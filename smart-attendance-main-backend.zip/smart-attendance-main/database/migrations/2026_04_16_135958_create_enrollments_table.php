<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('enrollments', function (Blueprint $table) {
            $table->id();

            // Student
            $table->foreignId('user_id')
                ->constrained('users')
                ->onDelete('cascade');

            // Course
            $table->foreignId('course_id')
                ->constrained('courses')
                ->onDelete('cascade');

            $table->timestamps();

            // Prevent duplicate enrollment
            $table->unique(['user_id', 'course_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('enrollments');
    }
};
