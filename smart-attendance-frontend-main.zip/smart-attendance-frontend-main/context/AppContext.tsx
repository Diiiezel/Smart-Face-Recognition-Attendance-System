import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useContext, useEffect, useState } from "react";

import {
  AUTH_TOKEN_KEY,
  AUTH_USER_KEY,
  DISPLAY_ROLE_KEY,
  FAKE_AUTH_TOKEN,
  authService,
  getErrorMessage,
  toApiRole,
  toDisplayRole,
  type ApiRole,
  type DisplayRole,
} from "@/services/authService";
import { attendanceService } from "@/services/attendanceService";
import { accountService } from "@/services/accountService";
import { coursesService } from "@/services/coursesService";
import { reportsService } from "@/services/reportsService";
import { sessionsService } from "@/services/sessionsService";
import { formatAcademicLevel } from "@/utils/academicLevel";
import { formatLocalDate, formatLocalTime, formatScheduleDate, formatScheduleTime } from "@/utils/dateTime";

export type UserRole = DisplayRole | null;

export interface StudentProfile {
  id: string;
  name: string;
  universityId: string;
  email: string;
  department: string;
  level: string;
  avatar?: string;
  faceImageUri?: string;
  faceEnrolled: boolean;
}

export interface StaffProfile {
  id: string;
  name: string;
  staffId: string;
  email: string;
  department: string;
  title: string;
}

export interface Course {
  id: string;
  courseIds?: string[];
  code: string;
  name: string;
  instructor: string;
  department: string;
  level: string;
  departments?: string[];
  levels?: string[];
  enrolledCount: number;
  sessionsCount?: number;
  schedule: string;
}

export interface AttendanceSession {
  id: string;
  sessionIds?: string[];
  sessionGroupKey?: string | null;
  courseId: string;
  courseIds?: string[];
  courseName: string;
  courseCode: string;
  levels?: string[];
  levelLabels?: string[];
  date: string;
  startTime: string;
  endTime: string;
  type: "face" | "qr" | "both";
  status: "scheduled" | "open" | "closed";
  isOpen: boolean;
  presentCount: number;
  totalCount: number;
}

export interface AttendanceRecord {
  id: string;
  courseCode: string;
  courseName: string;
  date: string;
  status: "present" | "absent";
  time?: string;
  attendanceRate: number;
}

export interface ReportsOverview {
  totals: {
    averageAttendanceRate: number;
    coursesCount: number;
    sessionsCount: number;
    studentsCount: number;
  };
  trend: Array<{ label: string; date: string; attendanceRate: number }>;
  courses: Array<{
    id: string;
    code: string;
    name: string;
    totalStudents: number;
    sessionsCount: number;
    attendanceRate: number;
  }>;
}

export interface SessionReportStudent {
  id: string;
  name: string;
  universityId: string;
  status: "present" | "absent";
  time?: string;
  method?: "face" | "qr";
  matchScore?: number | null;
}

export interface SessionReport {
  session: AttendanceSession | null;
  students: SessionReportStudent[];
}

interface AuthPayload {
  name: string;
  email: string;
  password: string;
  role: DisplayRole;
  universityId: string;
  major?: string;
  level?: string;
  levels?: string[];
}

export interface AppContextType {
  role: UserRole;
  setRole: (role: UserRole) => Promise<void>;
  backendRole: ApiRole | null;
  isAuthenticated: boolean;
  isReady: boolean;
  isLoading: boolean;
  studentProfile: StudentProfile | null;
  staffProfile: StaffProfile | null;
  courses: Course[];
  sessions: AttendanceSession[];
  attendanceHistory: AttendanceRecord[];
  qrCodeUrl: string | null;
  qrPayload: string | null;
  reportsOverview: ReportsOverview | null;
  login: (email: string, password: string, role: DisplayRole) => Promise<void>;
  signup: (payload: AuthPayload) => Promise<void>;
  logout: () => Promise<void>;
  refreshData: () => Promise<void>;
  updateProfile: (input: {
    name: string;
    email: string;
    major?: string;
    level?: string;
  }) => Promise<void>;
  changePassword: (input: {
    currentPassword: string;
    password: string;
    passwordConfirmation: string;
  }) => Promise<void>;
  enrollFace: (file: { uri: string; name?: string | null; mimeType?: string | null }) => Promise<void>;
  createCourse: (input: {
    name: string;
    code: string;
    semester?: string;
    level?: string;
    departments?: string[];
    levels?: string[];
  }) => Promise<void>;
  createSession: (input: {
    courseId: string;
    method: "face" | "qr" | "both";
    startsAt?: string | null;
    endsAt?: string | null;
  }) => Promise<void>;
  openSession: (sessionId: string) => Promise<void>;
  closeSession: (sessionId: string) => Promise<void>;
  deleteSession: (sessionId: string) => Promise<void>;
  updateSession: (
    sessionId: string,
    input: {
      method: "face" | "qr" | "both";
      startsAt?: string | null;
      endsAt?: string | null;
    },
  ) => Promise<void>;
  loadSessionReport: (sessionId: string) => Promise<SessionReport>;
  markQrAttendance: (sessionId: string, qrPayload: string) => Promise<SessionReportStudent>;
  markFaceAttendance: (
    sessionId: string,
    file: { uri: string; name?: string | null; mimeType?: string | null },
  ) => Promise<SessionReportStudent>;
}

const AppContext = createContext<AppContextType | null>(null);

function formatDate(dateValue?: string | null) {
  return formatLocalDate(dateValue);
}

function formatTime(dateValue?: string | null) {
  return formatLocalTime(dateValue);
}

function formatSessionDate(dateValue?: string | null) {
  return formatScheduleDate(dateValue);
}

function formatSessionTime(dateValue?: string | null) {
  return formatScheduleTime(dateValue);
}

function formatStudentLevel(level?: string | number | null) {
  return formatAcademicLevel(level) || "N/A";
}

function mapStudentProfile(user: any): StudentProfile {
  const savedFaceImage = user.face_image_url || user.face_image_uri || user.avatar;
  return {
    id: String(user.id),
    name: user.name,
    universityId: user.university_code || `ST-${user.id}`,
    email: user.email,
    department: user.major || "Unassigned",
    level: formatStudentLevel(user.level),
    avatar: savedFaceImage || undefined,
    faceImageUri: savedFaceImage || undefined,
    faceEnrolled: Boolean(user.is_face_verified || user.face_enrolled || user.face_token),
  };
}

function mapStaffProfile(user: any): StaffProfile {
  const assignedLevels = Array.isArray(user.levels)
    ? user.levels.filter(Boolean).join(", ")
    : user.level || "Doctor";

  return {
    id: String(user.id),
    name: user.name,
    staffId: user.university_code || `DOC-${user.id}`,
    email: user.email,
    department: user.major || "Academic Staff",
    title: assignedLevels,
  };
}

function mapCourse(course: any): Course {
  const departments = Array.isArray(course.departments)
    ? course.departments.filter(Boolean)
    : course.doctor?.major
      ? [course.doctor.major]
      : [];
  const levels = Array.isArray(course.levels)
    ? course.levels.filter(Boolean)
    : course.level
      ? [course.level]
      : [];

  return {
    id: String(course.id),
    courseIds: Array.isArray(course.courseIds)
      ? course.courseIds.map(String)
      : Array.isArray(course.course_ids)
        ? course.course_ids.map(String)
        : [String(course.id)],
    code: course.code,
    name: course.name,
    instructor: course.doctor?.name || "Doctor",
    department: departments.join(", ") || course.doctor?.major || course.semester || "General",
    level: levels.join(", ") || course.level || "N/A",
    departments,
    levels,
    enrolledCount: Number(course.enrolledCount ?? course.enrollments_count ?? course.enrolled_count ?? 0),
    sessionsCount: Number(course.sessionsCount ?? course.sessions_count ?? 0),
    schedule: course.semester || "TBD",
  };
}

function mapSession(session: any): AttendanceSession {
  return {
    id: String(session.id),
    sessionIds: Array.isArray(session.sessionIds)
      ? session.sessionIds.map(String)
      : Array.isArray(session.session_ids)
        ? session.session_ids.map(String)
        : [String(session.id)],
    sessionGroupKey: session.sessionGroupKey || session.session_group_key || null,
    courseId: String(session.course_id || session.courseId || session.course?.id || ""),
    courseIds: Array.isArray(session.courseIds)
      ? session.courseIds.map(String)
      : Array.isArray(session.course_ids)
        ? session.course_ids.map(String)
        : [String(session.course_id || session.courseId || session.course?.id || "")],
    courseName: session.course_name || session.courseName || session.course?.name || "Session",
    courseCode: session.course_code || session.courseCode || session.course?.code || "N/A",
    levels: Array.isArray(session.levels) ? session.levels.map(String) : [],
    levelLabels: Array.isArray(session.levelLabels)
      ? session.levelLabels
      : Array.isArray(session.level_labels)
        ? session.level_labels
        : [],
    date: session.display_date || formatSessionDate(session.starts_at || session.created_at),
    startTime: session.display_start_time || formatSessionTime(session.starts_at),
    endTime: session.display_end_time || formatSessionTime(session.ends_at),
    type: session.method,
    status: session.status || "scheduled",
    isOpen: session.status === "open",
    presentCount: Number(session.present_count || session.records_count || 0),
    totalCount: Number(session.total_count || session.course?.enrollments_count || 0),
  };
}

function mapAttendanceRecord(record: any): AttendanceRecord {
  const normalizedStatus = record.status === "late" ? "present" : record.status;
  return {
    id: String(record.id),
    courseCode: record.course_code || "N/A",
    courseName: record.course_name || "Unknown Course",
    date: record.date || "Unknown date",
    status: normalizedStatus,
    time: record.time || undefined,
    attendanceRate: Number(record.attendance_rate || 0),
  };
}

function mapReportsOverview(payload: any): ReportsOverview {
  return {
    totals: {
      averageAttendanceRate: Number(payload.totals?.average_attendance_rate || 0),
      coursesCount: Number(payload.totals?.courses_count || 0),
      sessionsCount: Number(payload.totals?.sessions_count || 0),
      studentsCount: Number(payload.totals?.students_count || 0),
    },
    trend: (payload.trend || []).map((item: any) => ({
      label: item.label,
      date: item.date,
      attendanceRate: Number(item.attendance_rate || 0),
    })),
    courses: (payload.courses || []).map((item: any) => ({
      id: String(item.id),
      code: item.code,
      name: item.name,
      totalStudents: Number(item.total_students || 0),
      sessionsCount: Number(item.sessions_count || 0),
      attendanceRate: Number(item.attendance_rate || 0),
    })),
  };
}

function mapSessionReport(payload: any): SessionReport {
  return {
    session: payload.session
      ? {
          id: String(payload.session.id),
          courseId: String(payload.session.course?.id || payload.session.course_id || ""),
          courseName: payload.session.course?.name || "Session",
          courseCode: payload.session.course?.code || "N/A",
          date: payload.session.display_date || formatSessionDate(payload.session.starts_at),
          startTime: payload.session.display_start_time || formatSessionTime(payload.session.starts_at),
          endTime: payload.session.display_end_time || formatSessionTime(payload.session.ends_at),
          type: payload.session.method,
          status: payload.session.status || "scheduled",
          isOpen: payload.session.status === "open",
          presentCount: Number(payload.session.present_count || 0),
          totalCount: Number(payload.session.total_count || 0),
        }
      : null,
    students: (payload.students || []).map((student: any) => {
      const normalizedStatus = student.status === "late" ? "present" : student.status;
      return {
        id: String(student.id),
        name: student.full_name,
        universityId: student.university_code || `ST-${student.id}`,
        status: normalizedStatus,
        time: student.attended_at ? formatTime(student.attended_at) : undefined,
        method: student.method || undefined,
        matchScore:
          student.match_score === null || student.match_score === undefined
            ? null
            : Number(student.match_score),
      };
    }),
  };
}

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [role, setRoleState] = useState<UserRole>(null);
  const [backendRole, setBackendRole] = useState<ApiRole | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isReady, setIsReady] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [studentProfile, setStudentProfile] = useState<StudentProfile | null>(null);
  const [staffProfile, setStaffProfile] = useState<StaffProfile | null>(null);
  const [courses, setCourses] = useState<Course[]>([]);
  const [sessions, setSessions] = useState<AttendanceSession[]>([]);
  const [attendanceHistory, setAttendanceHistory] = useState<AttendanceRecord[]>([]);
  const [qrCodeUrl, setQrCodeUrl] = useState<string | null>(null);
  const [qrPayload, setQrPayload] = useState<string | null>(null);
  const [reportsOverview, setReportsOverview] = useState<ReportsOverview | null>(null);

  useEffect(() => {
    void hydrate();
  }, []);

  useEffect(() => {
    if (isReady) return;

    const timeout = setTimeout(() => {
      void clearSession().finally(() => setIsReady(true));
    }, 12000);

    return () => clearTimeout(timeout);
  }, [isReady]);

  async function setRole(nextRole: UserRole) {
    setRoleState(nextRole);

    if (nextRole) {
      await AsyncStorage.setItem(DISPLAY_ROLE_KEY, nextRole);
      return;
    }

    await AsyncStorage.removeItem(DISPLAY_ROLE_KEY);
  }

  async function hydrate() {
    try {
      const storedRole = await AsyncStorage.getItem(DISPLAY_ROLE_KEY);
      const token = await AsyncStorage.getItem(AUTH_TOKEN_KEY);

      if (storedRole === "student" || storedRole === "staff") {
        setRoleState(storedRole);
      }

      if (!token) {
        setIsReady(true);
        return;
      }

      await refreshData();
    } catch {
      await clearSession();
    } finally {
      setIsReady(true);
    }
  }

  async function applyAuthenticatedUser(user: any) {
    setBackendRole(user.role);
    const nextRole = toDisplayRole(user.role);
    setRoleState(nextRole);
    setIsAuthenticated(true);
    await AsyncStorage.setItem(AUTH_USER_KEY, JSON.stringify(user || {}));

    if (nextRole) {
      await AsyncStorage.setItem(DISPLAY_ROLE_KEY, nextRole);
    }

    if (user.role === "student") {
      setStudentProfile(mapStudentProfile(user));
      setStaffProfile(null);
    } else {
      setStaffProfile(mapStaffProfile(user));
      setStudentProfile(null);
    }
  }

  async function refreshData() {
    setIsLoading(true);

    try {
      const user = await authService.getCurrentUser();
      await applyAuthenticatedUser(user);

      const myCourses = await coursesService.getCourses(user.role);
      setCourses((myCourses || []).map(mapCourse));

      if (user.role === "student") {
        const [attendance, qr] = await Promise.all([
          attendanceService.getAttendance(),
          attendanceService.getQrCode(),
        ]);

        setAttendanceHistory((attendance.records || []).map(mapAttendanceRecord));
        setQrCodeUrl(qr.qr_url || null);
        setQrPayload(qr.qr_payload || null);
        setSessions([]);
        setReportsOverview(null);
      } else {
        const [doctorSessions, overview] = await Promise.all([
          sessionsService.getSessions(),
          reportsService.getReports(),
        ]);

        setSessions((doctorSessions || []).map(mapSession));
        setReportsOverview(mapReportsOverview(overview));
        setAttendanceHistory([]);
        setQrCodeUrl(null);
        setQrPayload(null);
      }
    } catch (error) {
      await clearSession();
      throw error;
    } finally {
      setIsLoading(false);
    }
  }

  async function login(email: string, password: string, selectedRole: DisplayRole) {
    setIsLoading(true);

    try {
      const response = await authService.login({
        email,
        password,
        role: selectedRole,
      });

      const apiDisplayRole = toDisplayRole(response.user.role);
      if (apiDisplayRole && apiDisplayRole !== selectedRole) {
        throw new Error(
          `This account is registered as ${apiDisplayRole === "staff" ? "staff" : "student"}.`,
        );
      }

      await AsyncStorage.setItem(AUTH_TOKEN_KEY, String(response.token || FAKE_AUTH_TOKEN));
      await applyAuthenticatedUser(response.user);
      await refreshData();
    } finally {
      setIsLoading(false);
    }
  }

  async function signup(payload: AuthPayload) {
    setIsLoading(true);

    try {
      const response = await authService.signup({
        fullName: payload.name,
        universityId: payload.universityId,
        email: payload.email,
        password: payload.password,
        confirmPassword: payload.password,
        role: toApiRole(payload.role),
        ...(payload.role === "student"
          ? {
              major: payload.major,
              level: payload.level,
            }
          : {
              major: payload.major,
              levels: payload.levels,
            }),
      });

      await AsyncStorage.setItem(AUTH_TOKEN_KEY, String(response.token || FAKE_AUTH_TOKEN));
      await applyAuthenticatedUser(response.user);
      await refreshData();
    } finally {
      setIsLoading(false);
    }
  }

  async function clearSession() {
    setBackendRole(null);
    setRoleState(null);
    setIsAuthenticated(false);
    setStudentProfile(null);
    setStaffProfile(null);
    setCourses([]);
    setSessions([]);
    setAttendanceHistory([]);
    setQrCodeUrl(null);
    setQrPayload(null);
    setReportsOverview(null);
    await AsyncStorage.multiRemove([AUTH_TOKEN_KEY, AUTH_USER_KEY, DISPLAY_ROLE_KEY]);
  }

  async function logout() {
    try {
      await authService.logout();
    } catch {
      // Ignore logout transport failures and clear local session anyway.
    }

    await clearSession();
  }

  async function updateProfileAction(input: {
    name: string;
    email: string;
    major?: string;
    level?: string;
  }) {
    setIsLoading(true);

    try {
      const response = await accountService.updateProfile(input);
      await applyAuthenticatedUser(response.user);
      await refreshData();
    } finally {
      setIsLoading(false);
    }
  }

  async function changePasswordAction(input: {
    currentPassword: string;
    password: string;
    passwordConfirmation: string;
  }) {
    setIsLoading(true);

    try {
      await accountService.changePassword({
        current_password: input.currentPassword,
        password: input.password,
        password_confirmation: input.passwordConfirmation,
      });
    } finally {
      setIsLoading(false);
    }
  }

  async function enrollFace(file: { uri: string; name?: string | null; mimeType?: string | null }) {
    setIsLoading(true);

    try {
      const response = await attendanceService.registerFace(file);
      const enrolledFaceImage = response.face_image_url || response.face_image_uri || file.uri;
      await refreshData();
      setStudentProfile((previous) =>
        previous
          ? {
              ...previous,
              avatar: previous.faceImageUri || enrolledFaceImage,
              faceImageUri: previous.faceImageUri || enrolledFaceImage,
              faceEnrolled: true,
            }
          : previous,
      );
    } finally {
      setIsLoading(false);
    }
  }

  async function createCourseAction(input: {
    name: string;
    code: string;
    semester?: string;
    level?: string;
    departments?: string[];
    levels?: string[];
  }) {
    setIsLoading(true);

    try {
      await coursesService.createCourse(input);
      await refreshData();
    } finally {
      setIsLoading(false);
    }
  }

  async function createSessionAction(input: {
    courseId: string;
    method: "face" | "qr" | "both";
    startsAt?: string | null;
    endsAt?: string | null;
  }) {
    setIsLoading(true);

    try {
      const selectedCourse = courses.find((course) => course.id === input.courseId);
      const courseIds = selectedCourse?.courseIds?.length ? selectedCourse.courseIds : [input.courseId];
      const sessionGroupKey =
        courseIds.length > 1
          ? `session-group-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`
          : null;

      for (const courseId of courseIds) {
        await sessionsService.createSession({
          course_id: Number(courseId),
          method: input.method,
          starts_at: input.startsAt || null,
          ends_at: input.endsAt || null,
          session_group_key: sessionGroupKey,
        });
      }

      await refreshData();
    } finally {
      setIsLoading(false);
    }
  }

  async function openSessionAction(sessionId: string) {
    setIsLoading(true);

    try {
      await sessionsService.openSession(Number(sessionId));
      await refreshData();
    } finally {
      setIsLoading(false);
    }
  }

  async function closeSessionAction(sessionId: string) {
    setIsLoading(true);

    try {
      await sessionsService.closeSession(Number(sessionId));
      await refreshData();
    } finally {
      setIsLoading(false);
    }
  }

  async function deleteSessionAction(sessionId: string) {
    setIsLoading(true);

    try {
      await sessionsService.deleteSession(Number(sessionId));
      await refreshData();
    } finally {
      setIsLoading(false);
    }
  }

  async function updateSessionAction(
    sessionId: string,
    input: {
      method: "face" | "qr" | "both";
      startsAt?: string | null;
      endsAt?: string | null;
    },
  ) {
    setIsLoading(true);

    try {
      await sessionsService.updateSession(Number(sessionId), {
        method: input.method,
        starts_at: input.startsAt || null,
        ends_at: input.endsAt || null,
      });
      await refreshData();
    } finally {
      setIsLoading(false);
    }
  }

  async function loadSessionReport(sessionId: string) {
    const report = await sessionsService.getSessionReport(Number(sessionId));
    return mapSessionReport(report);
  }

  async function markQrAttendance(sessionId: string, payload: string) {
    const response = await sessionsService.markQrAttendance(Number(sessionId), {
      qr_payload: payload,
    });
    await refreshData();
    const attendance = response.attendance || response.data || {};

    return {
      id: String(response.student.id),
      name: response.student.name,
      universityId: response.student.university_code || `ST-${response.student.id}`,
      status: "present" as const,
      time: attendance.attended_at ? formatTime(attendance.attended_at) : undefined,
      method: "qr" as const,
      matchScore: null,
    };
  }

  async function markFaceAttendance(
    sessionId: string,
    file: { uri: string; name?: string | null; mimeType?: string | null },
    ) {
    const response = await sessionsService.markFaceAttendance(Number(sessionId), file);
    await refreshData();
    const attendance = response.attendance || response.data || {};

    return {
      id: String(response.student.id),
      name: response.student.name,
      universityId: response.student.university_code || `ST-${response.student.id}`,
      status: "present" as const,
      time: attendance.attended_at ? formatTime(attendance.attended_at) : undefined,
      method: "face" as const,
      matchScore:
        response.confidence === null || response.confidence === undefined
          ? null
          : Number(response.confidence),
    };
  }

  return (
    <AppContext.Provider
      value={{
        role,
        setRole,
        backendRole,
        isAuthenticated,
        isReady,
        isLoading,
        studentProfile,
        staffProfile,
        courses,
        sessions,
        attendanceHistory,
        qrCodeUrl,
        qrPayload,
        reportsOverview,
        login,
        signup,
        logout,
        refreshData,
        updateProfile: updateProfileAction,
        changePassword: changePasswordAction,
        enrollFace,
        createCourse: createCourseAction,
        createSession: createSessionAction,
        openSession: openSessionAction,
        closeSession: closeSessionAction,
        deleteSession: deleteSessionAction,
        updateSession: updateSessionAction,
        loadSessionReport,
        markQrAttendance,
        markFaceAttendance,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}

export function useAppErrorMessage(error: unknown) {
  return getErrorMessage(error);
}
