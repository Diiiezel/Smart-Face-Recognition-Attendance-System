import {
  getCurrentUser,
  hydrateMockSession,
  loginUser,
  logoutUser,
  MOCK_AUTH_TOKEN,
  MOCK_AUTH_USER_KEY,
  registerUser,
  requestMockPasswordReset,
  resetMockPassword,
  updateMockCurrentUserProfile,
  changeMockCurrentUserPassword,
  type ApiRole,
  type DisplayRole,
} from "@/mocks/mockApi";
import {
  apiClient,
  clearAuthToken,
  setAuthToken,
} from "@/services/apiClient";

export { AUTH_TOKEN_KEY } from "@/services/apiClient";
export const AUTH_USER_KEY = MOCK_AUTH_USER_KEY;
export const DISPLAY_ROLE_KEY = "userRole";
export const FAKE_AUTH_TOKEN = MOCK_AUTH_TOKEN;
export const USE_MOCKS = process.env.EXPO_PUBLIC_USE_MOCKS === "true";

if (USE_MOCKS) {
  void hydrateMockSession();
}

export type { ApiRole, DisplayRole };

export function toApiRole(role: DisplayRole): "student" | "doctor" {
  return role === "staff" ? "doctor" : "student";
}

export function toDisplayRole(role: ApiRole | null | undefined): DisplayRole | null {
  if (role === "doctor") return "staff";
  if (role === "student") return "student";
  return null;
}

export function getErrorMessage(error: unknown): string {
  if (error instanceof Error) {
    return error.message;
  }

  return "Something went wrong. Please try again.";
}

type BackendUser = {
  id: number;
  name: string;
  email: string;
  role: ApiRole;
  university_code?: string | null;
  major?: string | null;
  level?: number | string | null;
  face_token?: string | null;
  face_image_url?: string | null;
  face_image_uri?: string | null;
  face_enrolled?: boolean;
  is_face_verified?: boolean;
};

type AuthResponse = {
  message?: string;
  token: string;
  user: BackendUser;
};

export function normalizeUser(user: BackendUser) {
  const faceEnrolled = Boolean(user.face_enrolled || user.is_face_verified || user.face_token);

  return {
    ...user,
    role: user.role,
    university_code: user.university_code || "",
    universityId: user.university_code || "",
    major: user.major || "",
    level: user.level === null || user.level === undefined ? "" : String(user.level),
    face_token: user.face_token || (faceEnrolled ? "registered" : null),
    is_face_verified: faceEnrolled,
    face_enrolled: faceEnrolled,
  };
}

export function mapLevelToBackend(level?: string) {
  if (!level) return undefined;

  const trimmed = level.trim();
  const numeric = Number(trimmed);
  if (Number.isFinite(numeric)) return numeric;

  const normalized = trimmed.toLowerCase();
  const map: Record<string, number> = {
    "first year": 1,
    first: 1,
    "year 1": 1,
    "second year": 2,
    second: 2,
    "year 2": 2,
    "third year": 3,
    third: 3,
    "year 3": 3,
    "fourth year": 4,
    fourth: 4,
    "year 4": 4,
    "fifth year": 5,
    fifth: 5,
    "year 5": 5,
  };

  return map[normalized] || undefined;
}

function normalizeAuthResponse(response: AuthResponse) {
  return {
    ...response,
    user: normalizeUser(response.user),
  };
}

export const authService = {
  async getCurrentUser() {
    if (USE_MOCKS) {
      return getCurrentUser();
    }

    const user = await apiClient.get<BackendUser>("/me");
    return normalizeUser(user);
  },
  async login(payload: { email: string; password: string; role?: DisplayRole }) {
    if (USE_MOCKS) {
      return loginUser(payload);
    }

    const response = await apiClient.post<AuthResponse>(
      "/login",
      {
        email: payload.email,
        password: payload.password,
      },
      { auth: false },
    );

    await setAuthToken(response.token);
    return normalizeAuthResponse(response);
  },
  async signup(payload: {
    fullName: string;
    universityId: string;
    email: string;
    password: string;
    confirmPassword?: string;
    major?: string;
    level?: string;
    levels?: string[];
    role: "student" | "doctor";
  }) {
    if (USE_MOCKS) {
      return registerUser({
        name: payload.fullName,
        email: payload.email,
        password: payload.password,
        role: payload.role,
        university_code: payload.universityId,
        major: payload.major,
        level: payload.level,
        levels: payload.levels,
      });
    }

    const isStudent = payload.role === "student";
    const response = await apiClient.post<AuthResponse>(
      "/register",
      {
        name: payload.fullName,
        email: payload.email,
        password: payload.password,
        password_confirmation: payload.confirmPassword || payload.password,
        role: payload.role,
        ...(isStudent
          ? {
              university_code: payload.universityId,
              major: payload.major,
              level: mapLevelToBackend(payload.level),
            }
          : {}),
      },
      { auth: false },
    );

    await setAuthToken(response.token);
    return normalizeAuthResponse(response);
  },
  async logout() {
    if (USE_MOCKS) {
      return logoutUser();
    }

    try {
      return await apiClient.post("/logout");
    } finally {
      await clearAuthToken();
    }
  },
  async forgotPassword(email: string) {
    if (USE_MOCKS) {
      return requestMockPasswordReset(email);
    }

    return apiClient.post<{ message: string }>(
      "/forgot-password",
      { email },
      { auth: false, timeoutMs: 45000 },
    );
  },
  async resetPassword(payload: {
    email: string;
    otp: string;
    password: string;
    password_confirmation: string;
  }) {
    if (USE_MOCKS) {
      return resetMockPassword(payload);
    }

    return apiClient.post<{ message: string }>(
      "/reset-password",
      payload,
      { auth: false },
    );
  },
};
