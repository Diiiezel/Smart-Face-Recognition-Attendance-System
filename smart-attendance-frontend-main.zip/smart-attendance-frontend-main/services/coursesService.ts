import {
  createCourse,
  enrollStudentInCourse,
  getMyCourses,
  getStudentAvailableCourses as getMockStudentAvailableCourses,
  type ApiRole,
} from "@/mocks/mockApi";
import { apiClient } from "@/services/apiClient";
import { USE_MOCKS } from "@/services/authService";
import { academicLevelToNumber, formatAcademicLevel } from "@/utils/academicLevel";

type BackendCourse = {
  id: number | string;
  course_ids?: Array<number | string> | null;
  name?: string | null;
  code?: string | null;
  semester?: string | null;
  level?: number | string | null;
  department?: string | null;
  departments?: string[] | null;
  levels?: string[] | null;
  enrolled_count?: number | null;
  enrollments_count?: number | null;
  sessions_count?: number | null;
  attendance_rate?: number | null;
  doctor?: {
    name?: string | null;
    major?: string | null;
  } | null;
};

function parseDepartments(course: BackendCourse) {
  const source = Array.isArray(course.departments)
    ? course.departments
    : [course.department, course.semester, course.doctor?.major];

  return source
    .flatMap((value) => String(value || "").split(","))
    .map((value) => value.trim().toUpperCase())
    .filter((value) => value === "CS" || value === "IS");
}

export function normalizeCourse(course: BackendCourse) {
  const enrolledCount = Number(course.enrolled_count ?? course.enrollments_count ?? 0);
  const sessionsCount = Number(course.sessions_count ?? 0);
  const attendanceRate = Number(course.attendance_rate ?? 0);
  const level = formatAcademicLevel(course.level);
  const departments = parseDepartments(course);
  const levels = Array.isArray(course.levels)
      ? course.levels.filter(Boolean).map(formatAcademicLevel)
    : level
      ? [level]
      : [];

  return {
    ...course,
    id: String(course.id),
    course_ids: Array.isArray(course.course_ids) ? course.course_ids.map(String) : [String(course.id)],
    courseIds: Array.isArray(course.course_ids) ? course.course_ids.map(String) : [String(course.id)],
    name: course.name || "Untitled Course",
    code: course.code || `COURSE-${course.id}`,
    semester: course.semester || "",
    level,
    department: course.department || departments.join(", ") || "",
    departments,
    levels,
    doctor: course.doctor || null,
    instructor: course.doctor?.name || "Doctor",
    enrolled_count: enrolledCount,
    enrollments_count: enrolledCount,
    enrolledCount,
    sessions_count: sessionsCount,
    sessionsCount,
    attendance_rate: attendanceRate,
    attendanceRate,
  };
}

type NormalizedCourse = ReturnType<typeof normalizeCourse>;

function displayCodeForCourse(code: string) {
  return code.replace(/-(CS|IS)[1-4](?:-\d+)?$/i, "");
}

function doctorCourseGroupKey(course: NormalizedCourse) {
  return `${course.name.trim().toLowerCase()}::${displayCodeForCourse(course.code).trim().toLowerCase()}`;
}

function uniqueValues(values: string[]) {
  return Array.from(new Set(values.filter(Boolean)));
}

export function groupDoctorCourses(courses: NormalizedCourse[]) {
  const grouped = new Map<string, NormalizedCourse>();

  for (const course of courses) {
    const key = doctorCourseGroupKey(course);
    const existing = grouped.get(key);

    if (!existing) {
      grouped.set(key, {
        ...course,
        code: displayCodeForCourse(course.code),
        course_ids: [...course.courseIds],
        courseIds: [...course.courseIds],
      });
      continue;
    }

    const departments = uniqueValues([...existing.departments, ...course.departments]);
    const levels = uniqueValues([...existing.levels, ...course.levels]);
    const courseIds = uniqueValues([...existing.courseIds, ...course.courseIds]);
    const enrolledCount = Number(existing.enrolledCount || 0) + Number(course.enrolledCount || 0);
    const sessionsCount = Number(existing.sessionsCount || 0) + Number(course.sessionsCount || 0);

    grouped.set(key, {
      ...existing,
      departments: departments.filter((value): value is "CS" | "IS" => value === "CS" || value === "IS"),
      levels,
      department: departments.join(", ") || existing.department,
      level: levels.join(", ") || existing.level,
      enrolled_count: enrolledCount,
      enrollments_count: enrolledCount,
      enrolledCount,
      sessions_count: sessionsCount,
      sessionsCount,
      course_ids: courseIds,
      courseIds,
    });
  }

  return Array.from(grouped.values());
}

async function getBackendStudentCourses() {
  const courses = await apiClient.get<BackendCourse[]>("/my-courses");
  return (courses || []).map(normalizeCourse);
}

async function getBackendAvailableCourses() {
  const courses = await apiClient.get<BackendCourse[]>("/available-courses");
  return (courses || []).map(normalizeCourse);
}

async function getBackendDoctorCourses() {
  const courses = await apiClient.get<BackendCourse[]>("/courses");
  return groupDoctorCourses((courses || []).map(normalizeCourse));
}

function isSameCourseIdentifier(course: ReturnType<typeof normalizeCourse>, identifier: string) {
  const normalized = identifier.trim().toLowerCase();
  return (
    String(course.id).toLowerCase() === normalized ||
    String(course.code || "").toLowerCase() === normalized
  );
}

export const coursesService = {
  async getCourses(role?: ApiRole | null) {
    if (!USE_MOCKS && role === "student") {
      return getBackendStudentCourses();
    }

    if (!USE_MOCKS && role === "doctor") {
      return getBackendDoctorCourses();
    }

    return getMyCourses();
  },
  async getStudentAvailableCourses() {
    if (!USE_MOCKS) {
      return getBackendAvailableCourses();
    }

    return getMockStudentAvailableCourses();
  },
  async enrollStudent(courseCode: string) {
    if (!USE_MOCKS) {
      const availableCourses = await getBackendAvailableCourses();
      const course = availableCourses.find((item) => isSameCourseIdentifier(item, courseCode));

      if (!course) {
        throw new Error("This course is not available for enrollment.");
      }

      await apiClient.post("/enroll", {
        course_id: Number(course.id),
      });

      return getBackendStudentCourses();
    }

    return enrollStudentInCourse(courseCode);
  },
  async createCourse(payload: {
    name: string;
    code: string;
    semester?: string;
    level?: string;
    departments?: string[];
    levels?: string[];
  }) {
    if (!USE_MOCKS) {
      const response = await apiClient.post<{ course?: BackendCourse }>("/courses", {
        name: payload.name,
        code: payload.code,
        semester: payload.semester || null,
        level: academicLevelToNumber(payload.level || payload.levels?.[0] || null) || null,
        departments: payload.departments || [],
        levels: (payload.levels || []).map((level) => academicLevelToNumber(level)).filter(Boolean),
      });

      return response.course ? normalizeCourse(response.course) : response;
    }

    return createCourse(payload);
  },
};
