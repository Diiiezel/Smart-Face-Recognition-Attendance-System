import AsyncStorage from "@react-native-async-storage/async-storage";

import {
  managedStudentsSeed,
  type ManagedStudent,
  type ManagedStudentAttendanceRecord,
} from "@/mocks/students";

const MANAGED_STUDENTS_KEY = "managedStudents";

interface RegisteredStudentInput {
  fullName: string;
  universityId: string;
  email: string;
  major: string;
  level: string;
  faceEnrolled?: boolean;
  faceImageUri?: string | null;
}

interface AddManagedStudentInput extends RegisteredStudentInput {
  courseCode: string;
}

function clone<T>(value: T): T {
  return JSON.parse(JSON.stringify(value)) as T;
}

function delay<T>(value: T, min = 500, max = 900): Promise<T> {
  const ms = Math.floor(Math.random() * (max - min + 1)) + min;
  return new Promise((resolve) => setTimeout(() => resolve(clone(value)), ms));
}

async function readStudents(): Promise<ManagedStudent[]> {
  const raw = await AsyncStorage.getItem(MANAGED_STUDENTS_KEY);
  if (!raw) {
    const seed = clone(managedStudentsSeed);
    await AsyncStorage.setItem(MANAGED_STUDENTS_KEY, JSON.stringify(seed));
    return seed;
  }

  try {
    const parsed = JSON.parse(raw) as ManagedStudent[];
    return Array.isArray(parsed) ? parsed : clone(managedStudentsSeed);
  } catch {
    const seed = clone(managedStudentsSeed);
    await AsyncStorage.setItem(MANAGED_STUDENTS_KEY, JSON.stringify(seed));
    return seed;
  }
}

async function writeStudents(students: ManagedStudent[]) {
  await AsyncStorage.setItem(MANAGED_STUDENTS_KEY, JSON.stringify(students));
}

function dedupeCourses(courses: string[]) {
  return Array.from(new Set(courses.filter(Boolean)));
}

function nextStudentId() {
  return `stu_${Date.now()}`;
}

function normalizeRegisteredStudent(input: RegisteredStudentInput): ManagedStudent {
  return {
    id: nextStudentId(),
    fullName: input.fullName.trim(),
    universityId: input.universityId.trim(),
    email: input.email.trim().toLowerCase(),
    major: input.major.trim(),
    level: input.level.trim(),
    faceEnrolled: Boolean(input.faceEnrolled),
    faceImageUri: input.faceImageUri || null,
    attendanceRate: 100,
    courses: [],
    recentAttendance: [],
  };
}

export async function loadManagedStudents() {
  const students = await readStudents();
  // TODO: fetch students from backend
  return delay(students);
}

export async function getManagedStudentsForCourse(courseCode: string) {
  const students = await readStudents();
  const normalizedCourseCode = courseCode.trim();
  const enrolledStudents = students.filter((student) =>
    student.courses.includes(normalizedCourseCode),
  );
  // TODO: fetch enrolled students for course from backend
  return delay(enrolledStudents);
}

export async function upsertRegisteredStudent(input: RegisteredStudentInput) {
  const students = await readStudents();
  const normalizedUniversityId = input.universityId.trim();
  const normalizedEmail = input.email.trim().toLowerCase();
  const existingIndex = students.findIndex(
    (student) =>
      student.universityId === normalizedUniversityId ||
      student.email.toLowerCase() === normalizedEmail,
  );

  if (existingIndex >= 0) {
    students[existingIndex] = {
      ...students[existingIndex],
      fullName: input.fullName.trim(),
      universityId: normalizedUniversityId,
      email: normalizedEmail,
      major: input.major.trim(),
      level: input.level.trim(),
      faceEnrolled:
        input.faceEnrolled === undefined
          ? students[existingIndex].faceEnrolled
          : Boolean(input.faceEnrolled),
      faceImageUri:
        input.faceImageUri === undefined
          ? students[existingIndex].faceImageUri || null
          : input.faceImageUri || null,
    };
  } else {
    students.unshift(normalizeRegisteredStudent(input));
  }

  await writeStudents(students);
  return clone(students);
}

export async function findManagedStudentByEmail(email: string) {
  const students = await readStudents();
  const normalizedEmail = email.trim().toLowerCase();
  return (
    students.find((student) => student.email.toLowerCase() === normalizedEmail) || null
  );
}

export async function syncManagedStudentFaceEnrollment(
  lookup: { universityId?: string; email?: string },
  faceEnrolled: boolean,
  faceImageUri?: string | null,
) {
  const students = await readStudents();
  const normalizedUniversityId = lookup.universityId?.trim();
  const normalizedEmail = lookup.email?.trim().toLowerCase();

  const nextStudents = students.map((student) =>
    student.universityId === normalizedUniversityId ||
    student.email.toLowerCase() === normalizedEmail
      ? { ...student, faceEnrolled, faceImageUri: faceImageUri || student.faceImageUri || null }
      : student,
  );

  await writeStudents(nextStudents);
  return clone(nextStudents);
}

export async function addManagedStudent(input: AddManagedStudentInput) {
  const students = await readStudents();
  const normalizedUniversityId = input.universityId.trim();
  const normalizedEmail = input.email.trim().toLowerCase();
  const normalizedCourseCode = input.courseCode.trim();

  const duplicateInCourse = students.some(
    (student) =>
      student.universityId === normalizedUniversityId &&
      student.courses.includes(normalizedCourseCode),
  );

  if (duplicateInCourse) {
    throw new Error("This student is already enrolled in the selected course.");
  }

  const existingIndex = students.findIndex(
    (student) =>
      student.universityId === normalizedUniversityId ||
      student.email.toLowerCase() === normalizedEmail,
  );

  if (existingIndex >= 0) {
    students[existingIndex] = {
      ...students[existingIndex],
      fullName: input.fullName.trim(),
      universityId: normalizedUniversityId,
      email: normalizedEmail,
      major: input.major.trim(),
      level: input.level.trim(),
      courses: dedupeCourses([...students[existingIndex].courses, normalizedCourseCode]),
    };
  } else {
    students.unshift({
      ...normalizeRegisteredStudent(input),
      courses: [normalizedCourseCode],
    });
  }

  await writeStudents(students);
  // TODO: enroll student in course via backend
  return clone(students);
}

export async function removeManagedStudentFromCourse(studentId: string, courseCode: string) {
  const students = await readStudents();
  const nextStudents = students.map((student) =>
    student.id === studentId
      ? {
          ...student,
          courses: student.courses.filter((course) => course !== courseCode),
          recentAttendance: student.recentAttendance.filter(
            (record) => record.courseCode !== courseCode,
          ),
        }
      : student,
  );

  await writeStudents(nextStudents);
  // TODO: remove student from course via backend
  return clone(nextStudents);
}

export function getAttendanceVariant(rate: number) {
  if (rate >= 85) return "success";
  if (rate >= 75) return "warning";
  return "danger";
}

export function buildManagedStudentRecentAttendance(
  records: ManagedStudentAttendanceRecord[],
  courseCodes: string[],
) {
  return records.filter((record) => courseCodes.includes(record.courseCode));
}

export async function refreshManagedStudentsStats() {
  const students = await readStudents();
  // TODO: sync attendance statistics with backend
  return clone(students);
}
