import { getMyAttendanceHistory, getMyQr, mockUploadMultipart } from "@/mocks/mockApi";
import { apiClient, ApiError } from "@/services/apiClient";
import { USE_MOCKS } from "@/services/authService";
import { Platform } from "react-native";

type FaceFile = { uri: string; name?: string | null; mimeType?: string | null };

type RegisterFaceResponse = {
  message?: string;
  face_token?: string | null;
  face_image_url?: string | null;
  face_image_uri?: string | null;
};

type BackendQrResponse = {
  message?: string;
  qr_payload?: string | null;
  qr_data?: string | null;
  qr_url?: string | null;
};

type BackendAttendanceRecord = {
  id: number | string;
  course_id?: number | string | null;
  course_code?: string | null;
  course_name?: string | null;
  session_id?: number | string | null;
  date?: string | null;
  time?: string | null;
  status?: string | null;
  method?: string | null;
  attendance_rate?: number | string | null;
  attended_at?: string | null;
};

type BackendAttendanceResponse = {
  records?: BackendAttendanceRecord[];
};

function normalizeQrResponse(response: BackendQrResponse) {
  const payload = response.qr_payload || response.qr_data || null;

  return {
    ...response,
    qr_payload: payload,
    qr_data: response.qr_data || payload,
    qr_url: response.qr_url || null,
  };
}

function normalizeAttendanceRecord(record: BackendAttendanceRecord) {
  const courseId = record.course_id === null || record.course_id === undefined ? "" : String(record.course_id);
  const sessionId = record.session_id === null || record.session_id === undefined ? "" : String(record.session_id);
  const attendanceRate = Number(record.attendance_rate ?? 0);

  return {
    ...record,
    id: String(record.id),
    course_id: courseId,
    courseId,
    course_code: record.course_code || "N/A",
    courseCode: record.course_code || "N/A",
    course_name: record.course_name || "Unknown Course",
    courseName: record.course_name || "Unknown Course",
    session_id: sessionId,
    sessionId,
    date: record.date || "Unknown date",
    time: record.time || undefined,
    status: record.status === "late" ? "present" : record.status || "absent",
    method: record.method || undefined,
    attendance_rate: attendanceRate,
    attendanceRate,
    attended_at: record.attended_at || null,
    attendedAt: record.attended_at || null,
  };
}

async function appendImage(formData: FormData, file: FaceFile) {
  const name = file.name || "face-capture.jpg";
  const type = file.mimeType || "image/jpeg";

  if (Platform.OS === "web" && file.uri.startsWith("data:")) {
    const blob = await (await fetch(file.uri)).blob();
    formData.append("image", blob as any, name);
    return;
  }

  formData.append("image", {
    uri: file.uri,
    name,
    type,
  } as any);
}

function normalizeFaceError(error: unknown) {
  if (error instanceof ApiError && error.status === 503) {
    return new Error(error.message || "Face verification service is unavailable.");
  }

  return error;
}

export const attendanceService = {
  async getAttendance() {
    if (USE_MOCKS) {
      return getMyAttendanceHistory();
    }

    const response = await apiClient.get<BackendAttendanceResponse>("/my-attendance");

    return {
      records: (response.records || []).map(normalizeAttendanceRecord),
    };
  },
  async getQrCode() {
    if (USE_MOCKS) {
      return getMyQr();
    }

    const response = await apiClient.get<BackendQrResponse>("/my-qr");
    return normalizeQrResponse(response);
  },
  async registerFace(file: FaceFile): Promise<RegisterFaceResponse> {
    if (USE_MOCKS) {
      return mockUploadMultipart<RegisterFaceResponse>("register-face", file);
    }

    const formData = new FormData();
    await appendImage(formData, file);

    try {
      return await apiClient.post<RegisterFaceResponse>("/face/register", formData);
    } catch (error) {
      throw normalizeFaceError(error);
    }
  },
};
