import type { ManagedStudent } from "@/mocks/students";
import { apiClient } from "@/services/apiClient";
import { USE_MOCKS } from "@/services/authService";
import { groupDoctorCourses, normalizeCourse } from "@/services/coursesService";
import {
  addManagedStudent,
  findManagedStudentByEmail,
  getManagedStudentsForCourse as getMockManagedStudentsForCourse,
  loadManagedStudents,
  refreshManagedStudentsStats,
  removeManagedStudentFromCourse,
  syncManagedStudentFaceEnrollment,
  upsertRegisteredStudent,
} from "@/services/mockStudentsService";

export {
  addManagedStudent,
  findManagedStudentByEmail,
  loadManagedStudents,
  refreshManagedStudentsStats,
  removeManagedStudentFromCourse,
  syncManagedStudentFaceEnrollment,
  upsertRegisteredStudent,
};

type BackendRosterStudent = {
  id: number | string;
  full_name?: string | null;
  name?: string | null;
  email?: string | null;
  university_code?: string | null;
  university_id?: string | null;
  major?: string | null;
  level?: number | string | null;
  face_enrolled?: boolean | null;
  attendance_rate?: number | string | null;
};

type BackendCourse = Parameters<typeof normalizeCourse>[0];
type NormalizedCourse = ReturnType<typeof normalizeCourse>;
type BackendRosterResponse = {
  course?: {
    id?: number | string | null;
    code?: string | null;
  } | null;
  students?: BackendRosterStudent[];
};

function normalizeRosterStudent(student: BackendRosterStudent, courseCode: string): ManagedStudent {
  const fullName = student.full_name || student.name || "Student";
  const universityId = student.university_id || student.university_code || "";

  return {
    id: String(student.id),
    fullName,
    universityId,
    email: student.email || "",
    major: student.major || "",
    level: student.level === null || student.level === undefined ? "" : String(student.level),
    faceEnrolled: Boolean(student.face_enrolled),
    faceImageUri: null,
    attendanceRate: Number(student.attendance_rate ?? 0),
    courses: courseCode ? [courseCode] : [],
    recentAttendance: [],
  };
}

async function resolveCourse(identifier: string) {
  const courses = await apiClient.get<BackendCourse[]>("/courses");
  const normalized = groupDoctorCourses((courses || []).map(normalizeCourse));
  const target = identifier.trim().toLowerCase();

  return normalized.find(
    (course) =>
      String(course.id).toLowerCase() === target ||
      String(course.code || "").toLowerCase() === target ||
      course.courseIds.some((courseId) => String(courseId).toLowerCase() === target) ||
      course.course_ids.some((courseId) => String(courseId).toLowerCase() === target),
  );
}

async function fetchRosterByCourseId(courseId: string, fallbackCourseCode = "") {
  const response = await apiClient.get<BackendRosterResponse>(`/courses/${courseId}/students`);
  const courseCode = response.course?.code || fallbackCourseCode;

  return (response.students || []).map((student) =>
    normalizeRosterStudent(student, courseCode),
  );
}

function uniqueStudents(students: ManagedStudent[]) {
  const seen = new Set<string>();

  return students.filter((student) => {
    const key = student.id || student.universityId || student.email;
    if (seen.has(key)) {
      return false;
    }

    seen.add(key);
    return true;
  });
}

async function fetchRosterForCourse(course: NormalizedCourse, fallback = "") {
  const courseIds = course.courseIds.length > 0 ? course.courseIds : [course.id];
  const rosters = await Promise.all(
    courseIds.map((courseId) => fetchRosterByCourseId(String(courseId), rosterCourseCode(course, fallback))),
  );

  return uniqueStudents(rosters.flat());
}

function rosterCourseCode(course: NormalizedCourse | null, fallback = "") {
  return course?.code || fallback;
}

export async function getManagedStudentsForCourse(courseIdentifier: string, fallbackIdentifier = "") {
  if (USE_MOCKS) {
    return getMockManagedStudentsForCourse(fallbackIdentifier || courseIdentifier);
  }

  const primaryIdentifier = courseIdentifier.trim();
  const fallback = fallbackIdentifier.trim();

  if (/^\d+$/.test(primaryIdentifier)) {
    const course = await resolveCourse(primaryIdentifier);

    if (course) {
      return fetchRosterForCourse(course, fallback);
    }

    return fetchRosterByCourseId(primaryIdentifier, fallback);
  }

  const lookupIdentifier = fallback || primaryIdentifier;
  const course = lookupIdentifier ? await resolveCourse(lookupIdentifier) : null;

  if (!course) {
    throw new Error("Course not found.");
  }

  return fetchRosterForCourse(course, fallback);
}
