import {
  changeMockCurrentUserPassword,
  updateMockCurrentUserProfile,
} from "@/mocks/mockApi";
import { apiClient } from "@/services/apiClient";
import { mapLevelToBackend, normalizeUser, USE_MOCKS } from "@/services/authService";

type UpdateProfileInput = {
  name: string;
  email: string;
  major?: string;
  level?: string;
};

type ChangePasswordInput = {
  current_password: string;
  password: string;
  password_confirmation: string;
};

type ProfileResponse = {
  message?: string;
  user: Parameters<typeof normalizeUser>[0];
};

export const accountService = {
  async updateProfile(payload: UpdateProfileInput) {
    if (USE_MOCKS) {
      const response = await updateMockCurrentUserProfile(payload);
      return {
        ...response,
        user: normalizeUser(response.user as Parameters<typeof normalizeUser>[0]),
      };
    }

    const response = await apiClient.patch<ProfileResponse>("/me/profile", {
      name: payload.name,
      email: payload.email,
      ...(payload.major !== undefined ? { major: payload.major } : {}),
      ...(payload.level !== undefined ? { level: mapLevelToBackend(payload.level) } : {}),
    });

    return {
      ...response,
      user: normalizeUser(response.user),
    };
  },

  async changePassword(payload: ChangePasswordInput) {
    if (USE_MOCKS) {
      return changeMockCurrentUserPassword();
    }

    return apiClient.post<{ message: string }>("/me/change-password", payload);
  },
};
