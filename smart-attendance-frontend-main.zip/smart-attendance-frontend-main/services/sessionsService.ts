import {
  closeSession,
  createSession,
  deleteSession,
  getDoctorSessions,
  getSessionReport,
  markQrAttendanceForSession,
  mockUploadMultipart,
  openSession,
  updateSession,
} from "@/mocks/mockApi";
import { apiClient, ApiError } from "@/services/apiClient";
import { USE_MOCKS } from "@/services/authService";

type BackendSession = {
  id: number | string;
  session_ids?: Array<number | string> | null;
  session_group_key?: string | null;
  course_id?: number | string | null;
  course_ids?: Array<number | string> | null;
  course_name?: string | null;
  course_code?: string | null;
  departments?: string[] | null;
  levels?: string[] | null;
  level_labels?: string[] | null;
  course?: {
    id?: number | string | null;
    name?: string | null;
    code?: string | null;
    enrollments_count?: number | null;
  } | null;
  method?: "face" | "qr" | "both" | null;
  status?: string | null;
  is_open?: boolean | null;
  starts_at?: string | null;
  ends_at?: string | null;
  display_date?: string | null;
  display_start_time?: string | null;
  display_end_time?: string | null;
  present_count?: number | null;
  total_count?: number | null;
  records_count?: number | null;
};

type SessionEnvelope = {
  session?: BackendSession;
  data?: BackendSession[];
  students?: unknown[];
};

type FaceFile = { uri: string; name?: string | null; mimeType?: string | null };

type BackendMarkedStudent = {
  id: number | string;
  full_name?: string | null;
  name?: string | null;
  email?: string | null;
  university_code?: string | null;
  status?: string | null;
  attended_at?: string | null;
  method?: "face" | "qr" | null;
  match_score?: number | string | null;
  face_enrolled?: boolean | null;
};

type BackendAttendance = {
  id?: number | string;
  session_id?: number | string | null;
  method?: "face" | "qr" | null;
  status?: string | null;
  attended_at?: string | null;
  match_score?: number | string | null;
};

type MarkAttendanceResponse = {
  matched?: boolean;
  message?: string;
  student: BackendMarkedStudent;
  attendance?: BackendAttendance | null;
  data?: BackendAttendance | null;
  confidence?: number | string | null;
};

export function normalizeSession(session: BackendSession) {
  const courseId = session.course_id ?? session.course?.id ?? "";
  const courseIds = Array.isArray(session.course_ids) ? session.course_ids.map(String) : [String(courseId)];
  const sessionIds = Array.isArray(session.session_ids) ? session.session_ids.map(String) : [String(session.id)];
  const courseName = session.course_name || session.course?.name || "Session";
  const courseCode = session.course_code || session.course?.code || "N/A";
  const isOpen = Boolean(session.is_open ?? session.status === "open");
  const presentCount = Number(session.present_count ?? session.records_count ?? 0);
  const totalCount = Number(session.total_count ?? session.course?.enrollments_count ?? 0);

  return {
    ...session,
    id: String(session.id),
    session_ids: sessionIds,
    sessionIds,
    session_group_key: session.session_group_key || null,
    sessionGroupKey: session.session_group_key || null,
    course_id: courseId,
    courseId: String(courseId),
    course_ids: courseIds,
    courseIds,
    course_name: courseName,
    courseName,
    course_code: courseCode,
    courseCode,
    course: session.course || {
      id: courseId,
      name: courseName,
      code: courseCode,
      enrollments_count: totalCount,
    },
    method: session.method || "face",
    status: session.status || (isOpen ? "open" : "closed"),
    is_open: isOpen,
    isOpen,
    starts_at: session.starts_at || null,
    startsAt: session.starts_at || null,
    ends_at: session.ends_at || null,
    endsAt: session.ends_at || null,
    present_count: presentCount,
    presentCount,
    total_count: totalCount,
    totalCount,
    departments: Array.isArray(session.departments) ? session.departments : [],
    levels: Array.isArray(session.levels) ? session.levels.map(String) : [],
    level_labels: Array.isArray(session.level_labels) ? session.level_labels : [],
    levelLabels: Array.isArray(session.level_labels) ? session.level_labels : [],
  };
}

function unwrapSession(response: BackendSession | SessionEnvelope) {
  return normalizeSession("session" in response && response.session ? response.session : (response as BackendSession));
}

async function appendImage(formData: FormData, file: FaceFile) {
  const name = file.name || "face-capture.jpg";
  const type = file.mimeType || "image/jpeg";

  if (file.uri.startsWith("data:")) {
    const blob = await (await fetch(file.uri)).blob();
    formData.append("image", blob as any, name);
    return;
  }

  formData.append("image", {
    uri: file.uri,
    name,
    type,
  } as any);
}

function normalizeAttendanceError(error: unknown) {
  if (error instanceof ApiError) {
    if (error.status === 409) {
      return new Error(error.message || "Attendance already recorded for this student in this session.");
    }

    if (error.status === 400 && /closed/i.test(error.message)) {
      return new Error("This session is closed. Open the session before marking attendance.");
    }

    if (error.status === 503) {
      return new Error(error.message || "Face verification service is unavailable.");
    }
  }

  return error;
}

function normalizeMarkAttendanceResponse(
  response: MarkAttendanceResponse,
  fallbackMethod: "face" | "qr",
) {
  const attendance = response.attendance || response.data || null;
  const attendedAt =
    attendance?.attended_at ||
    response.student.attended_at ||
    new Date().toISOString();
  const method = attendance?.method || response.student.method || fallbackMethod;
  const status = attendance?.status || response.student.status || "present";
  const matchScore =
    attendance?.match_score ??
    response.student.match_score ??
    response.confidence ??
    null;

  return {
    ...response,
    matched: response.matched ?? true,
    student: {
      ...response.student,
      id: response.student.id,
      full_name: response.student.full_name || response.student.name || "Student",
      name: response.student.name || response.student.full_name || "Student",
      university_code: response.student.university_code || "",
      status,
      attended_at: attendedAt,
      method,
      match_score: matchScore,
    },
    attendance,
    data: {
      ...(attendance || {}),
      attended_at: attendedAt,
      method,
      status,
      match_score: matchScore,
    },
    confidence:
      response.confidence === null || response.confidence === undefined
        ? matchScore
        : response.confidence,
  };
}

export const sessionsService = {
  async getSessions() {
    if (!USE_MOCKS) {
      const response = await apiClient.get<{ data?: BackendSession[] } | BackendSession[]>("/sessions");
      const sessions = Array.isArray(response) ? response : response.data || [];
      return sessions.map(normalizeSession);
    }

    return getDoctorSessions();
  },
  async createSession(payload: {
    course_id: number;
    method: "face" | "qr" | "both";
    starts_at?: string | null;
    ends_at?: string | null;
    session_group_key?: string | null;
  }) {
    if (!USE_MOCKS) {
      const response = await apiClient.post<SessionEnvelope>("/sessions", payload);
      return unwrapSession(response);
    }

    return createSession(payload);
  },
  async openSession(sessionId: number) {
    if (!USE_MOCKS) {
      const response = await apiClient.post<SessionEnvelope>(`/sessions/${sessionId}/open`);
      return unwrapSession(response);
    }

    return openSession(sessionId);
  },
  async closeSession(sessionId: number) {
    if (!USE_MOCKS) {
      const response = await apiClient.post<SessionEnvelope>(`/sessions/${sessionId}/close`);
      return unwrapSession(response);
    }

    return closeSession(sessionId);
  },
  async updateSession(
    sessionId: number,
    payload: {
      method: "face" | "qr" | "both";
      starts_at?: string | null;
      ends_at?: string | null;
    },
  ) {
    if (!USE_MOCKS) {
      const response = await apiClient.patch<SessionEnvelope>(`/sessions/${sessionId}`, payload);
      return unwrapSession(response);
    }

    return updateSession(sessionId, payload);
  },
  async deleteSession(sessionId: number) {
    if (!USE_MOCKS) {
      return apiClient.del<{ message?: string }>(`/sessions/${sessionId}`);
    }

    return deleteSession(sessionId);
  },
  async getSessionReport(sessionId: number) {
    if (!USE_MOCKS) {
      const response = await apiClient.get<SessionEnvelope>(`/sessions/${sessionId}/report`);
      return {
        ...response,
        session: response.session ? normalizeSession(response.session) : null,
        students: response.students || [],
      };
    }

    return getSessionReport(sessionId);
  },
  async markQrAttendance(sessionId: number, payload: { qr_payload: string }) {
    if (!USE_MOCKS) {
      try {
        const response = await apiClient.post<MarkAttendanceResponse>("/qr/scan", {
          session_id: sessionId,
          qr_payload: payload.qr_payload,
        });

        return normalizeMarkAttendanceResponse(response, "qr");
      } catch (error) {
        throw normalizeAttendanceError(error);
      }
    }

    const response = await markQrAttendanceForSession(sessionId, payload);
    return normalizeMarkAttendanceResponse(response, "qr");
  },
  async markFaceAttendance(
    sessionId: number,
    file: FaceFile,
  ) {
    if (!USE_MOCKS) {
      const formData = new FormData();
      formData.append("session_id", String(sessionId));
      await appendImage(formData, file);

      try {
        const response = await apiClient.post<MarkAttendanceResponse>(
          "/face/verify-and-mark",
          formData,
          { timeoutMs: 20000 },
        );

        return normalizeMarkAttendanceResponse(response, "face");
      } catch (error) {
        throw normalizeAttendanceError(error);
      }
    }

    const response = await mockUploadMultipart<MarkAttendanceResponse>(
      `mark-face-attendance:${sessionId}`,
      file,
    );
    return normalizeMarkAttendanceResponse(response, "face");
  },
};
