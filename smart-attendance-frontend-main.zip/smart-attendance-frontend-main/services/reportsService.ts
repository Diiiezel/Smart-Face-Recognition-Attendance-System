import { getCourseReport, getReportsOverview } from "@/mocks/mockApi";
import { apiClient } from "@/services/apiClient";
import { USE_MOCKS } from "@/services/authService";

type BackendReportsOverview = {
  totals?: {
    average_attendance_rate?: number | string | null;
    courses_count?: number | string | null;
    sessions_count?: number | string | null;
    students_count?: number | string | null;
  };
  trend?: Array<{
    label?: string | null;
    date?: string | null;
    attendance_rate?: number | string | null;
  }>;
  courses?: Array<{
    id: number | string;
    code?: string | null;
    name?: string | null;
    total_students?: number | string | null;
    sessions_count?: number | string | null;
    attendance_rate?: number | string | null;
  }>;
  sessions?: unknown[];
};

function normalizeReportsOverview(payload: BackendReportsOverview) {
  return {
    ...payload,
    totals: {
      average_attendance_rate: Number(payload.totals?.average_attendance_rate ?? 0),
      courses_count: Number(payload.totals?.courses_count ?? 0),
      sessions_count: Number(payload.totals?.sessions_count ?? 0),
      students_count: Number(payload.totals?.students_count ?? 0),
    },
    trend: (payload.trend || []).map((item) => ({
      label: item.label || "",
      date: item.date || "",
      attendance_rate: Number(item.attendance_rate ?? 0),
    })),
    courses: (payload.courses || []).map((course) => ({
      id: String(course.id),
      code: course.code || "N/A",
      name: course.name || "Course",
      total_students: Number(course.total_students ?? 0),
      sessions_count: Number(course.sessions_count ?? 0),
      attendance_rate: Number(course.attendance_rate ?? 0),
    })),
    sessions: payload.sessions || [],
  };
}

export const reportsService = {
  async getReports() {
    if (!USE_MOCKS) {
      const response = await apiClient.get<BackendReportsOverview>("/reports/overview");
      return normalizeReportsOverview(response);
    }

    return getReportsOverview();
  },
  async getCourseReport() {
    // TODO: replace mock reports data with backend reports API
    return getCourseReport();
  },
};
