import React from "react";
import {
  ActivityIndicator,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
  ViewStyle,
} from "react-native";
import { useColors } from "@/hooks/useColors";

interface CardProps {
  children: React.ReactNode;
  style?: ViewStyle;
  onPress?: () => void;
  elevated?: boolean;
}

export function Card({ children, style, onPress, elevated = true }: CardProps) {
  const colors = useColors();
  const cardStyle = [
    styles.card,
    {
      backgroundColor: colors.card,
      borderColor: colors.border,
      borderRadius: 20,
      borderWidth: 1,
    },
    elevated && styles.raised,
    style,
  ];

  if (onPress) {
    return (
      <Pressable
        onPress={onPress}
        style={({ pressed, hovered }) => [
          cardStyle,
          styles.pressable,
          hovered && styles.hovered,
          pressed && styles.pressed,
        ]}
      >
        {children}
      </Pressable>
    );
  }

  return <View style={cardStyle}>{children}</View>;
}

interface ButtonProps {
  title: string;
  onPress: () => void;
  variant?: "primary" | "secondary" | "outline" | "ghost" | "danger";
  loading?: boolean;
  disabled?: boolean;
  fullWidth?: boolean;
  size?: "sm" | "md" | "lg";
  style?: ViewStyle;
}

export function Button({
  title,
  onPress,
  variant = "primary",
  loading = false,
  disabled = false,
  fullWidth = true,
  size = "md",
  style,
}: ButtonProps) {
  const colors = useColors();

  const bgMap: Record<string, string> = {
    primary: colors.primary,
    secondary: colors.secondary,
    outline: "transparent",
    ghost: "transparent",
    danger: colors.destructive,
  };

  const textMap: Record<string, string> = {
    primary: colors.primaryForeground,
    secondary: colors.secondaryForeground,
    outline: colors.primary,
    ghost: colors.foreground,
    danger: colors.destructiveForeground,
  };

  const borderColorMap: Record<string, string> = {
    primary: colors.primary,
    secondary: colors.border,
    outline: colors.border,
    ghost: "transparent",
    danger: colors.destructive,
  };

  const paddingMap: Record<string, number> = { sm: 10, md: 12, lg: 15 };
  const fontSizeMap: Record<string, number> = { sm: 13, md: 14, lg: 15 };

  return (
    <Pressable
      onPress={onPress}
      disabled={disabled || loading}
      style={({ pressed, hovered }) => [
        styles.button,
        {
          backgroundColor: bgMap[variant],
          borderColor: borderColorMap[variant],
          opacity: disabled || loading ? 0.55 : pressed ? 0.86 : 1,
          paddingVertical: paddingMap[size],
        },
        fullWidth && { width: "100%" },
        hovered && !disabled && !loading && styles.buttonHover,
        pressed && !disabled && !loading && styles.buttonPressed,
        style,
      ]}
    >
      {loading ? (
        <ActivityIndicator color={textMap[variant]} size="small" />
      ) : (
        <Text
          style={{
            color: textMap[variant],
            fontFamily: "Inter_600SemiBold",
            fontSize: fontSizeMap[size],
            fontWeight: "600",
            letterSpacing: 0.1,
          }}
        >
          {title}
        </Text>
      )}
    </Pressable>
  );
}

interface InputFieldProps {
  label?: string;
  placeholder?: string;
  value: string;
  onChangeText: (v: string) => void;
  secureTextEntry?: boolean;
  keyboardType?: "default" | "email-address" | "numeric";
  autoCapitalize?: "none" | "sentences" | "words" | "characters";
  icon?: React.ReactNode;
  rightElement?: React.ReactNode;
  error?: string;
  editable?: boolean;
}

interface SelectionOption {
  label: string;
  value: string;
}

export function InputField({
  label,
  placeholder,
  value,
  onChangeText,
  secureTextEntry,
  keyboardType = "default",
  autoCapitalize = "sentences",
  icon,
  rightElement,
  error,
  editable = true,
}: InputFieldProps) {
  const colors = useColors();

  return (
    <View style={styles.fieldStack}>
      {label ? (
        <Text style={[styles.label, { color: colors.foreground }]}>{label}</Text>
      ) : null}
      <View
        style={[
          styles.inputShell,
          {
            backgroundColor: colors.card,
            borderColor: error ? colors.destructive : colors.border,
          },
        ]}
      >
        {icon}
        <TextInput
          style={[
            styles.input,
            {
              color: colors.foreground,
              outlineStyle: "none",
            } as any,
          ]}
          placeholder={placeholder}
          placeholderTextColor={colors.mutedForeground}
          value={value}
          onChangeText={onChangeText}
          secureTextEntry={secureTextEntry}
          keyboardType={keyboardType}
          autoCapitalize={autoCapitalize}
          editable={editable}
        />
        {rightElement}
      </View>
      {error ? (
        <Text style={[styles.errorText, { color: colors.destructive }]}>{error}</Text>
      ) : null}
    </View>
  );
}

interface SelectionFieldProps {
  label?: string;
  value?: string;
  placeholder?: string;
  options: SelectionOption[];
  onSelect: (value: string) => void;
  icon?: React.ReactNode;
  error?: string;
  multiSelect?: boolean;
  selectedValues?: string[];
}

export function SelectionField({
  label,
  value,
  placeholder,
  options,
  onSelect,
  icon,
  error,
  multiSelect = false,
  selectedValues = [],
}: SelectionFieldProps) {
  const colors = useColors();
  const selectedSet = new Set(selectedValues);
  const displayValue = multiSelect
    ? selectedValues.length > 0
      ? `${selectedValues.length} selected`
      : placeholder
    : value || placeholder;

  return (
    <View style={styles.fieldStack}>
      {label ? (
        <Text style={[styles.label, { color: colors.foreground }]}>{label}</Text>
      ) : null}
      <View
        style={[
          styles.selectionShell,
          {
            backgroundColor: colors.card,
            borderColor: error ? colors.destructive : colors.border,
          },
        ]}
      >
        <View style={styles.selectionValueRow}>
          {icon}
          <Text
            style={[
              styles.selectionValue,
              { color: displayValue ? colors.foreground : colors.mutedForeground },
            ]}
          >
            {displayValue}
          </Text>
        </View>
        <View style={styles.optionWrap}>
          {options.map((option) => {
            const isSelected = multiSelect
              ? selectedSet.has(option.value)
              : value === option.value;

            return (
              <Pressable
                key={option.value}
                onPress={() => onSelect(option.value)}
                style={({ pressed, hovered }) => [
                  styles.optionChip,
                  {
                    backgroundColor: isSelected ? colors.secondary : colors.background,
                    borderColor: isSelected ? colors.primary : colors.border,
                    opacity: pressed ? 0.84 : 1,
                  },
                  hovered && styles.optionHover,
                ]}
              >
                <Text
                  style={[
                    styles.optionLabel,
                    {
                      color: isSelected ? colors.primary : colors.foreground,
                      fontFamily: isSelected ? "Inter_600SemiBold" : "Inter_500Medium",
                    },
                  ]}
                >
                  {option.label}
                </Text>
              </Pressable>
            );
          })}
        </View>
      </View>
      {error ? (
        <Text style={[styles.errorText, { color: colors.destructive }]}>{error}</Text>
      ) : null}
    </View>
  );
}

interface BadgeProps {
  label: string;
  variant?: "success" | "danger" | "warning" | "primary" | "muted";
}

export function Badge({ label, variant = "primary" }: BadgeProps) {
  const colors = useColors();
  const bgMap: Record<string, string> = {
    success: "#DCFCE7",
    danger: "#FEE2E2",
    warning: "#FEF3C7",
    primary: colors.secondary,
    muted: colors.muted,
  };
  const textColorMap: Record<string, string> = {
    success: "#15803D",
    danger: "#B91C1C",
    warning: "#B45309",
    primary: colors.primary,
    muted: colors.mutedForeground,
  };

  return (
    <View style={[styles.badge, { backgroundColor: bgMap[variant] }]}>
      <Text style={[styles.badgeText, { color: textColorMap[variant] }]}>{label}</Text>
    </View>
  );
}

interface SectionHeaderProps {
  title: string;
  action?: string;
  onAction?: () => void;
}

export function SectionHeader({ title, action, onAction }: SectionHeaderProps) {
  const colors = useColors();

  return (
    <View style={styles.sectionHeader}>
      <Text style={[styles.sectionTitle, { color: colors.foreground }]}>{title}</Text>
      {action ? (
        <Pressable
          onPress={onAction}
          style={({ pressed, hovered }) => [
            styles.sectionAction,
            hovered && { backgroundColor: colors.secondary },
            pressed && { opacity: 0.75 },
          ]}
        >
          <Text style={[styles.sectionActionText, { color: colors.primary }]}>{action}</Text>
        </Pressable>
      ) : null}
    </View>
  );
}

interface StatCardProps {
  label: string;
  value: string | number;
  icon: React.ReactNode;
  color: string;
  bgColor: string;
  onPress?: () => void;
}

export function StatCard({
  label,
  value,
  icon,
  color,
  bgColor,
  onPress,
}: StatCardProps) {
  const colors = useColors();

  return (
    <Card style={styles.statCard} onPress={onPress}>
      <View style={[styles.statIcon, { backgroundColor: bgColor }]}>{icon}</View>
      <Text style={[styles.statValue, { color }]}>{value}</Text>
      <Text style={[styles.statLabel, { color: colors.mutedForeground }]}>{label}</Text>
    </Card>
  );
}

const styles = StyleSheet.create({
  badge: {
    alignSelf: "flex-start",
    borderRadius: 999,
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  badgeText: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 11,
    fontWeight: "600",
    letterSpacing: 0.2,
  },
  button: {
    alignItems: "center",
    borderRadius: 12,
    borderWidth: 1,
    flexDirection: "row",
    gap: 8,
    justifyContent: "center",
    paddingHorizontal: 22,
  },
  buttonHover: {
    boxShadow: "0 4px 14px rgba(13, 27, 62, 0.08)",
  } as any,
  buttonPressed: {
    transform: [{ translateY: 1 }],
  },
  card: {
    padding: 20,
  },
  errorText: {
    fontFamily: "Inter_400Regular",
    fontSize: 12,
  },
  fieldStack: {
    gap: 8,
  },
  hovered: {
    borderColor: "#D5DCEB",
    transform: [{ translateY: -1 }],
  },
  input: {
    flex: 1,
    fontFamily: "Inter_400Regular",
    fontSize: 15,
    minHeight: 24,
  },
  inputShell: {
    alignItems: "center",
    borderRadius: 14,
    borderWidth: 1,
    flexDirection: "row",
    gap: 10,
    paddingHorizontal: 14,
    paddingVertical: 13,
  },
  label: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 13,
    fontWeight: "600",
    letterSpacing: 0.1,
  },
  optionChip: {
    borderRadius: 999,
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingVertical: 10,
  },
  optionHover: {
    transform: [{ translateY: -1 }],
  },
  optionLabel: {
    fontSize: 12,
  },
  optionWrap: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
  },
  pressable: {
    cursor: "pointer",
  } as any,
  pressed: {
    opacity: 0.94,
    transform: [{ scale: 0.99 }],
  },
  raised: {
    boxShadow: "0 10px 24px rgba(13, 27, 62, 0.06)",
  } as any,
  sectionAction: {
    borderRadius: 999,
    paddingHorizontal: 10,
    paddingVertical: 6,
  },
  sectionActionText: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 13,
    fontWeight: "600",
  },
  sectionHeader: {
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 14,
  },
  sectionTitle: {
    fontFamily: "Inter_700Bold",
    fontSize: 18,
    fontWeight: "700",
    letterSpacing: -0.2,
  },
  selectionShell: {
    borderRadius: 14,
    borderWidth: 1,
    gap: 12,
    paddingHorizontal: 14,
    paddingVertical: 14,
  },
  selectionValue: {
    flex: 1,
    fontFamily: "Inter_400Regular",
    fontSize: 15,
  },
  selectionValueRow: {
    alignItems: "center",
    flexDirection: "row",
    gap: 10,
  },
  statCard: {
    flex: 1,
    minWidth: 160,
    padding: 18,
  },
  statIcon: {
    alignItems: "center",
    borderRadius: 12,
    height: 40,
    justifyContent: "center",
    marginBottom: 12,
    width: 40,
  },
  statLabel: {
    fontFamily: "Inter_500Medium",
    fontSize: 12,
    marginTop: 4,
  },
  statValue: {
    fontFamily: "Inter_700Bold",
    fontSize: 28,
    fontWeight: "700",
    letterSpacing: -0.6,
  },
});
