import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import React from "react";
import { Platform, Pressable, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/useColors";

interface ScreenHeaderProps {
  title: string;
  subtitle?: string;
  showBack?: boolean;
  rightElement?: React.ReactNode;
  dark?: boolean;
}

export function ScreenHeader({
  title,
  subtitle,
  showBack = false,
  rightElement,
  dark = false,
}: ScreenHeaderProps) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const topPad = Platform.OS === "web" ? 67 : insets.top;

  return (
    <View
      style={{
        paddingTop: topPad + 10,
        paddingBottom: 14,
        paddingHorizontal: 20,
        backgroundColor: dark ? colors.navy : colors.card,
        borderBottomWidth: dark ? 0 : 1,
        borderBottomColor: colors.border,
        flexDirection: "row",
        alignItems: "center",
        gap: 12,
      }}
    >
      {showBack && (
        <Pressable
          onPress={() => router.back()}
          style={{
            width: 34,
            height: 34,
            borderRadius: 10,
            backgroundColor: dark ? "rgba(255,255,255,0.1)" : colors.muted,
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Ionicons
            name="chevron-back"
            size={18}
            color={dark ? "#FFF" : colors.foreground}
          />
        </Pressable>
      )}
      <View style={{ flex: 1 }}>
        <Text
          style={{
            fontSize: 18,
            fontWeight: "700",
            color: dark ? "#FFFFFF" : colors.foreground,
            fontFamily: "Inter_700Bold",
            letterSpacing: -0.3,
          }}
        >
          {title}
        </Text>
        {subtitle ? (
          <Text
            style={{
              fontSize: 12,
              color: dark ? "rgba(255,255,255,0.6)" : colors.mutedForeground,
              marginTop: 1,
              fontFamily: "Inter_400Regular",
            }}
          >
            {subtitle}
          </Text>
        ) : null}
      </View>
      {rightElement}
    </View>
  );
}
