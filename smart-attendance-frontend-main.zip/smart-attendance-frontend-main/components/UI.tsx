import React from "react";
import {
  ActivityIndicator,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
  ViewStyle,
} from "react-native";
import { useColors } from "@/hooks/useColors";

interface CardProps {
  children: React.ReactNode;
  style?: ViewStyle;
  onPress?: () => void;
  elevated?: boolean;
}

export function Card({ children, style, onPress, elevated = true }: CardProps) {
  const colors = useColors();
  const cardStyle = [
    styles.card,
    {
      backgroundColor: colors.card,
      borderRadius: colors.radius,
      borderWidth: 1,
      borderColor: colors.border,
    },
    elevated && {
      shadowColor: "#0D1B3E",
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.06,
      shadowRadius: 10,
      elevation: 3,
    },
    style,
  ];

  if (onPress) {
    return (
      <Pressable
        style={({ pressed }) => [
          cardStyle,
          pressed && { opacity: 0.94, transform: [{ scale: 0.985 }] },
        ]}
        onPress={onPress}
      >
        {children}
      </Pressable>
    );
  }
  return <View style={cardStyle}>{children}</View>;
}

interface ButtonProps {
  title: string;
  onPress: () => void;
  variant?: "primary" | "secondary" | "outline" | "ghost" | "danger";
  loading?: boolean;
  disabled?: boolean;
  fullWidth?: boolean;
  size?: "sm" | "md" | "lg";
  style?: ViewStyle;
}

export function Button({
  title,
  onPress,
  variant = "primary",
  loading = false,
  disabled = false,
  fullWidth = true,
  size = "md",
  style,
}: ButtonProps) {
  const colors = useColors();

  const bgMap: Record<string, string> = {
    primary: colors.primary,
    secondary: colors.secondary,
    outline: "transparent",
    ghost: "transparent",
    danger: colors.destructive,
  };

  const textMap: Record<string, string> = {
    primary: colors.primaryForeground,
    secondary: colors.secondaryForeground,
    outline: colors.primary,
    ghost: colors.foreground,
    danger: colors.destructiveForeground,
  };

  const paddingMap: Record<string, number> = { sm: 11, md: 14, lg: 17 };
  const fontSizeMap: Record<string, number> = { sm: 13, md: 14, lg: 15 };

  return (
    <Pressable
      onPress={onPress}
      disabled={disabled || loading}
      style={({ pressed }) => [
        {
          backgroundColor: bgMap[variant],
          borderRadius: colors.radius,
          paddingVertical: paddingMap[size],
          paddingHorizontal: 22,
          alignItems: "center" as const,
          justifyContent: "center" as const,
          flexDirection: "row" as const,
          gap: 8,
          borderWidth: variant === "outline" ? 1.5 : 0,
          borderColor: variant === "outline" ? colors.primary : "transparent",
          opacity: disabled || loading ? 0.55 : pressed ? 0.86 : 1,
          transform: [{ scale: pressed ? 0.975 : 1 }],
        },
        fullWidth && { width: "100%" },
        style,
      ]}
    >
      {loading ? (
        <ActivityIndicator color={textMap[variant]} size="small" />
      ) : (
        <Text
          style={{
            color: textMap[variant],
            fontSize: fontSizeMap[size],
            fontWeight: "600",
            fontFamily: "Inter_600SemiBold",
            letterSpacing: 0.2,
          }}
        >
          {title}
        </Text>
      )}
    </Pressable>
  );
}

interface InputFieldProps {
  label?: string;
  placeholder?: string;
  value: string;
  onChangeText: (v: string) => void;
  secureTextEntry?: boolean;
  keyboardType?: "default" | "email-address" | "numeric";
  autoCapitalize?: "none" | "sentences" | "words" | "characters";
  icon?: React.ReactNode;
  rightElement?: React.ReactNode;
  error?: string;
  editable?: boolean;
}

interface SelectionOption {
  label: string;
  value: string;
}

export function InputField({
  label,
  placeholder,
  value,
  onChangeText,
  secureTextEntry,
  keyboardType = "default",
  autoCapitalize = "sentences",
  icon,
  rightElement,
  error,
  editable = true,
}: InputFieldProps) {
  const colors = useColors();
  return (
    <View style={{ gap: 7 }}>
      {label ? (
        <Text
          style={{
            fontSize: 13,
            fontWeight: "600",
            color: colors.foreground,
            fontFamily: "Inter_600SemiBold",
            letterSpacing: 0.1,
          }}
        >
          {label}
        </Text>
      ) : null}
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          backgroundColor: colors.muted,
          borderRadius: colors.radius,
          borderWidth: 1.5,
          borderColor: error ? colors.destructive : "transparent",
          paddingHorizontal: 14,
          paddingVertical: Platform.OS === "ios" ? 15 : 13,
          gap: 10,
        }}
      >
        {icon}
        <TextInput
          style={{
            flex: 1,
            fontSize: 15,
            color: colors.foreground,
            fontFamily: "Inter_400Regular",
          }}
          placeholder={placeholder}
          placeholderTextColor={colors.mutedForeground}
          value={value}
          onChangeText={onChangeText}
          secureTextEntry={secureTextEntry}
          keyboardType={keyboardType}
          autoCapitalize={autoCapitalize}
          editable={editable}
        />
        {rightElement}
      </View>
      {error ? (
        <Text
          style={{
            fontSize: 12,
            color: colors.destructive,
            fontFamily: "Inter_400Regular",
          }}
        >
          {error}
        </Text>
      ) : null}
    </View>
  );
}

interface SelectionFieldProps {
  label?: string;
  value?: string;
  placeholder?: string;
  options: SelectionOption[];
  onSelect: (value: string) => void;
  icon?: React.ReactNode;
  error?: string;
  multiSelect?: boolean;
  selectedValues?: string[];
}

export function SelectionField({
  label,
  value,
  placeholder,
  options,
  onSelect,
  icon,
  error,
  multiSelect = false,
  selectedValues = [],
}: SelectionFieldProps) {
  const colors = useColors();
  const selectedSet = new Set(selectedValues);
  const displayValue =
    multiSelect
      ? selectedValues.length > 0
        ? `${selectedValues.length} selected`
        : placeholder
      : value || placeholder;

  return (
    <View style={{ gap: 7 }}>
      {label ? (
        <Text
          style={{
            fontSize: 13,
            fontWeight: "600",
            color: colors.foreground,
            fontFamily: "Inter_600SemiBold",
            letterSpacing: 0.1,
          }}
        >
          {label}
        </Text>
      ) : null}
      <View
        style={{
          backgroundColor: colors.muted,
          borderRadius: colors.radius,
          borderWidth: 1.5,
          borderColor: error ? colors.destructive : "transparent",
          paddingHorizontal: 14,
          paddingVertical: 14,
          gap: 12,
        }}
      >
        <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
          {icon}
          <Text
            style={{
              flex: 1,
              fontSize: 15,
              color: displayValue ? colors.foreground : colors.mutedForeground,
              fontFamily: "Inter_400Regular",
            }}
          >
            {displayValue}
          </Text>
        </View>
        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 10 }}>
          {options.map((option) => {
            const isSelected = multiSelect
              ? selectedSet.has(option.value)
              : value === option.value;

            return (
              <Pressable
                key={option.value}
                onPress={() => onSelect(option.value)}
                style={({ pressed }) => [
                  {
                    paddingHorizontal: 14,
                    paddingVertical: 10,
                    borderRadius: 999,
                    borderWidth: 1,
                    borderColor: isSelected ? colors.primary : colors.border,
                    backgroundColor: isSelected ? "#DBEAFE" : colors.card,
                    opacity: pressed ? 0.9 : 1,
                  },
                ]}
              >
                <Text
                  style={{
                    color: isSelected ? colors.primary : colors.foreground,
                    fontSize: 12,
                    fontFamily: isSelected ? "Inter_600SemiBold" : "Inter_500Medium",
                  }}
                >
                  {option.label}
                </Text>
              </Pressable>
            );
          })}
        </View>
      </View>
      {error ? (
        <Text
          style={{
            fontSize: 12,
            color: colors.destructive,
            fontFamily: "Inter_400Regular",
          }}
        >
          {error}
        </Text>
      ) : null}
    </View>
  );
}

interface BadgeProps {
  label: string;
  variant?: "success" | "danger" | "warning" | "primary" | "muted";
}

export function Badge({ label, variant = "primary" }: BadgeProps) {
  const colors = useColors();
  const bgMap: Record<string, string> = {
    success: "#DCFCE7",
    danger: "#FEE2E2",
    warning: "#FEF3C7",
    primary: "#DBEAFE",
    muted: colors.muted,
  };
  const textColorMap: Record<string, string> = {
    success: "#15803D",
    danger: "#B91C1C",
    warning: "#B45309",
    primary: "#1D4ED8",
    muted: colors.mutedForeground,
  };
  return (
    <View
      style={{
        backgroundColor: bgMap[variant],
        borderRadius: 100,
        paddingHorizontal: 10,
        paddingVertical: 4,
        alignSelf: "flex-start",
      }}
    >
      <Text
        style={{
          fontSize: 11,
          fontWeight: "600",
          color: textColorMap[variant],
          fontFamily: "Inter_600SemiBold",
          letterSpacing: 0.2,
        }}
      >
        {label}
      </Text>
    </View>
  );
}

interface SectionHeaderProps {
  title: string;
  action?: string;
  onAction?: () => void;
}

export function SectionHeader({ title, action, onAction }: SectionHeaderProps) {
  const colors = useColors();
  return (
    <View
      style={{
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        marginBottom: 14,
      }}
    >
      <Text
        style={{
          fontSize: 16,
          fontWeight: "700",
          color: colors.foreground,
          fontFamily: "Inter_700Bold",
          letterSpacing: -0.2,
        }}
      >
        {title}
      </Text>
      {action ? (
        <Pressable onPress={onAction}>
          <Text
            style={{
              fontSize: 13,
              color: colors.primary,
              fontWeight: "600",
              fontFamily: "Inter_600SemiBold",
            }}
          >
            {action}
          </Text>
        </Pressable>
      ) : null}
    </View>
  );
}

interface StatCardProps {
  label: string;
  value: string | number;
  icon: React.ReactNode;
  color: string;
  bgColor: string;
  onPress?: () => void;
}

export function StatCard({
  label,
  value,
  icon,
  color,
  bgColor,
  onPress,
}: StatCardProps) {
  const colors = useColors();
  return (
    <Card style={{ flex: 1, padding: 14 }} onPress={onPress}>
      <View
        style={{
          width: 36,
          height: 36,
          borderRadius: 10,
          backgroundColor: bgColor,
          alignItems: "center",
          justifyContent: "center",
          marginBottom: 10,
        }}
      >
        {icon}
      </View>
      <Text
        style={{
          fontSize: 22,
          fontWeight: "700",
          color,
          fontFamily: "Inter_700Bold",
          letterSpacing: -0.5,
        }}
      >
        {value}
      </Text>
      <Text
        style={{
          fontSize: 11,
          color: colors.mutedForeground,
          marginTop: 3,
          fontFamily: "Inter_500Medium",
        }}
      >
        {label}
      </Text>
    </Card>
  );
}

const styles = StyleSheet.create({
  card: {
    padding: 16,
  },
});
