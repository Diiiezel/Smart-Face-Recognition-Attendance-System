import { Button, Card, InputField, SelectionField } from "@/components/UI";
import { useApp, useAppErrorMessage } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { LEVEL_OPTIONS, MAJOR_OPTIONS } from "@/mocks/academicOptions";
import React, { useEffect, useState } from "react";
import { StyleSheet, Text, View } from "react-native";

type Props = {
  mode: "student" | "staff";
};

type ActiveForm = "profile" | "password" | null;

const LEVEL_BY_NUMBER: Record<string, string> = {
  "1": "First Year",
  "2": "Second Year",
  "3": "Third Year",
  "4": "Fourth Year",
};

function normalizeLevelValue(value?: string | null) {
  if (!value) return "";
  return LEVEL_BY_NUMBER[value] || value;
}

export function AccountSettingsCard({ mode }: Props) {
  const colors = useColors();
  const errorMessage = useAppErrorMessage;
  const {
    studentProfile,
    staffProfile,
    updateProfile,
    changePassword,
    isLoading,
  } = useApp();
  const profile = mode === "student" ? studentProfile : staffProfile;
  const [activeForm, setActiveForm] = useState<ActiveForm>(null);
  const [name, setName] = useState(profile?.name || "");
  const [email, setEmail] = useState(profile?.email || "");
  const [major, setMajor] = useState(studentProfile?.department || "");
  const [level, setLevel] = useState(normalizeLevelValue(studentProfile?.level));
  const [profileMessage, setProfileMessage] = useState("");
  const [profileError, setProfileError] = useState("");
  const [currentPassword, setCurrentPassword] = useState("");
  const [password, setPassword] = useState("");
  const [passwordConfirmation, setPasswordConfirmation] = useState("");
  const [passwordMessage, setPasswordMessage] = useState("");
  const [passwordError, setPasswordError] = useState("");

  useEffect(() => {
    setName(profile?.name || "");
    setEmail(profile?.email || "");
    setMajor(studentProfile?.department || "");
    setLevel(normalizeLevelValue(studentProfile?.level));
  }, [profile?.email, profile?.name, studentProfile?.department, studentProfile?.level]);

  const toggleForm = (form: ActiveForm) => {
    setProfileError("");
    setPasswordError("");
    setActiveForm((current) => (current === form ? null : form));
  };

  const saveProfile = async () => {
    setProfileError("");
    setProfileMessage("");
    setPasswordMessage("");

    try {
      await updateProfile({
        name: name.trim(),
        email: email.trim(),
        ...(mode === "student"
          ? {
              major: major.trim(),
              level: level.trim(),
            }
          : {}),
      });
      setActiveForm(null);
      setProfileMessage("Profile updated successfully.");
    } catch (error) {
      setProfileError(errorMessage(error));
    }
  };

  const submitPassword = async () => {
    setPasswordError("");
    setPasswordMessage("");
    setProfileMessage("");

    if (password !== passwordConfirmation) {
      setPasswordError("Password confirmation does not match.");
      return;
    }

    try {
      await changePassword({
        currentPassword,
        password,
        passwordConfirmation,
      });
      setCurrentPassword("");
      setPassword("");
      setPasswordConfirmation("");
      setActiveForm(null);
      setPasswordMessage("Password changed successfully.");
    } catch (error) {
      setPasswordError(errorMessage(error));
    }
  };

  if (!profile) return null;

  return (
    <Card style={styles.card}>
      <View style={styles.headerBlock}>
        <Text style={[styles.title, { color: colors.foreground }]}>Account actions</Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
          Profile and password changes are saved to your account.
        </Text>
      </View>

      <View style={styles.actionRow}>
        <Button
          title={activeForm === "profile" ? "Close Edit" : "Edit Profile"}
          onPress={() => toggleForm("profile")}
          variant={activeForm === "profile" ? "secondary" : "outline"}
          size="sm"
          fullWidth={false}
          style={styles.actionButton}
        />
        <Button
          title={activeForm === "password" ? "Close Password" : "Change Password"}
          onPress={() => toggleForm("password")}
          variant={activeForm === "password" ? "secondary" : "outline"}
          size="sm"
          fullWidth={false}
          style={styles.actionButton}
        />
      </View>

      {profileMessage ? <Text style={styles.success}>{profileMessage}</Text> : null}
      {passwordMessage ? <Text style={styles.success}>{passwordMessage}</Text> : null}

      {activeForm === "profile" ? (
        <View style={styles.form}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Edit profile</Text>
          <InputField label="Name" value={name} onChangeText={setName} placeholder="Full name" />
          <InputField
            label="Email"
            value={email}
            onChangeText={setEmail}
            placeholder="email@example.com"
            keyboardType="email-address"
            autoCapitalize="none"
          />
          {mode === "student" ? (
            <>
              <SelectionField
                label="Major"
                value={major}
                placeholder="Select major"
                options={[...MAJOR_OPTIONS]}
                onSelect={setMajor}
              />
              <SelectionField
                label="Level"
                value={level}
                placeholder="Select level"
                options={[...LEVEL_OPTIONS]}
                onSelect={setLevel}
              />
            </>
          ) : null}
          {profileError ? <Text style={[styles.error, { color: colors.destructive }]}>{profileError}</Text> : null}
          <Button title="Save Profile" onPress={saveProfile} loading={isLoading} />
        </View>
      ) : null}

      {activeForm === "password" ? (
      <View style={styles.form}>
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Change password</Text>
        <InputField
          label="Current Password"
          value={currentPassword}
          onChangeText={setCurrentPassword}
          secureTextEntry
          autoCapitalize="none"
        />
        <InputField
          label="New Password"
          value={password}
          onChangeText={setPassword}
          placeholder="New password"
          secureTextEntry
          autoCapitalize="none"
        />
        <InputField
          label="Confirm New Password"
          value={passwordConfirmation}
          onChangeText={setPasswordConfirmation}
          placeholder="Confirm new password"
          secureTextEntry
          autoCapitalize="none"
        />
        {passwordError ? <Text style={[styles.error, { color: colors.destructive }]}>{passwordError}</Text> : null}
        <Button
          title="Change Password"
          onPress={submitPassword}
          loading={isLoading}
          variant="secondary"
        />
      </View>
      ) : null}
    </Card>
  );
}

const styles = StyleSheet.create({
  actionButton: {
    flexGrow: 1,
    minWidth: 150,
  },
  actionRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
  },
  card: {
    gap: 14,
  },
  error: {
    fontFamily: "Inter_500Medium",
    fontSize: 13,
  },
  form: {
    gap: 12,
  },
  headerBlock: {
    gap: 3,
  },
  sectionTitle: {
    fontFamily: "Inter_700Bold",
    fontSize: 16,
    fontWeight: "700",
  },
  subtitle: {
    fontFamily: "Inter_400Regular",
    fontSize: 13,
    marginTop: 3,
  },
  success: {
    color: "#15803D",
    fontFamily: "Inter_600SemiBold",
    fontSize: 13,
  },
  title: {
    fontFamily: "Inter_700Bold",
    fontSize: 18,
    fontWeight: "700",
  },
});
