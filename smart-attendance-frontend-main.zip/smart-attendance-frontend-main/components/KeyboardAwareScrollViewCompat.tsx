import type { KeyboardAwareScrollViewProps } from "react-native-keyboard-controller";
import { Platform, ScrollView, ScrollViewProps } from "react-native";

type Props = KeyboardAwareScrollViewProps & ScrollViewProps;
declare const require: (moduleName: string) => any;

function getKeyboardAwareScrollView() {
  if (Platform.OS === "web") return null;

  try {
    return require("react-native-keyboard-controller").KeyboardAwareScrollView || null;
  } catch {
    return null;
  }
}

export function KeyboardAwareScrollViewCompat({
  children,
  keyboardShouldPersistTaps = "handled",
  ...props
}: Props) {
  const NativeKeyboardAwareScrollView = getKeyboardAwareScrollView();

  if (!NativeKeyboardAwareScrollView) {
    return (
      <ScrollView keyboardShouldPersistTaps={keyboardShouldPersistTaps} {...props}>
        {children}
      </ScrollView>
    );
  }

  return (
    <NativeKeyboardAwareScrollView
      keyboardShouldPersistTaps={keyboardShouldPersistTaps}
      {...props}
    >
      {children}
    </NativeKeyboardAwareScrollView>
  );
}
