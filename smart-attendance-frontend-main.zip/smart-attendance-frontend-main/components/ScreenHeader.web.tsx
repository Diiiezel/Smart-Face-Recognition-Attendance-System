import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import React from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { useColors } from "@/hooks/useColors";

interface ScreenHeaderProps {
  title: string;
  subtitle?: string;
  showBack?: boolean;
  rightElement?: React.ReactNode;
  dark?: boolean;
}

export function ScreenHeader({
  title,
  subtitle,
  showBack = false,
  rightElement,
  dark = false,
}: ScreenHeaderProps) {
  const colors = useColors();

  return (
    <View
      style={[
        styles.shell,
        {
          backgroundColor: dark ? colors.navy : colors.card,
          borderBottomColor: dark ? "rgba(255,255,255,0.08)" : colors.border,
        },
      ]}
    >
      <View style={styles.inner}>
        {showBack && (
          <Pressable
            onPress={() => router.back()}
            style={({ pressed, hovered }) => [
              styles.backButton,
              {
                backgroundColor: dark ? "rgba(255,255,255,0.1)" : colors.muted,
              },
              hovered && { borderColor: dark ? "rgba(255,255,255,0.22)" : colors.border },
              pressed && { opacity: 0.76 },
            ]}
          >
            <Ionicons
              name="chevron-back"
              size={18}
              color={dark ? "#FFFFFF" : colors.foreground}
            />
          </Pressable>
        )}
        <View style={styles.titleBlock}>
          <Text
            style={[
              styles.title,
              { color: dark ? "#FFFFFF" : colors.foreground },
            ]}
          >
            {title}
          </Text>
          {subtitle ? (
            <Text
              style={[
                styles.subtitle,
                { color: dark ? "rgba(255,255,255,0.62)" : colors.mutedForeground },
              ]}
            >
              {subtitle}
            </Text>
          ) : null}
        </View>
        {rightElement}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  backButton: {
    alignItems: "center",
    borderColor: "transparent",
    borderRadius: 12,
    borderWidth: 1,
    height: 40,
    justifyContent: "center",
    width: 40,
  },
  inner: {
    alignItems: "center",
    alignSelf: "center",
    flexDirection: "row",
    gap: 14,
    maxWidth: 1180,
    paddingHorizontal: 28,
    paddingVertical: 18,
    width: "100%",
  },
  shell: {
    borderBottomWidth: 1,
    paddingTop: 18,
  },
  subtitle: {
    fontFamily: "Inter_400Regular",
    fontSize: 13,
    marginTop: 2,
  },
  title: {
    fontFamily: "Inter_700Bold",
    fontSize: 24,
    fontWeight: "700",
    letterSpacing: -0.4,
  },
  titleBlock: {
    flex: 1,
  },
});
