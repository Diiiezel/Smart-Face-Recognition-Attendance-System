# Smart Attendance Frontend

Expo React Native frontend for the Smart Attendance graduation project.

This repository is prepared for Netlify web deployment. The Laravel backend should be deployed separately on Railway, and this frontend talks to it through `EXPO_PUBLIC_API_BASE_URL`.

## Requirements

- Node.js
- pnpm

## Local Setup

```bash
pnpm install
cp .env.example .env
pnpm run typecheck
pnpm run start -- --web --port 8081
```

Set local `.env` values as needed:

```env
EXPO_PUBLIC_API_BASE_URL=https://your-railway-domain.up.railway.app/api
EXPO_PUBLIC_USE_MOCKS=false
```

Do not commit `.env`.

## Build Locally

```bash
pnpm run build
```

The Netlify-ready static web output is written to:

```text
dist/
```

## Netlify Deployment

1. Push this frontend-only folder to a separate GitHub repository.
2. In Netlify, import the GitHub repository.
3. Use these build settings:

```text
Build command: pnpm run build
Publish directory: dist
```

4. Add these Netlify environment variables:

```env
EXPO_PUBLIC_API_BASE_URL=https://your-railway-domain.up.railway.app/api
EXPO_PUBLIC_USE_MOCKS=false
```

`EXPO_PUBLIC_API_BASE_URL` must be the Railway backend API URL and must end in `/api`.

## Backend Railway Note

This frontend does not include the Laravel backend. It calls the Railway backend only through:

```env
EXPO_PUBLIC_API_BASE_URL
```

After deploying the backend, test:

```text
https://your-railway-domain.up.railway.app/api/test
```

Then put:

```env
EXPO_PUBLIC_API_BASE_URL=https://your-railway-domain.up.railway.app/api
```

in Netlify.

## Mock Mode

For offline/demo mode without the backend:

```env
EXPO_PUBLIC_USE_MOCKS=true
```

For production backend mode:

```env
EXPO_PUBLIC_USE_MOCKS=false
```

Mock mode remains included in this package.

## Mobile Note

Netlify is for the web app only.

Expo mobile can still run locally or through EAS using the same API URL:

```env
EXPO_PUBLIC_API_BASE_URL=https://your-railway-domain.up.railway.app/api
```

## Troubleshooting

### Blank Screen

- Confirm Netlify publish directory is `dist`.
- Confirm `pnpm run build` succeeds locally.
- Check browser console errors.
- Make sure Netlify has the required environment variables.

### Wrong API URL

- `EXPO_PUBLIC_API_BASE_URL` must include `/api`.
- Example:

```env
EXPO_PUBLIC_API_BASE_URL=https://your-railway-domain.up.railway.app/api
```

### CORS Issue

- Confirm the Railway backend CORS config allows the Netlify domain.
- Confirm the frontend is calling the Railway backend, not localhost.

### Missing Environment Variables

- Add variables in Netlify site settings.
- Redeploy after changing environment variables.

### Catalog Dependency Error

This standalone package replaces previous `catalog:` dependency versions with explicit versions, so it should install without the original workspace.

If you still see a catalog error:

```bash
pnpm install
```

from the frontend package root and confirm `package.json` does not contain `catalog:`.

### Clear Expo Cache

```bash
pnpm run start -- --web --clear --port 8081
```

## Safety

- Do not commit `.env`.
- Do not commit `node_modules/`.
- Do not commit `.expo/`.
- Do not commit `dist/`, `web-build/`, or other build output.
