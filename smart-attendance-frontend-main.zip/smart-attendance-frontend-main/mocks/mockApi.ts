import AsyncStorage from "@react-native-async-storage/async-storage";

import {
  findManagedStudentByEmail,
  syncManagedStudentFaceEnrollment,
  upsertRegisteredStudent,
} from "@/services/studentsService";
import {
  buildStudentQrPayload,
  parseStudentQrPayload,
  stringifyStudentQrPayload,
} from "@/utils/qr";

export type DisplayRole = "student" | "staff";
export type ApiRole = "student" | "doctor" | "admin";

export const MOCK_AUTH_USER_KEY = "mockAuthUser";
export const MOCK_AUTH_TOKEN = "mock-token-123";
const STUDENT_ENROLLMENTS_KEY = "studentCourseEnrollments";

type MockUser = {
  id: number;
  name: string;
  fullName?: string;
  email: string;
  role: "student" | "doctor";
  university_code: string;
  universityId?: string;
  major?: string;
  level?: string;
  levels?: string[];
  face_token?: string | null;
  face_image_uri?: string | null;
  is_face_verified?: boolean;
};

type MockCourse = {
  id: number;
  code: string;
  name: string;
  semester: string;
  level: string;
  departments?: string[];
  levels?: string[];
  doctor?: {
    name: string;
    major: string;
  };
  enrollments_count: number;
};

type MockSession = {
  id: number;
  session_ids?: number[];
  session_group_key?: string | null;
  course_id: number;
  course_ids?: number[];
  method: "face" | "qr" | "both";
  status: "scheduled" | "open" | "closed";
  starts_at: string;
  ends_at: string;
  created_at: string;
  present_count: number;
  total_count: number;
  levels?: string[];
  level_labels?: string[];
  course?: {
    id: number;
    code: string;
    name: string;
    enrollments_count: number;
  };
};

type MockAttendanceRecord = {
  id: number;
  course_code: string;
  course_name: string;
  date: string;
  status: "present" | "absent";
  time?: string;
  attendance_rate: number;
};

type MockReportStudent = {
  id: number;
  full_name: string;
  name: string;
  university_code: string;
  status: "present" | "absent";
  attended_at?: string;
  method?: "face" | "qr";
  match_score?: number | null;
};

type RegisterPayload = {
  name: string;
  email: string;
  password: string;
  role: "student" | "doctor";
  university_code: string;
  major?: string;
  level?: string;
  levels?: string[];
};

const DEFAULT_STUDENT: MockUser = {
  id: 1,
  name: "Maya Hassan",
  fullName: "Maya Hassan",
  email: "maya@student.university.edu",
  role: "student",
  university_code: "202101234",
  universityId: "202101234",
  major: "CS",
  level: "Third Year",
  face_token: null,
  face_image_uri: null,
  is_face_verified: false,
};

const DEFAULT_STAFF: MockUser = {
  id: 10,
  name: "Dr. Karim Adel",
  fullName: "Dr. Karim Adel",
  email: "karim@university.edu",
  role: "doctor",
  university_code: "STF-00456",
  universityId: "STF-00456",
  major: "CS",
  levels: ["Third Year", "Fourth Year"],
  level: "Third Year, Fourth Year",
  face_token: null,
  face_image_uri: null,
  is_face_verified: false,
};

const studentCoursesSeed: MockCourse[] = [
  {
    id: 101,
    code: "CS301",
    name: "Mobile Application Development",
    semester: "Spring 2026 · Sun & Tue 10:00",
    level: "Third Year",
    departments: ["CS"],
    levels: ["Third Year"],
    doctor: { name: "Dr. Karim Adel", major: "CS" },
    enrollments_count: 42,
  },
  {
    id: 102,
    code: "CS315",
    name: "Database Systems",
    semester: "Spring 2026 · Mon & Wed 12:00",
    level: "Third Year",
    departments: ["CS"],
    levels: ["Third Year"],
    doctor: { name: "Dr. Rana Fathy", major: "CS" },
    enrollments_count: 38,
  },
  {
    id: 103,
    code: "IS220",
    name: "Information Security Basics",
    semester: "Spring 2026 · Thu 09:00",
    level: "Third Year",
    departments: ["IS"],
    levels: ["Third Year"],
    doctor: { name: "Dr. Salma Tarek", major: "IS" },
    enrollments_count: 35,
  },
  {
    id: 104,
    code: "CS320",
    name: "Software Testing",
    semester: "Spring 2026 · Tue 13:00",
    level: "Third Year",
    departments: ["CS"],
    levels: ["Third Year"],
    doctor: { name: "Dr. Karim Adel", major: "CS" },
    enrollments_count: 31,
  },
  {
    id: 109,
    code: "CS410",
    name: "Artificial Intelligence",
    semester: "Spring 2026 · Wed 12:00",
    level: "Third Year",
    departments: ["CS"],
    levels: ["Third Year"],
    doctor: { name: "Dr. Sara Ahmed", major: "CS" },
    enrollments_count: 34,
  },
  {
    id: 105,
    code: "IS310",
    name: "Systems Analysis",
    semester: "Spring 2026 · Wed 11:00",
    level: "Third Year",
    departments: ["IS"],
    levels: ["Third Year"],
    doctor: { name: "Dr. Salma Tarek", major: "IS" },
    enrollments_count: 29,
  },
  {
    id: 106,
    code: "CS401",
    name: "Advanced Software Engineering",
    semester: "Spring 2026 · Sun & Tue 14:00",
    level: "Fourth Year",
    departments: ["CS"],
    levels: ["Fourth Year"],
    doctor: { name: "Dr. Karim Adel", major: "CS" },
    enrollments_count: 54,
  },
  {
    id: 108,
    code: "CS310",
    name: "Machine Learning Basics",
    semester: "Spring 2026 · Wed 10:00",
    level: "Fourth Year",
    departments: ["CS"],
    levels: ["Fourth Year"],
    doctor: { name: "Dr. Sara Ahmed", major: "CS" },
    enrollments_count: 36,
  },
  {
    id: 107,
    code: "CS305",
    name: "Human Computer Interaction",
    semester: "Spring 2026 · Mon 11:00",
    level: "Third Year",
    departments: ["CS"],
    levels: ["Third Year"],
    doctor: { name: "Dr. Karim Adel", major: "CS" },
    enrollments_count: 47,
  },
];

const staffCoursesSeed: MockCourse[] = [
  {
    id: 201,
    code: "CS401",
    name: "Advanced Software Engineering",
    semester: "Spring 2026 · Sun & Tue 14:00",
    level: "Fourth Year",
    doctor: { name: DEFAULT_STAFF.name, major: "CS" },
    enrollments_count: 54,
  },
  {
    id: 202,
    code: "CS305",
    name: "Human Computer Interaction",
    semester: "Spring 2026 · Mon 11:00",
    level: "Third Year",
    doctor: { name: DEFAULT_STAFF.name, major: "CS" },
    enrollments_count: 47,
  },
];

const attendanceSeed: MockAttendanceRecord[] = [
  { id: 1, course_code: "CS301", course_name: "Mobile Application Development", date: "2026-04-21", status: "present", time: "10:03", attendance_rate: 92 },
  { id: 2, course_code: "CS315", course_name: "Database Systems", date: "2026-04-20", status: "present", time: "12:09", attendance_rate: 88 },
  { id: 3, course_code: "IS220", course_name: "Information Security Basics", date: "2026-04-17", status: "absent", attendance_rate: 81 },
  { id: 4, course_code: "CS301", course_name: "Mobile Application Development", date: "2026-04-14", status: "present", time: "09:58", attendance_rate: 90 },
];

const sessionsSeed: MockSession[] = [
  {
    id: 501,
    course_id: 201,
    method: "both",
    status: "open",
    starts_at: "2026-04-29T11:00:00.000Z",
    ends_at: "2026-04-29T12:30:00.000Z",
    created_at: "2026-04-29T10:55:00.000Z",
    present_count: 18,
    total_count: 54,
    course: { id: 201, code: "CS401", name: "Advanced Software Engineering", enrollments_count: 54 },
  },
  {
    id: 502,
    course_id: 202,
    method: "qr",
    status: "scheduled",
    starts_at: "2026-04-27T09:00:00.000Z",
    ends_at: "2026-04-27T10:00:00.000Z",
    created_at: "2026-04-27T08:50:00.000Z",
    present_count: 39,
    total_count: 47,
    course: { id: 202, code: "CS305", name: "Human Computer Interaction", enrollments_count: 47 },
  },
];

const sessionReportsSeed: Record<number, MockReportStudent[]> = {
  501: [
    { id: 1, full_name: "Maya Hassan", name: "Maya Hassan", university_code: "202101234", status: "present", attended_at: "2026-04-29T11:03:00.000Z", method: "qr", match_score: null },
    { id: 2, full_name: "Omar Samir", name: "Omar Samir", university_code: "202101235", status: "present", attended_at: "2026-04-29T11:05:00.000Z", method: "face", match_score: 97.5 },
    { id: 3, full_name: "Nour Ali", name: "Nour Ali", university_code: "202101236", status: "absent" },
  ],
  502: [
    { id: 4, full_name: "Youssef Mostafa", name: "Youssef Mostafa", university_code: "202101240", status: "present", attended_at: "2026-04-27T09:02:00.000Z", method: "qr", match_score: null },
    { id: 5, full_name: "Lina Ashraf", name: "Lina Ashraf", university_code: "202101241", status: "present", attended_at: "2026-04-27T09:11:00.000Z", method: "qr", match_score: null },
  ],
};

let currentUser: MockUser | null = null;
let mockCourses: MockCourse[] = [];
let mockSessions: MockSession[] = [];
let mockAttendanceHistory: MockAttendanceRecord[] = [];
let mockSessionReports: Record<number, MockReportStudent[]> = {};

function clone<T>(value: T): T {
  return JSON.parse(JSON.stringify(value)) as T;
}

function delay<T>(value: T, min = 500, max = 1500): Promise<T> {
  const ms = Math.floor(Math.random() * (max - min + 1)) + min;
  return new Promise((resolve) => setTimeout(() => resolve(clone(value)), ms));
}

function ensureStateForRole(role: "student" | "doctor") {
  if (role === "student") {
    mockCourses = clone(studentCoursesSeed);
    mockAttendanceHistory = clone(attendanceSeed);
    mockSessions = [];
    mockSessionReports = {};
    return;
  }

  mockCourses = clone(staffCoursesSeed);
  mockSessions = clone(sessionsSeed);
  mockAttendanceHistory = [];
  mockSessionReports = clone(sessionReportsSeed);
}

function makeQrPayload(user: MockUser) {
  return stringifyStudentQrPayload(
    buildStudentQrPayload({
      studentId: user.id,
      name: user.name,
      universityCode: user.university_code,
      major: user.major,
      level: user.level,
    }),
  );
}

function makeQrDataUri(user: MockUser) {
  const label = `${user.university_code}\n${user.name}`;
  const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200">
      <rect width="200" height="200" fill="white"/>
      <rect x="16" y="16" width="42" height="42" fill="#111827"/>
      <rect x="142" y="16" width="42" height="42" fill="#111827"/>
      <rect x="16" y="142" width="42" height="42" fill="#111827"/>
      <rect x="74" y="16" width="18" height="18" fill="#2563EB"/>
      <rect x="102" y="16" width="18" height="18" fill="#111827"/>
      <rect x="74" y="44" width="18" height="18" fill="#111827"/>
      <rect x="102" y="44" width="18" height="18" fill="#2563EB"/>
      <rect x="74" y="74" width="18" height="18" fill="#111827"/>
      <rect x="102" y="74" width="18" height="18" fill="#111827"/>
      <rect x="130" y="74" width="18" height="18" fill="#2563EB"/>
      <rect x="158" y="74" width="18" height="18" fill="#111827"/>
      <rect x="74" y="102" width="18" height="18" fill="#2563EB"/>
      <rect x="102" y="102" width="18" height="18" fill="#111827"/>
      <rect x="130" y="102" width="18" height="18" fill="#111827"/>
      <rect x="158" y="102" width="18" height="18" fill="#2563EB"/>
      <rect x="74" y="130" width="18" height="18" fill="#111827"/>
      <rect x="102" y="130" width="18" height="18" fill="#2563EB"/>
      <rect x="130" y="130" width="18" height="18" fill="#111827"/>
      <rect x="158" y="130" width="18" height="18" fill="#111827"/>
      <text x="100" y="189" font-size="11" text-anchor="middle" fill="#111827" font-family="Arial">${label}</text>
    </svg>
  `;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

function buildReportsOverview() {
  const totalStudents = mockCourses.reduce((sum, course) => sum + (course.enrollments_count || 0), 0);
  return {
    totals: {
      average_attendance_rate: 89,
      courses_count: mockCourses.length,
      sessions_count: mockSessions.length,
      students_count: totalStudents,
    },
    trend: [
      { label: "Week 1", date: "2026-04-01", attendance_rate: 85 },
      { label: "Week 2", date: "2026-04-08", attendance_rate: 88 },
      { label: "Week 3", date: "2026-04-15", attendance_rate: 91 },
      { label: "Week 4", date: "2026-04-22", attendance_rate: 89 },
    ],
    courses: mockCourses.map((course) => ({
      id: course.id,
      code: course.code,
      name: course.name,
      total_students: course.enrollments_count,
      sessions_count: mockSessions.filter((session) => session.course_id === course.id).length || 1,
      attendance_rate: course.code === "CS401" ? 93 : 87,
    })),
  };
}

async function readStudentEnrollments() {
  const raw = await AsyncStorage.getItem(STUDENT_ENROLLMENTS_KEY);
  if (!raw) return {} as Record<string, string[]>;

  try {
    const parsed = JSON.parse(raw) as Record<string, string[]>;
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch {
    return {};
  }
}

async function writeStudentEnrollments(value: Record<string, string[]>) {
  await AsyncStorage.setItem(STUDENT_ENROLLMENTS_KEY, JSON.stringify(value));
}

function getStudentEnrollmentKey(user: MockUser) {
  return user.university_code || user.email.trim().toLowerCase();
}

function getEligibleStudentCourses(user: MockUser) {
  return studentCoursesSeed.filter((course) => {
    const matchesDepartment =
      !course.departments?.length || course.departments.includes(user.major || "");
    const matchesLevel = !course.levels?.length || course.levels.includes(user.level || "");
    return matchesDepartment && matchesLevel;
  });
}

function getCurrentRoleUser() {
  if (!currentUser) {
    throw new Error("Mock user is not authenticated.");
  }
  return currentUser;
}

async function persistCurrentUser() {
  if (!currentUser) {
    await AsyncStorage.removeItem(MOCK_AUTH_USER_KEY);
    return;
  }

  await AsyncStorage.setItem(MOCK_AUTH_USER_KEY, JSON.stringify(currentUser));
}

export async function hydrateMockSession() {
  if (currentUser) return;

  const storedUser = await AsyncStorage.getItem(MOCK_AUTH_USER_KEY);
  if (!storedUser) return;

  try {
    const parsed = JSON.parse(storedUser) as MockUser;
    currentUser = parsed;
    ensureStateForRole(parsed.role);
  } catch {
    currentUser = null;
    await AsyncStorage.removeItem(MOCK_AUTH_USER_KEY);
  }
}

export async function loginUser(payload: { email: string; password: string; role?: DisplayRole }) {
  await hydrateMockSession();

  const normalizedEmail = payload.email.trim().toLowerCase();
  const registeredStudent = await findManagedStudentByEmail(normalizedEmail);

  if (payload.role === "staff") {
    currentUser = { ...DEFAULT_STAFF, email: normalizedEmail || DEFAULT_STAFF.email };
  } else if (payload.role === "student" && registeredStudent) {
    currentUser = {
      id: Number(registeredStudent.id.replace(/\D/g, "")) || Date.now(),
      name: registeredStudent.fullName,
      fullName: registeredStudent.fullName,
      email: registeredStudent.email,
      role: "student",
      university_code: registeredStudent.universityId,
      universityId: registeredStudent.universityId,
      major: registeredStudent.major,
      level: registeredStudent.level,
      face_token: registeredStudent.faceEnrolled ? "mock-face-token" : null,
      face_image_uri: registeredStudent.faceImageUri || null,
      is_face_verified: registeredStudent.faceEnrolled,
    };
  } else if (payload.role === "student") {
    currentUser = { ...DEFAULT_STUDENT, email: normalizedEmail || DEFAULT_STUDENT.email };
  } else {
    currentUser =
      normalizedEmail.includes("staff") || normalizedEmail.includes("doctor")
        ? { ...DEFAULT_STAFF, email: normalizedEmail || DEFAULT_STAFF.email }
        : registeredStudent
          ? {
              id: Number(registeredStudent.id.replace(/\D/g, "")) || Date.now(),
              name: registeredStudent.fullName,
              fullName: registeredStudent.fullName,
              email: registeredStudent.email,
              role: "student",
              university_code: registeredStudent.universityId,
              universityId: registeredStudent.universityId,
              major: registeredStudent.major,
              level: registeredStudent.level,
              face_token: registeredStudent.faceEnrolled ? "mock-face-token" : null,
              face_image_uri: registeredStudent.faceImageUri || null,
              is_face_verified: registeredStudent.faceEnrolled,
            }
          : { ...DEFAULT_STUDENT, email: normalizedEmail || DEFAULT_STUDENT.email };
  }

  ensureStateForRole(currentUser.role);
  await persistCurrentUser();

  return delay({
    token: MOCK_AUTH_TOKEN,
    user: currentUser,
  });
}

export async function requestMockPasswordReset(email: string) {
  await delay(null);
  return {
    email,
    message: "If this email exists, a reset code has been sent.",
  };
}

export async function resetMockPassword(payload: {
  email: string;
  otp: string;
  password: string;
  password_confirmation: string;
}) {
  await delay(null);

  if (payload.otp !== "123456") {
    throw new Error("Invalid or expired reset code.");
  }

  if (payload.password !== payload.password_confirmation) {
    throw new Error("Passwords do not match.");
  }

  return {
    message: "Password reset successfully. You can now sign in.",
  };
}

export async function registerUser(payload: RegisterPayload) {
  currentUser = {
    id: Date.now(),
    name: payload.name,
    fullName: payload.name,
    email: payload.email.trim().toLowerCase(),
    role: payload.role,
    university_code: payload.university_code,
    universityId: payload.university_code,
    major: payload.major || "CS",
    level:
      payload.role === "student"
        ? payload.level || "First Year"
        : (payload.levels || []).join(", ") || "All Levels",
    levels: payload.role === "doctor" ? payload.levels || [] : undefined,
    face_token: null,
    face_image_uri: null,
    is_face_verified: false,
  };

  if (payload.role === "student") {
    await upsertRegisteredStudent({
      fullName: payload.name,
      universityId: payload.university_code,
      email: payload.email,
      major: payload.major || "CS",
      level: payload.level || "First Year",
      faceEnrolled: false,
      faceImageUri: null,
    });
  }

  ensureStateForRole(currentUser.role);
  await persistCurrentUser();

  return delay({
    token: MOCK_AUTH_TOKEN,
    user: currentUser,
  });
}

export async function getCurrentUser() {
  await hydrateMockSession();
  return delay(getCurrentRoleUser());
}

export async function updateMockCurrentUserProfile(payload: {
  name?: string;
  email?: string;
  major?: string;
  level?: string;
}) {
  await hydrateMockSession();
  const user = getCurrentRoleUser();
  const previousLevel = user.level;

  currentUser = {
    ...user,
    name: payload.name?.trim() || user.name,
    fullName: payload.name?.trim() || user.fullName || user.name,
    email: payload.email?.trim().toLowerCase() || user.email,
    ...(user.role === "student"
      ? {
          major: payload.major?.trim() || user.major,
          level: payload.level?.trim() || user.level,
        }
      : {}),
  };

  if (currentUser.role === "student") {
    if (payload.level && payload.level.trim() !== previousLevel) {
      const enrollments = await readStudentEnrollments();
      const key = getStudentEnrollmentKey(currentUser);
      const eligibleCodes = getEligibleStudentCourses(currentUser).map((course) => course.code);
      enrollments[key] = (enrollments[key] || []).filter((code) => eligibleCodes.includes(code));
      await writeStudentEnrollments(enrollments);
    }

    await upsertRegisteredStudent({
      fullName: currentUser.name,
      universityId: currentUser.university_code,
      email: currentUser.email,
      major: currentUser.major || "CS",
      level: currentUser.level || "First Year",
      faceEnrolled: Boolean(currentUser.is_face_verified || currentUser.face_token),
      faceImageUri: currentUser.face_image_uri || null,
    });
  }

  await persistCurrentUser();
  return delay({
    message: "Profile updated successfully",
    user: currentUser,
  });
}

export async function changeMockCurrentUserPassword() {
  await hydrateMockSession();
  getCurrentRoleUser();

  return delay({
    message: "Password changed successfully",
  });
}

export async function logoutUser() {
  currentUser = null;
  mockCourses = [];
  mockSessions = [];
  mockAttendanceHistory = [];
  mockSessionReports = {};
  await AsyncStorage.removeItem(MOCK_AUTH_USER_KEY);
  return delay({ success: true }, 250, 500);
}

export async function getMyCourses() {
  await hydrateMockSession();
  const user = getCurrentRoleUser();

  if (user.role !== "student") {
    return delay(mockCourses);
  }

  const enrollments = await readStudentEnrollments();
  const enrolledCodes = enrollments[getStudentEnrollmentKey(user)] || [];
  const eligibleCourses = getEligibleStudentCourses(user);
  const selectedCourses = eligibleCourses.filter((course) => enrolledCodes.includes(course.code));
  mockCourses = clone(selectedCourses);
  return delay(mockCourses);
}

export async function getStudentAvailableCourses() {
  await hydrateMockSession();
  const user = getCurrentRoleUser();

  if (user.role !== "student") {
    return delay([]);
  }

  const enrollments = await readStudentEnrollments();
  const enrolledCodes = enrollments[getStudentEnrollmentKey(user)] || [];
  const availableCourses = getEligibleStudentCourses(user).filter(
    (course) => !enrolledCodes.includes(course.code),
  );

  return delay(availableCourses);
}

export async function enrollStudentInCourse(courseCode: string) {
  await hydrateMockSession();
  const user = getCurrentRoleUser();

  if (user.role !== "student") {
    return delay([]);
  }

  const eligibleCourses = getEligibleStudentCourses(user);
  const course = eligibleCourses.find((item) => item.code === courseCode.trim());
  if (!course) {
    throw new Error("This course is not available for your major and level.");
  }

  const enrollments = await readStudentEnrollments();
  const key = getStudentEnrollmentKey(user);
  const currentCodes = enrollments[key] || [];
  if (!currentCodes.includes(course.code)) {
    enrollments[key] = [...currentCodes, course.code];
    await writeStudentEnrollments(enrollments);
  }

  const selectedCourses = eligibleCourses.filter((item) => (enrollments[key] || []).includes(item.code));
  mockCourses = clone(selectedCourses);
  return delay(mockCourses);
}

export async function getMyAttendanceHistory() {
  await hydrateMockSession();
  return delay({
    records: mockAttendanceHistory,
  });
}

export async function getMyQr() {
  await hydrateMockSession();
  const user = getCurrentRoleUser();
  return delay({
    qr_url: makeQrDataUri(user),
    qr_payload: makeQrPayload(user),
  });
}

function displayMockCourseCode(code: string) {
  return code.replace(/-(CS|IS)[1-4](?:-\d+)?$/i, "");
}

function levelLabel(level: string) {
  if (level === "1") return "First Year";
  if (level === "2") return "Second Year";
  if (level === "3") return "Third Year";
  if (level === "4") return "Fourth Year";
  return level;
}

function mockSessionGroupFor(sessionId: number) {
  const session = mockSessions.find((item) => item.id === sessionId);
  if (!session) return [];
  if (!session.session_group_key) return [session];
  return mockSessions.filter((item) => item.session_group_key === session.session_group_key);
}

function groupedMockSessions() {
  const groups = new Map<string, MockSession[]>();

  for (const session of mockSessions) {
    const key = session.session_group_key || `session:${session.id}`;
    groups.set(key, [...(groups.get(key) || []), session]);
  }

  return Array.from(groups.values()).map((group) => {
    const representative = group[0];
    const courses = group.map((session) => session.course).filter(Boolean);
    const levels = group
      .map((session) => mockCourses.find((course) => course.id === session.course_id)?.level || "")
      .filter(Boolean);

    return {
      ...representative,
      session_ids: group.map((session) => session.id),
      course_ids: group.map((session) => session.course_id),
      course_code: displayMockCourseCode(representative.course?.code || "N/A"),
      total_count: group.reduce((sum, session) => sum + Number(session.total_count || 0), 0),
      present_count: group.reduce((sum, session) => sum + Number(session.present_count || 0), 0),
      levels,
      level_labels: levels.map(levelLabel),
      course: representative.course
        ? {
            ...representative.course,
            code: displayMockCourseCode(representative.course.code),
            enrollments_count: group.reduce((sum, session) => sum + Number(session.total_count || 0), 0),
          }
        : courses[0],
    };
  });
}

export async function getDoctorSessions() {
  await hydrateMockSession();
  return delay(groupedMockSessions());
}

export async function createCourse(input: {
  name: string;
  code: string;
  semester?: string;
  level?: string;
  departments?: string[];
  levels?: string[];
}) {
  await hydrateMockSession();
  const user = getCurrentRoleUser();
  const departments = (input.departments || []).filter(Boolean);
  const levels = (input.levels || []).filter(Boolean);
  const course: MockCourse = {
    id: Date.now(),
    code: input.code,
    name: input.name,
    semester: input.semester || "Spring 2026 · TBD",
    level: levels.join(", ") || input.level || "First Year",
    departments,
    levels,
    doctor: {
      name: user.name,
      major: departments.join(", ") || user.major || "CS",
    },
    enrollments_count: 32,
  };
  mockCourses = [course, ...mockCourses];
  return delay(course);
}

export async function createSession(input: {
  course_id: number;
  method: "face" | "qr" | "both";
  starts_at?: string | null;
  ends_at?: string | null;
  session_group_key?: string | null;
}) {
  await hydrateMockSession();
  const course = mockCourses.find((item) => item.id === input.course_id) || mockCourses[0];
  const session: MockSession = {
    id: Date.now(),
    session_group_key: input.session_group_key || null,
    course_id: input.course_id,
    method: input.method,
    status: "scheduled",
    starts_at: input.starts_at || new Date().toISOString(),
    ends_at: input.ends_at || new Date(Date.now() + 60 * 60 * 1000).toISOString(),
    created_at: new Date().toISOString(),
    present_count: 0,
    total_count: course?.enrollments_count || 0,
    course: course
      ? {
          id: course.id,
          code: course.code,
          name: course.name,
          enrollments_count: course.enrollments_count,
        }
      : undefined,
  };
  mockSessions = [session, ...mockSessions];
  mockSessionReports[session.id] = [];
  return delay(session);
}

export async function openSession(sessionId: number) {
  await hydrateMockSession();
  const group = mockSessionGroupFor(sessionId);
  mockSessions = mockSessions.map((session) =>
    group.some((child) => child.id === session.id) ? { ...session, status: "open" } : session,
  );
  return delay({ success: true });
}

export async function closeSession(sessionId: number) {
  await hydrateMockSession();
  const group = mockSessionGroupFor(sessionId);
  const session = group[0];

  if (group.length === 0 || group.some((item) => item.status !== "open")) {
    throw new Error("Open the session before closing it.");
  }

  for (const childSession of group) {
    const existingReport = mockSessionReports[childSession.id] || [];
    const existingIds = new Set(existingReport.map((student) => student.id));
    const method = session.method === "face" ? "face" : "qr";

    if (!existingIds.has(DEFAULT_STUDENT.id)) {
      mockSessionReports[childSession.id] = [
        ...existingReport,
        {
          id: DEFAULT_STUDENT.id,
          full_name: DEFAULT_STUDENT.name,
          name: DEFAULT_STUDENT.name,
          university_code: DEFAULT_STUDENT.university_code,
          status: "absent",
          method,
        },
      ];
    }
  }

  mockSessions = mockSessions.map((session) =>
    group.some((child) => child.id === session.id) ? { ...session, status: "closed" } : session,
  );
  return delay({ success: true });
}

export async function updateSession(
  sessionId: number,
  input: {
    method: "face" | "qr" | "both";
    starts_at?: string | null;
    ends_at?: string | null;
  },
) {
  await hydrateMockSession();
  const group = mockSessionGroupFor(sessionId);
  const existingSession = group[0];

  if (!existingSession) {
    throw new Error("Session not found.");
  }

  if (group.some((session) => session.status !== "scheduled")) {
    throw new Error("Only scheduled sessions can be updated.");
  }

  const updatedSession = {
    ...existingSession,
    method: input.method,
    starts_at: input.starts_at || existingSession.starts_at,
    ends_at: input.ends_at || existingSession.ends_at,
  };

  mockSessions = mockSessions.map((session) =>
    group.some((child) => child.id === session.id)
      ? {
          ...session,
          method: input.method,
          starts_at: input.starts_at || session.starts_at,
          ends_at: input.ends_at || session.ends_at,
        }
      : session,
  );

  return delay(updatedSession);
}

export async function deleteSession(sessionId: number) {
  await hydrateMockSession();
  const group = mockSessionGroupFor(sessionId);
  const existingSession = group[0];

  if (!existingSession) {
    throw new Error("Session not found.");
  }

  if (group.some((session) => session.status !== "scheduled")) {
    throw new Error("Only scheduled sessions can be deleted.");
  }

  if (group.some((session) => (mockSessionReports[session.id] || []).length > 0)) {
    throw new Error("Sessions with attendance records cannot be deleted.");
  }

  mockSessions = mockSessions.filter((session) => !group.some((child) => child.id === session.id));
  for (const session of group) {
    delete mockSessionReports[session.id];
  }

  return delay({ message: "Session deleted successfully" });
}

export async function getSessionReport(sessionId: number) {
  await hydrateMockSession();
  const group = mockSessionGroupFor(sessionId);
  const session = groupedMockSessions().find((item) => item.id === sessionId) || mockSessions.find((item) => item.id === sessionId) || null;
  return delay({
    session,
    students: group.flatMap((item) => mockSessionReports[item.id] || []),
  });
}

export async function markQrAttendanceForSession(
  sessionId: number,
  payload: { qr_payload: string },
) {
  await hydrateMockSession();
  const parsedStudentPayload = parseStudentQrPayload(payload.qr_payload);
  const parsedId = parsedStudentPayload.universityCode.trim();
  const reportList = mockSessionReports[sessionId] || [];

  const existing = reportList.find(
    (student) => student.university_code === parsedId || student.university_code === parsedId?.trim(),
  );

  if (existing?.status === "present") {
    throw new Error("Attendance already recorded for this student in this session.");
  }

  const student =
    existing ||
    ({
      id: Number(parsedStudentPayload.studentId) || Date.now(),
      full_name: parsedStudentPayload.name,
      name: parsedStudentPayload.name,
      university_code: parsedId?.trim() || "UNKNOWN",
      status: "present",
      method: "qr",
      attended_at: new Date().toISOString(),
      match_score: null,
    } satisfies MockReportStudent);

  const updatedStudent = {
    ...student,
    full_name: parsedStudentPayload.name,
    name: parsedStudentPayload.name,
    status: "present" as const,
    method: "qr" as const,
    attended_at: new Date().toISOString(),
  };

  mockSessionReports[sessionId] = [
    updatedStudent,
    ...reportList.filter((item) => item.university_code !== updatedStudent.university_code),
  ];

  mockSessions = mockSessions.map((session) =>
    session.id === sessionId
      ? {
          ...session,
          present_count: mockSessionReports[sessionId].filter((item) => item.status === "present").length,
        }
      : session,
  );

  return delay({
    student: {
      id: updatedStudent.id,
      name: updatedStudent.full_name,
      university_code: updatedStudent.university_code,
    },
    data: {
      attended_at: updatedStudent.attended_at,
    },
  });
}

export async function getReportsOverview() {
  await hydrateMockSession();
  return delay(buildReportsOverview());
}

export async function getCourseReport() {
  await hydrateMockSession();
  return delay({
    success: true,
    courses: mockCourses,
  });
}

export async function mockUploadMultipart<T>(
  operation: string,
  file: { uri: string; name?: string | null; mimeType?: string | null },
): Promise<T> {
  await hydrateMockSession();

  if (operation === "register-face") {
    currentUser = {
      ...getCurrentRoleUser(),
      face_token: file.uri || "mock-face-token",
      face_image_uri: file.uri || null,
      is_face_verified: true,
    };
    await syncManagedStudentFaceEnrollment(
      {
        universityId: currentUser.university_code,
        email: currentUser.email,
      },
      true,
      file.uri || null,
    );
    await persistCurrentUser();
    return delay({
      success: true,
      face_image_uri: file.uri || null,
      face_token: currentUser.face_token,
    } as T);
  }

  const sessionIdMatch = operation.match(/^mark-face-attendance:(\d+)$/);
  const sessionId = sessionIdMatch ? Number(sessionIdMatch[1]) : null;

  if (sessionId) {
    const user = currentUser?.role === "student" ? currentUser : DEFAULT_STUDENT;
    const updatedStudent: MockReportStudent = {
      id: user.id,
      full_name: user.name,
      name: user.name,
      university_code: user.university_code,
      status: "present",
      attended_at: new Date().toISOString(),
      method: "face",
      match_score: 97.5,
    };

    mockSessionReports[sessionId] = [
      updatedStudent,
      ...(mockSessionReports[sessionId] || []).filter((item) => item.university_code !== updatedStudent.university_code),
    ];

    mockSessions = mockSessions.map((session) =>
      session.id === sessionId
        ? {
            ...session,
            present_count: mockSessionReports[sessionId].filter((item) => item.status === "present").length,
          }
        : session,
    );

    return delay({
      student: {
        id: updatedStudent.id,
        name: updatedStudent.full_name,
        university_code: updatedStudent.university_code,
      },
      data: {
        attended_at: updatedStudent.attended_at,
      },
      confidence: updatedStudent.match_score,
    } as T);
  }

  return delay({ success: true } as T);
}
