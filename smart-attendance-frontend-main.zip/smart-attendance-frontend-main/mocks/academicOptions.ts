export const MAJOR_OPTIONS = [
  { label: "CS", value: "CS" },
  { label: "IS", value: "IS" },
] as const;

export const LEVEL_OPTIONS = [
  { label: "First Year", value: "First Year" },
  { label: "Second Year", value: "Second Year" },
  { label: "Third Year", value: "Third Year" },
  { label: "Fourth Year", value: "Fourth Year" },
] as const;
