export interface ManagedStudentAttendanceRecord {
  courseCode: string;
  sessionDate: string;
  status: "Present" | "Absent";
}

export interface ManagedStudent {
  id: string;
  fullName: string;
  universityId: string;
  email: string;
  major: string;
  level: string;
  faceEnrolled: boolean;
  faceImageUri?: string | null;
  attendanceRate: number;
  courses: string[];
  recentAttendance: ManagedStudentAttendanceRecord[];
}

export const managedStudentsSeed: ManagedStudent[] = [
  {
    id: "stu_001",
    fullName: "Ahmed Al-Rashidi",
    universityId: "202101234",
    email: "ahmed.rashidi@university.edu",
    major: "CS",
    level: "Fourth Year",
    faceEnrolled: true,
    faceImageUri: null,
    attendanceRate: 89,
    courses: ["CS401", "CS305"],
    recentAttendance: [
      { courseCode: "CS401", sessionDate: "2026-04-28", status: "Present" },
      { courseCode: "CS305", sessionDate: "2026-04-25", status: "Present" },
      { courseCode: "CS401", sessionDate: "2026-04-21", status: "Present" },
    ],
  },
  {
    id: "stu_002",
    fullName: "Lina Mostafa",
    universityId: "202101240",
    email: "lina.mostafa@university.edu",
    major: "IS",
    level: "Third Year",
    faceEnrolled: false,
    faceImageUri: null,
    attendanceRate: 72,
    courses: ["CS305"],
    recentAttendance: [
      { courseCode: "CS305", sessionDate: "2026-04-27", status: "Present" },
      { courseCode: "CS305", sessionDate: "2026-04-20", status: "Absent" },
    ],
  },
  {
    id: "stu_003",
    fullName: "Omar Samir",
    universityId: "202101235",
    email: "omar.samir@university.edu",
    major: "CS",
    level: "Fourth Year",
    faceEnrolled: true,
    faceImageUri: null,
    attendanceRate: 94,
    courses: ["CS401"],
    recentAttendance: [
      { courseCode: "CS401", sessionDate: "2026-04-29", status: "Present" },
      { courseCode: "CS401", sessionDate: "2026-04-22", status: "Present" },
    ],
  },
  {
    id: "stu_004",
    fullName: "Nour Ali",
    universityId: "202101236",
    email: "nour.ali@university.edu",
    major: "CS",
    level: "Fourth Year",
    faceEnrolled: true,
    faceImageUri: null,
    attendanceRate: 78,
    courses: ["CS401"],
    recentAttendance: [
      { courseCode: "CS401", sessionDate: "2026-04-29", status: "Absent" },
      { courseCode: "CS401", sessionDate: "2026-04-15", status: "Present" },
    ],
  },
  {
    id: "stu_005",
    fullName: "Salma Nabil",
    universityId: "202101242",
    email: "salma.nabil@university.edu",
    major: "IS",
    level: "Third Year",
    faceEnrolled: false,
    faceImageUri: null,
    attendanceRate: 67,
    courses: ["CS305"],
    recentAttendance: [
      { courseCode: "CS305", sessionDate: "2026-04-27", status: "Absent" },
      { courseCode: "CS305", sessionDate: "2026-04-13", status: "Present" },
    ],
  },
  {
    id: "stu_006",
    fullName: "Youssef Hamdy",
    universityId: "202101245",
    email: "youssef.hamdy@university.edu",
    major: "CS",
    level: "Third Year",
    faceEnrolled: true,
    faceImageUri: null,
    attendanceRate: 84,
    courses: ["CS305", "CS401"],
    recentAttendance: [
      { courseCode: "CS401", sessionDate: "2026-04-28", status: "Present" },
      { courseCode: "CS305", sessionDate: "2026-04-27", status: "Present" },
    ],
  },
];
