import {
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
  Inter_700Bold,
  useFonts,
} from "@expo-google-fonts/inter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Stack } from "expo-router";
import * as SplashScreen from "expo-splash-screen";
import React, { useEffect } from "react";
import { Platform } from "react-native";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { SafeAreaProvider } from "react-native-safe-area-context";

import { ErrorBoundary } from "@/components/ErrorBoundary";
import { AppProvider } from "@/context/AppContext";

declare const require: (moduleName: string) => any;

SplashScreen.preventAutoHideAsync();

const queryClient = new QueryClient();
const MaybeKeyboardProvider = (() => {
  if (Platform.OS === "web") return React.Fragment;

  try {
    return require("react-native-keyboard-controller").KeyboardProvider || React.Fragment;
  } catch {
    return React.Fragment;
  }
})();

function RootLayoutNav() {
  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="index" />
      <Stack.Screen name="role-select" />
      <Stack.Screen name="auth/login" />
      <Stack.Screen name="auth/signup" />
      <Stack.Screen name="auth/forgot-password" />
      <Stack.Screen name="student/dashboard" />
      <Stack.Screen name="student/profile" />
      <Stack.Screen name="student/face-enrollment" />
      <Stack.Screen name="student/courses" />
      <Stack.Screen name="student/attendance-history" />
      <Stack.Screen name="student/qr-code" />
      <Stack.Screen name="staff/dashboard" />
      <Stack.Screen name="staff/profile" />
      <Stack.Screen name="staff/all-courses" />
      <Stack.Screen name="staff/course-students" />
      <Stack.Screen name="staff/create-course" />
      <Stack.Screen name="staff/create-session" />
      <Stack.Screen name="staff/open-session" />
      <Stack.Screen name="staff/face-scan" />
      <Stack.Screen name="staff/qr-scan" />
      <Stack.Screen name="staff/reports" />
      <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
    </Stack>
  );
}

export default function RootLayout() {
  const [fontsLoaded, fontError] = useFonts({
    Ionicons: require("../assets/fonts/Ionicons.ttf"),
    Feather: require("../assets/fonts/Feather.ttf"),
    ...(Platform.OS !== "web"
      ? {
          Inter_400Regular,
          Inter_500Medium,
          Inter_600SemiBold,
          Inter_700Bold,
        }
      : {}),
  });

  useEffect(() => {
    if (fontsLoaded || fontError) {
      SplashScreen.hideAsync();
    }
  }, [fontError, fontsLoaded]);

  if (!fontsLoaded && !fontError) return null;

  return (
    <SafeAreaProvider>
      <ErrorBoundary>
        <QueryClientProvider client={queryClient}>
          <GestureHandlerRootView style={{ flex: 1 }}>
            <MaybeKeyboardProvider>
              <AppProvider>
                <RootLayoutNav />
              </AppProvider>
            </MaybeKeyboardProvider>
          </GestureHandlerRootView>
        </QueryClientProvider>
      </ErrorBoundary>
    </SafeAreaProvider>
  );
}
