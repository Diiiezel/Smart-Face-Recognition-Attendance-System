import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import React, { useRef } from "react";
import { Animated, Pressable, ScrollView, StyleSheet, Text, useWindowDimensions, View } from "react-native";

function RoleCard({
  title,
  subtitle,
  icon,
  gradient,
  iconBg,
  onPress,
}: {
  title: string;
  subtitle: string;
  icon: React.ReactNode;
  gradient: string[];
  iconBg: string;
  onPress: () => void;
  delay: number;
}) {
  const anim = useRef(new Animated.Value(1)).current;
  const handlePress = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    Animated.sequence([
      Animated.timing(anim, { toValue: 0.98, duration: 80, useNativeDriver: false }),
      Animated.timing(anim, { toValue: 1, duration: 80, useNativeDriver: false }),
    ]).start(onPress);
  };

  return (
    <Animated.View style={{ flex: 1, transform: [{ scale: anim }] }}>
      <Pressable onPress={handlePress} style={styles.cardPressable}>
        <LinearGradient
          colors={gradient as any}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.roleCard}
        >
          <View style={[styles.roleIconBg, { backgroundColor: iconBg }]}>{icon}</View>
          <View style={styles.roleBody}>
            <Text style={styles.roleTitle}>{title}</Text>
            <Text style={styles.roleSubtitle}>{subtitle}</Text>
          </View>
          <View style={styles.arrowBtn}>
            <Ionicons name="chevron-forward" size={17} color="rgba(255,255,255,0.92)" />
          </View>
        </LinearGradient>
      </Pressable>
    </Animated.View>
  );
}

export default function RoleSelect() {
  const colors = useColors();
  const { width } = useWindowDimensions();
  const { setRole } = useApp();
  const isCompact = width < 840;

  const handleSelect = async (role: "student" | "staff") => {
    await setRole(role);
    router.push(`/auth/login?role=${role}`);
  };

  return (
    <View style={[styles.page, { backgroundColor: colors.background }]}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        <View style={[styles.shell, isCompact && styles.shellCompact]}>
          <LinearGradient
            colors={["#0B1530", "#0F1B3C", "#1E3A7B"]}
            start={{ x: 0.1, y: 0 }}
            end={{ x: 0.9, y: 1 }}
            style={styles.hero}
          >
            <Text style={styles.eyebrow}>Smart Attendance</Text>
            <Text style={styles.heroTitle}>Welcome back</Text>
            <Text style={styles.heroSubtitle}>
              Select your role to continue to the attendance workspace.
            </Text>
            <View style={styles.securityBadge}>
              <Ionicons name="shield-checkmark" size={14} color="rgba(255,255,255,0.76)" />
              <Text style={styles.securityText}>Secure access</Text>
            </View>
          </LinearGradient>

          <View style={styles.content}>
            <View style={styles.sectionIntro}>
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Choose a workspace</Text>
              <Text style={[styles.sectionText, { color: colors.mutedForeground }]}>
                The selected role controls the existing login path and app dashboard.
              </Text>
            </View>

            <View style={[styles.cardsGroup, isCompact && styles.cardsGroupCompact]}>
              <RoleCard
                title="Continue as Student"
                subtitle="View attendance, enroll courses & show QR"
                icon={<Ionicons name="person" size={25} color="#FFFFFF" />}
                gradient={["#1D4ED8", "#2563EB"]}
                iconBg="rgba(255,255,255,0.18)"
                onPress={() => handleSelect("student")}
                delay={0}
              />
              <RoleCard
                title="Continue as Staff"
                subtitle="Manage courses, sessions & take attendance"
                icon={<Ionicons name="briefcase" size={25} color="#FFFFFF" />}
                gradient={["#4F46E5", "#6366F1"]}
                iconBg="rgba(255,255,255,0.18)"
                onPress={() => handleSelect("staff")}
                delay={100}
              />
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  arrowBtn: {
    alignItems: "center",
    backgroundColor: "rgba(255,255,255,0.12)",
    borderRadius: 10,
    height: 32,
    justifyContent: "center",
    width: 32,
  },
  cardPressable: {
    borderRadius: 24,
    flex: 1,
    overflow: "hidden",
  },
  cardsGroup: {
    flexDirection: "row",
    gap: 18,
  },
  cardsGroupCompact: {
    flexDirection: "column",
  },
  content: {
    gap: 22,
  },
  eyebrow: {
    color: "rgba(255,255,255,0.58)",
    fontFamily: "Inter_600SemiBold",
    fontSize: 12,
    fontWeight: "600",
    letterSpacing: 1.2,
    textTransform: "uppercase",
  },
  hero: {
    borderRadius: 32,
    gap: 12,
    minHeight: 320,
    padding: 36,
  },
  heroSubtitle: {
    color: "rgba(255,255,255,0.68)",
    fontFamily: "Inter_400Regular",
    fontSize: 16,
    lineHeight: 24,
    maxWidth: 620,
  },
  heroTitle: {
    color: "#FFFFFF",
    fontFamily: "Inter_700Bold",
    fontSize: 48,
    fontWeight: "700",
    letterSpacing: -1.2,
    lineHeight: 56,
  },
  page: {
    flex: 1,
  },
  roleBody: {
    flex: 1,
    gap: 5,
  },
  roleCard: {
    alignItems: "center",
    borderRadius: 24,
    flex: 1,
    flexDirection: "row",
    gap: 18,
    minHeight: 156,
    paddingHorizontal: 24,
    paddingVertical: 26,
  },
  roleIconBg: {
    alignItems: "center",
    borderRadius: 16,
    height: 56,
    justifyContent: "center",
    width: 56,
  },
  roleSubtitle: {
    color: "rgba(255,255,255,0.68)",
    fontFamily: "Inter_400Regular",
    fontSize: 13,
    lineHeight: 19,
  },
  roleTitle: {
    color: "#FFFFFF",
    fontFamily: "Inter_700Bold",
    fontSize: 18,
    fontWeight: "700",
    letterSpacing: -0.2,
  },
  scrollContent: {
    flexGrow: 1,
  },
  sectionIntro: {
    gap: 7,
  },
  sectionText: {
    fontFamily: "Inter_400Regular",
    fontSize: 14,
    lineHeight: 21,
  },
  sectionTitle: {
    fontFamily: "Inter_700Bold",
    fontSize: 28,
    fontWeight: "700",
    letterSpacing: -0.5,
  },
  securityBadge: {
    alignItems: "center",
    alignSelf: "flex-start",
    backgroundColor: "rgba(255,255,255,0.08)",
    borderColor: "rgba(255,255,255,0.1)",
    borderRadius: 999,
    borderWidth: 1,
    flexDirection: "row",
    gap: 7,
    marginTop: 20,
    paddingHorizontal: 13,
    paddingVertical: 8,
  },
  securityText: {
    color: "rgba(255,255,255,0.76)",
    fontFamily: "Inter_600SemiBold",
    fontSize: 12,
    fontWeight: "600",
  },
  shell: {
    alignSelf: "center",
    gap: 28,
    maxWidth: 1120,
    padding: 28,
    width: "100%",
  },
  shellCompact: {
    padding: 16,
  },
});
