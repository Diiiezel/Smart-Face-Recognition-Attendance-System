import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import React, { useRef } from "react";
import { Animated, Platform, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

function RoleCard({
  title,
  subtitle,
  icon,
  gradient,
  iconBg,
  onPress,
  delay,
}: {
  title: string;
  subtitle: string;
  icon: React.ReactNode;
  gradient: string[];
  iconBg: string;
  onPress: () => void;
  delay: number;
}) {
  const anim = useRef(new Animated.Value(1)).current;
  const handlePress = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    Animated.sequence([
      Animated.timing(anim, { toValue: 0.96, duration: 80, useNativeDriver: true }),
      Animated.timing(anim, { toValue: 1, duration: 80, useNativeDriver: true }),
    ]).start(onPress);
  };
  return (
    <Animated.View style={{ transform: [{ scale: anim }] }}>
      <Pressable onPress={handlePress} style={{ borderRadius: 20, overflow: "hidden" }}>
        <LinearGradient
          colors={gradient as any}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.roleCard}
        >
          <View style={[styles.roleIconBg, { backgroundColor: iconBg }]}>{icon}</View>
          <View style={{ flex: 1, gap: 4 }}>
            <Text style={styles.roleTitle}>{title}</Text>
            <Text style={styles.roleSubtitle}>{subtitle}</Text>
          </View>
          <View style={styles.arrowBtn}>
            <Ionicons name="chevron-forward" size={16} color="rgba(255,255,255,0.9)" />
          </View>
        </LinearGradient>
      </Pressable>
    </Animated.View>
  );
}

export default function RoleSelect() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { setRole } = useApp();

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  const handleSelect = async (role: "student" | "staff") => {
    await setRole(role);
    router.push(`/auth/login?role=${role}`);
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <LinearGradient
        colors={["#0B1530", "#0F1B3C", "#1E3A7B"]}
        start={{ x: 0.1, y: 0 }}
        end={{ x: 0.9, y: 1 }}
        style={[styles.header, { paddingTop: topPad + 36 }]}
      >
        <Text style={styles.headerTitle}>Welcome Back</Text>
        <Text style={styles.headerSubtitle}>
          Select your role to continue to the Smart Attendance system
        </Text>
      </LinearGradient>

      <ScrollView
        bounces={false}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[styles.content, { paddingBottom: bottomPad + 20 }]}
      >
        <View style={styles.contentBody}>
          <View style={styles.cardsGroup}>
            <RoleCard
              title="Continue as Student"
              subtitle="View attendance, enroll courses & show QR"
              icon={<Ionicons name="person" size={24} color="#FFFFFF" />}
              gradient={["#1D4ED8", "#2563EB"]}
              iconBg="rgba(255,255,255,0.18)"
              onPress={() => handleSelect("student")}
              delay={0}
            />
            <RoleCard
              title="Continue as Staff"
              subtitle="Manage courses, sessions & take attendance"
              icon={<Ionicons name="briefcase" size={24} color="#FFFFFF" />}
              gradient={["#4F46E5", "#6366F1"]}
              iconBg="rgba(255,255,255,0.18)"
              onPress={() => handleSelect("staff")}
              delay={100}
            />
          </View>

          <View style={styles.footer}>
            <View style={styles.bottomBadge}>
              <Ionicons name="shield-checkmark" size={12} color={colors.mutedForeground} />
              <Text style={[styles.bottomBadgeText, { color: colors.mutedForeground }]}>
                Secure Access
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: 24,
    paddingBottom: 44,
    borderBottomLeftRadius: 32,
    borderBottomRightRadius: 32,
    gap: 10,
  },
  headerTitle: {
    fontSize: 32,
    fontWeight: "700",
    color: "#FFFFFF",
    fontFamily: "Inter_700Bold",
    letterSpacing: -0.8,
  },
  headerSubtitle: {
    fontSize: 14,
    color: "rgba(255,255,255,0.6)",
    fontFamily: "Inter_400Regular",
    lineHeight: 21,
  },
  content: {
    flexGrow: 1,
    paddingHorizontal: 20,
    paddingTop: 28,
  },
  contentBody: {
    flex: 1,
    minHeight: 420,
    justifyContent: "space-between",
    gap: 32,
  },
  cardsGroup: {
    gap: 14,
  },
  roleCard: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingVertical: 22,
    borderRadius: 20,
    gap: 16,
  },
  roleIconBg: {
    width: 48,
    height: 48,
    borderRadius: 13,
    alignItems: "center",
    justifyContent: "center",
  },
  arrowBtn: {
    width: 28,
    height: 28,
    borderRadius: 8,
    backgroundColor: "rgba(255,255,255,0.12)",
    alignItems: "center",
    justifyContent: "center",
  },
  roleTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: "#FFFFFF",
    fontFamily: "Inter_700Bold",
    letterSpacing: -0.2,
  },
  roleSubtitle: {
    fontSize: 12,
    color: "rgba(255,255,255,0.65)",
    fontFamily: "Inter_400Regular",
    lineHeight: 17,
  },
  footer: {
    justifyContent: "center",
  },
  bottomBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    alignSelf: "center",
    backgroundColor: "#FFFFFF",
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 100,
    borderWidth: 1,
    borderColor: "#E8ECF4",
  },
  bottomBadgeText: {
    fontSize: 12,
    fontFamily: "Inter_400Regular",
  },
});
