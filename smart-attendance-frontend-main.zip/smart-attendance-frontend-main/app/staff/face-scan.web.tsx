import { Badge, Button, Card } from "@/components/UI";
import { ScreenHeader } from "@/components/ScreenHeader";
import { useApp, type SessionReportStudent } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { Ionicons } from "@expo/vector-icons";
import { CameraView, useCameraPermissions } from "expo-camera";
import * as Haptics from "expo-haptics";
import { useLocalSearchParams } from "expo-router";
import React, { useEffect, useMemo, useRef, useState } from "react";
import { Platform, ScrollView, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const SCAN_INTERVAL_MS = 2600;
const RECOGNITION_COOLDOWN_MS = 10000;

type ToastState = {
  tone: "success" | "error";
  message: string;
} | null;

export default function FaceScan() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { sessions, loadSessionReport, markFaceAttendance, isLoading } = useApp();
  const params = useLocalSearchParams<{ sessionId?: string }>();
  const [cameraPermission, requestCameraPermission] = useCameraPermissions();

  const session = sessions.find((s) => s.id === params.sessionId) || sessions[0];
  const [recognized, setRecognized] = useState<SessionReportStudent[]>([]);
  const [currentScan, setCurrentScan] = useState<SessionReportStudent | null>(null);
  const [error, setError] = useState("");
  const [cameraActive, setCameraActive] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [toast, setToast] = useState<ToastState>(null);
  const [cameraReady, setCameraReady] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const nativeCameraRef = useRef<CameraView | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const scanTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const toastTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const recognitionCooldownRef = useRef<Record<string, number>>({});

  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  const showToast = (nextToast: ToastState) => {
    if (toastTimeoutRef.current) {
      clearTimeout(toastTimeoutRef.current);
    }

    setToast(nextToast);

    if (nextToast) {
      toastTimeoutRef.current = setTimeout(() => {
        setToast(null);
      }, 2600);
    }
  };

  const clearScheduledScan = () => {
    if (scanTimeoutRef.current) {
      clearTimeout(scanTimeoutRef.current);
      scanTimeoutRef.current = null;
    }
  };

  const refreshRecognized = async () => {
    if (!session?.id) return;
    const report = await loadSessionReport(session.id);
    const presentStudents = report.students.filter((item) => item.status === "present");
    setRecognized(presentStudents);
  };

  const stopCamera = () => {
    clearScheduledScan();
    streamRef.current?.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
    setCameraActive(false);
    setCameraReady(false);
    setIsScanning(false);
    setError("");
  };

  useEffect(() => {
    if (!session?.id) return;
    void loadSessionReport(session.id).then((report) => {
      const presentStudents = report.students.filter((student) => student.status === "present");
      setRecognized(presentStudents);
    });
  }, [loadSessionReport, session?.id]);

  useEffect(() => {
    return () => {
      clearScheduledScan();
      if (toastTimeoutRef.current) {
        clearTimeout(toastTimeoutRef.current);
      }
      streamRef.current?.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    };
  }, []);

  const submitCapture = async (asset: { uri: string; name?: string; mimeType?: string }) => {
    if (!session?.id || isScanning) {
      return;
    }

    setError("");
    setIsScanning(true);

    try {
      const student = await markFaceAttendance(session.id, asset);
      const now = Date.now();
      const lastSeenAt = recognitionCooldownRef.current[student.universityId] ?? 0;

      if (now - lastSeenAt < RECOGNITION_COOLDOWN_MS) {
        setCurrentScan(student);
        return;
      }

      recognitionCooldownRef.current[student.universityId] = now;
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setCurrentScan(student);
      showToast({
        tone: "success",
        message: `${student.name} checked in successfully`,
      });
      await refreshRecognized();
    } catch (err) {
      const message = err instanceof Error ? err.message : "Unable to verify face.";
      setError(message);
      showToast({
        tone: "error",
        message,
      });
    } finally {
      setIsScanning(false);
    }
  };

  const captureFromCamera = async () => {
    if (!cameraActive || !cameraReady) {
      return;
    }

    if (Platform.OS !== "web") {
      const photo = await nativeCameraRef.current?.takePictureAsync({
        quality: 0.65,
        skipProcessing: true,
        shutterSound: false,
      });

      if (!photo?.uri) {
        setError("Unable to capture camera frame.");
        return;
      }

      await submitCapture({
        uri: photo.uri,
        name: "face-capture.jpg",
        mimeType: "image/jpeg",
      });
      return;
    }

    if (!videoRef.current) {
      return;
    }

    const video = videoRef.current;
    const canvas = document.createElement("canvas");
    canvas.width = video.videoWidth || 720;
    canvas.height = video.videoHeight || 720;
    const context = canvas.getContext("2d");

    if (!context) {
      setError("Unable to capture camera frame.");
      return;
    }

    context.drawImage(video, 0, 0, canvas.width, canvas.height);
    const uri = canvas.toDataURL("image/jpeg", 0.92);

    await submitCapture({
      uri,
      name: "face-capture.jpg",
      mimeType: "image/jpeg",
    });
  };

  const scheduleNextScan = () => {
    clearScheduledScan();

    if (!cameraActive) {
      return;
    }

    scanTimeoutRef.current = setTimeout(() => {
      void captureFromCamera();
    }, SCAN_INTERVAL_MS);
  };

  const startCamera = async () => {
    if (Platform.OS !== "web") {
      setError("");
      const permission = cameraPermission?.granted
        ? cameraPermission
        : await requestCameraPermission();

      if (!permission.granted) {
        const message = "Camera access is required to scan faces.";
        setError(message);
        showToast({
          tone: "error",
          message,
        });
        return;
      }

      setCameraActive(true);
      return;
    }

    try {
      setError("");
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: "user",
          width: { ideal: 960 },
          height: { ideal: 960 },
        },
        audio: false,
      });
      streamRef.current?.getTracks().forEach((track) => track.stop());
      streamRef.current = stream;
      setCameraActive(true);
    } catch {
      const message = "Unable to access camera. Please allow camera permission and try again.";
      setError(message);
      showToast({
        tone: "error",
        message,
      });
    }
  };

  useEffect(() => {
    void startCamera();
  }, []);

  useEffect(() => {
    if (Platform.OS !== "web" || !cameraActive || !videoRef.current || !streamRef.current) {
      return;
    }

    const video = videoRef.current;
    video.srcObject = streamRef.current;

    const handleLoadedMetadata = () => {
      setCameraReady(true);
    };

    video.addEventListener("loadedmetadata", handleLoadedMetadata);

    void video.play().catch(() => {
      setError("Camera preview could not start.");
      setCameraReady(false);
    });

    return () => {
      video.removeEventListener("loadedmetadata", handleLoadedMetadata);
    };
  }, [cameraActive]);

  useEffect(() => {
    if (!cameraActive || !cameraReady || isScanning || isLoading) {
      clearScheduledScan();
      return;
    }

    scheduleNextScan();

    return () => {
      clearScheduledScan();
    };
  }, [cameraActive, cameraReady, isLoading, isScanning]);

  const scanStatus = useMemo(() => {
    if (!cameraActive) {
      return "Camera closed";
    }
    if (error) {
      return "Camera needs attention";
    }
    if (isScanning || isLoading) {
      return "Scanning face...";
    }
    return "Face detected automatically when ready";
  }, [cameraActive, error, isLoading, isScanning]);

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <ScreenHeader title="Face Recognition" showBack subtitle={session ? `${session.courseName} · ${session.courseCode}` : "Scanning"} dark />
      <ScrollView contentContainerStyle={[styles.webContent, { paddingBottom: bottomPad + 32 }]} showsVerticalScrollIndicator={false}>
        <View style={styles.cameraArea}>
          <View style={styles.cameraInner}>
            {Platform.OS === "web" && cameraActive ? (
              <View style={styles.videoFrame}>
                <video
                  ref={videoRef}
                  muted
                  playsInline
                  autoPlay
                  style={styles.webVideo as never}
                />
                <View style={styles.videoOverlay}>
                  <View
                    style={[
                      styles.corner,
                      styles.cornerTopLeft,
                      isScanning || currentScan ? styles.cornerDetected : null,
                    ]}
                  />
                  <View
                    style={[
                      styles.corner,
                      styles.cornerTopRight,
                      isScanning || currentScan ? styles.cornerDetected : null,
                    ]}
                  />
                  <View
                    style={[
                      styles.corner,
                      styles.cornerBottomLeft,
                      isScanning || currentScan ? styles.cornerDetected : null,
                    ]}
                  />
                  <View
                    style={[
                      styles.corner,
                      styles.cornerBottomRight,
                      isScanning || currentScan ? styles.cornerDetected : null,
                    ]}
                  />
                </View>
              </View>
            ) : Platform.OS !== "web" && cameraActive ? (
              <View style={styles.videoFrame}>
                <CameraView
                  ref={nativeCameraRef}
                  style={StyleSheet.absoluteFill}
                  facing="front"
                  mirror
                  active={cameraActive}
                  mode="picture"
                  onCameraReady={() => setCameraReady(true)}
                  onMountError={(event) => {
                    setCameraReady(false);
                    setError(event.message || "Camera preview could not start.");
                  }}
                />
                <View style={styles.videoOverlay} pointerEvents="none">
                  <View
                    style={[
                      styles.corner,
                      styles.cornerTopLeft,
                      isScanning || currentScan ? styles.cornerDetected : null,
                    ]}
                  />
                  <View
                    style={[
                      styles.corner,
                      styles.cornerTopRight,
                      isScanning || currentScan ? styles.cornerDetected : null,
                    ]}
                  />
                  <View
                    style={[
                      styles.corner,
                      styles.cornerBottomLeft,
                      isScanning || currentScan ? styles.cornerDetected : null,
                    ]}
                  />
                  <View
                    style={[
                      styles.corner,
                      styles.cornerBottomRight,
                      isScanning || currentScan ? styles.cornerDetected : null,
                    ]}
                  />
                </View>
              </View>
            ) : (
              <View style={styles.faceFrame}>
                <View style={[styles.corner, styles.cornerTopLeft]} />
                <View style={[styles.corner, styles.cornerTopRight]} />
                <View style={[styles.corner, styles.cornerBottomLeft]} />
                <View style={[styles.corner, styles.cornerBottomRight]} />
                <Ionicons name="videocam-outline" size={78} color="rgba(59,130,246,0.4)" />
              </View>
            )}
          </View>
          <Text style={styles.cameraLabel}>
            {cameraActive
              ? "Keep the student's face centered. Attendance will be recorded automatically."
              : "Camera closed. Tap Open Camera to resume automatic scanning."}
          </Text>

          <View style={styles.sessionInfo}>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
              <View
                style={{
                  width: 8,
                  height: 8,
                  borderRadius: 4,
                  backgroundColor: error ? "#EF4444" : "#10B981",
                }}
              />
              <Text style={{ color: "#FFF", fontSize: 12, fontFamily: "Inter_600SemiBold" }}>
                {scanStatus}
              </Text>
            </View>
            <Text style={{ color: "rgba(255,255,255,0.7)", fontSize: 12, fontFamily: "Inter_400Regular" }}>
              {recognized.length}/{session?.totalCount ?? 0} recognized
            </Text>
          </View>
        </View>

        <View style={{ gap: 12 }}>
          {toast ? (
            <Card
              style={{
                backgroundColor: toast.tone === "success" ? "#D1FAE5" : "#FEF2F2",
                borderColor: toast.tone === "success" ? "#6EE7B7" : "#FECACA",
                borderWidth: 1,
              }}
            >
              <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
                <Ionicons
                  name={toast.tone === "success" ? "checkmark-circle" : "alert-circle"}
                  size={18}
                  color={toast.tone === "success" ? "#059669" : "#B91C1C"}
                />
                <Text
                  style={{
                    flex: 1,
                    color: toast.tone === "success" ? "#065F46" : "#B91C1C",
                    fontFamily: "Inter_600SemiBold",
                    fontSize: 13,
                  }}
                >
                  {toast.message}
                </Text>
              </View>
            </Card>
          ) : null}

          {error ? (
            <Card style={{ backgroundColor: "#FEF2F2", borderColor: "#FECACA", borderWidth: 1 }}>
              <Text style={{ color: "#B91C1C", fontFamily: "Inter_500Medium" }}>{error}</Text>
            </Card>
          ) : null}

          <View style={styles.cameraActions}>
            <Button
              title={cameraActive ? "Close Camera" : "Open Camera"}
              onPress={() => void (cameraActive ? Promise.resolve(stopCamera()) : startCamera())}
              variant={cameraActive ? "outline" : "primary"}
              fullWidth={false}
              style={{ minWidth: 150 }}
              disabled={isScanning || isLoading}
            />
          </View>
        </View>

        {currentScan && (
          <View>
            <Card style={{ backgroundColor: "#D1FAE5", borderWidth: 2, borderColor: "#6EE7B7" }}>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
                <View style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: "#10B981", alignItems: "center", justifyContent: "center" }}>
                  <Ionicons name="checkmark" size={24} color="#FFF" />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontSize: 15, fontWeight: "700", color: "#065F46", fontFamily: "Inter_700Bold" }}>
                    {currentScan.name}
                  </Text>
                  <Text style={{ fontSize: 12, color: "#047857", fontFamily: "Inter_400Regular" }}>
                    {currentScan.universityId}
                    {currentScan.matchScore ? ` · ${currentScan.matchScore.toFixed(1)}% match` : ""}
                  </Text>
                </View>
                <Badge label="Marked" variant="success" />
              </View>
            </Card>
          </View>
        )}

        <View style={{ gap: 10 }}>
          <Text style={{ fontSize: 15, fontWeight: "700", color: colors.foreground, fontFamily: "Inter_700Bold" }}>
            Recognized ({recognized.length})
          </Text>
          {recognized.map((student) => (
            <Card key={student.id} style={{ padding: 12 }}>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
                <View style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: "#DBEAFE", alignItems: "center", justifyContent: "center" }}>
                  <Ionicons name="person" size={20} color="#2563EB" />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontSize: 14, fontWeight: "600", color: colors.foreground, fontFamily: "Inter_600SemiBold" }}>
                    {student.name}
                  </Text>
                  <Text style={{ fontSize: 12, color: colors.mutedForeground, fontFamily: "Inter_400Regular" }}>
                    {student.universityId}
                    {student.time ? ` · ${student.time}` : ""}
                  </Text>
                </View>
                <View style={{ alignItems: "flex-end", gap: 4 }}>
                  <Badge label="Present" variant="success" />
                  {student.matchScore ? (
                    <Text style={{ fontSize: 10, color: colors.mutedForeground, fontFamily: "Inter_400Regular" }}>
                      {student.matchScore.toFixed(1)}%
                    </Text>
                  ) : null}
                </View>
              </View>
            </Card>
          ))}
          {recognized.length === 0 && (
            <View style={{ alignItems: "center", padding: 24, gap: 8 }}>
              <Ionicons name="scan-outline" size={36} color={colors.mutedForeground} />
              <Text style={{ color: colors.mutedForeground, fontFamily: "Inter_500Medium" }}>
                Waiting for a recognized student...
              </Text>
            </View>
          )}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  webContent: {
    alignSelf: "center",
    gap: 18,
    maxWidth: 1120,
    padding: 28,
    width: "100%",
  },
  cameraArea: {
    height: 440,
    backgroundColor: "#0F1B3C",
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
    overflow: "hidden",
    borderRadius: 28,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.08)",
  },
  cameraInner: {
    width: 280,
    height: 280,
    alignItems: "center",
    justifyContent: "center",
  },
  videoFrame: {
    width: 280,
    height: 280,
    borderRadius: 24,
    overflow: "hidden",
    position: "relative",
    backgroundColor: "#0B1530",
  },
  webVideo: {
    width: "100%",
    height: "100%",
    objectFit: "cover",
    transform: "scaleX(-1)",
  },
  videoOverlay: {
    ...StyleSheet.absoluteFillObject,
    alignItems: "center",
    justifyContent: "center",
  },
  faceFrame: {
    width: 240,
    height: 240,
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
  },
  corner: {
    position: "absolute",
    width: 28,
    height: 28,
    borderColor: "#3B82F6",
  },
  cornerDetected: {
    borderColor: "#10B981",
  },
  cornerTopLeft: {
    top: 0,
    left: 0,
    borderTopWidth: 3,
    borderLeftWidth: 3,
  },
  cornerTopRight: {
    top: 0,
    right: 0,
    borderTopWidth: 3,
    borderRightWidth: 3,
  },
  cornerBottomLeft: {
    bottom: 0,
    left: 0,
    borderBottomWidth: 3,
    borderLeftWidth: 3,
  },
  cornerBottomRight: {
    bottom: 0,
    right: 0,
    borderBottomWidth: 3,
    borderRightWidth: 3,
  },
  cameraLabel: {
    position: "absolute",
    bottom: 64,
    color: "rgba(255,255,255,0.72)",
    fontSize: 12,
    fontFamily: "Inter_500Medium",
    textAlign: "center",
    paddingHorizontal: 20,
  },
  sessionInfo: {
    position: "absolute",
    bottom: 18,
    left: 22,
    right: 22,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  cameraActions: {
    alignItems: "center",
    gap: 14,
  },
});
