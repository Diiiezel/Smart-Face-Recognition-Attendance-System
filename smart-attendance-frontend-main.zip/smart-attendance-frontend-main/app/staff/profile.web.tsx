import { Badge, Card } from "@/components/UI";
import { AccountSettingsCard } from "@/components/AccountSettingsCard";
import { ScreenHeader } from "@/components/ScreenHeader";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  useWindowDimensions,
  View,
} from "react-native";

interface InfoRowProps {
  label: string;
  value: string;
  icon: string;
}

function InfoRow({ label, value, icon }: InfoRowProps) {
  const colors = useColors();

  return (
    <View style={[styles.infoRow, { borderBottomColor: colors.border }]}>
      <View style={[styles.infoIcon, { backgroundColor: colors.muted }]}>
        <Ionicons name={icon as any} size={18} color={colors.primary} />
      </View>
      <View style={styles.infoText}>
        <Text style={[styles.infoLabel, { color: colors.mutedForeground }]}>{label}</Text>
        <Text style={[styles.infoValue, { color: colors.foreground }]}>{value}</Text>
      </View>
    </View>
  );
}

function formatDoctorName(name?: string | null) {
  const cleanName = (name || "Doctor").replace(/\.cs$/i, "").trim();
  return cleanName.toUpperCase().startsWith("DR.") ? cleanName : `DR. ${cleanName}`;
}

export default function StaffProfile() {
  const colors = useColors();
  const { staffProfile, logout } = useApp();
  const { width } = useWindowDimensions();
  const isWide = width >= 960;
  const [isSigningOut, setIsSigningOut] = useState(false);
  const doctorName = formatDoctorName(staffProfile?.name);

  const performSignOut = async () => {
    setIsSigningOut(true);

    try {
      await logout();
      router.replace("/role-select");
    } catch {
      setIsSigningOut(false);
      Alert.alert("Sign Out", "Unable to sign out. Please try again.");
    }
  };

  const handleSignOut = () => {
    if (isSigningOut) {
      return;
    }

    if (Platform.OS === "web") {
      const confirmed =
        typeof globalThis.confirm === "function"
          ? globalThis.confirm("Are you sure you want to sign out?")
          : true;

      if (confirmed) {
        void performSignOut();
      }
      return;
    }

    Alert.alert("Sign Out", "Are you sure you want to sign out?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Sign Out",
        style: "destructive",
        onPress: () => void performSignOut(),
      },
    ]);
  };

  if (!staffProfile) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.background }}>
        <ScreenHeader title="My Profile" showBack subtitle="Staff" />
        <View style={styles.emptyState}>
          {isSigningOut ? (
            <>
              <ActivityIndicator size="small" color={colors.primary} />
              <Text style={[styles.emptyStateText, { color: colors.mutedForeground }]}>
                Signing out...
              </Text>
            </>
          ) : (
            <Text style={[styles.emptyStateText, { color: colors.mutedForeground }]}>
              Profile unavailable.
            </Text>
          )}
        </View>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <ScreenHeader title="My Profile" showBack subtitle="Doctor Settings" />
      <ScrollView
        contentContainerStyle={[
          styles.page,
          { paddingHorizontal: isWide ? 32 : 18, paddingBottom: 44 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <View style={[styles.profileGrid, { flexDirection: isWide ? "row" : "column" }]}>
          <Card style={styles.identityPanel}>
            <View style={styles.identityTopline}>
              <Text style={[styles.kicker, { color: colors.mutedForeground }]}>
                Staff profile
              </Text>
              <Badge label="Staff" variant="primary" />
            </View>

            <View style={styles.identityMain}>
              <View style={styles.avatarLarge}>
                <Ionicons name="briefcase" size={48} color="#6366F1" />
              </View>
              <View style={styles.nameBlock}>
                <Text style={[styles.profileName, { color: colors.foreground }]}>
                  {doctorName}
                </Text>
                <Text style={[styles.profileSubline, { color: colors.mutedForeground }]}>
                  {staffProfile.email}
                </Text>
              </View>
            </View>

          </Card>

          <View style={styles.detailColumn}>
            <Card style={styles.detailCard}>
              <View style={styles.cardHeader}>
                <View>
                  <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
                    Account details
                  </Text>
                  <Text style={[styles.sectionSubtitle, { color: colors.mutedForeground }]}>
                    Staff identity used across courses and sessions
                  </Text>
                </View>
              </View>
              <InfoRow label="Full Name" value={doctorName} icon="person-outline" />
              <InfoRow label="Email" value={staffProfile.email} icon="mail-outline" />
            </Card>

            <AccountSettingsCard mode="staff" />

            <Pressable onPress={handleSignOut} disabled={isSigningOut}>
              <View style={[styles.signOutRow, { borderColor: colors.border, backgroundColor: colors.card }, isSigningOut && styles.signOutRowDisabled]}>
                <Ionicons name="log-out-outline" size={17} color={colors.mutedForeground} />
                {isSigningOut ? (
                  <ActivityIndicator size="small" color={colors.mutedForeground} />
                ) : (
                  <Text style={[styles.signOutText, { color: colors.mutedForeground }]}>
                    Sign Out
                  </Text>
                )}
              </View>
            </Pressable>

            <Card style={styles.statusPanel}>
              <View style={styles.statusIcon}>
                <Ionicons name="shield-checkmark" size={22} color="#2563EB" />
              </View>
              <View style={styles.statusCopy}>
                <Text style={[styles.statusTitle, { color: colors.foreground }]}>
                  Academic staff access
                </Text>
                <Text style={[styles.statusDescription, { color: colors.mutedForeground }]}>
                  This account manages courses, sessions, attendance records, and operational reports through the existing staff workflow.
                </Text>
              </View>
            </Card>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  avatarLarge: {
    alignItems: "center",
    backgroundColor: "#EEF2FF",
    borderColor: "#C7D2FE",
    borderRadius: 50,
    borderWidth: 4,
    height: 100,
    justifyContent: "center",
    width: 100,
  },
  cardHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 4,
  },
  detailCard: {
    gap: 2,
  },
  detailColumn: {
    flex: 1,
    gap: 18,
    minWidth: 0,
  },
  emptyState: {
    alignItems: "center",
    flex: 1,
    gap: 12,
    justifyContent: "center",
    paddingHorizontal: 24,
  },
  emptyStateText: {
    fontFamily: "Inter_500Medium",
    fontSize: 14,
  },
  identityMain: {
    alignItems: "center",
    gap: 18,
    paddingVertical: 22,
  },
  identityPanel: {
    flex: 0.85,
    gap: 24,
    minWidth: 300,
  },
  identityTopline: {
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 12,
  },
  infoIcon: {
    alignItems: "center",
    borderRadius: 12,
    height: 40,
    justifyContent: "center",
    width: 40,
  },
  infoLabel: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 11,
    letterSpacing: 0.6,
    textTransform: "uppercase",
  },
  infoRow: {
    alignItems: "center",
    borderBottomWidth: 1,
    flexDirection: "row",
    gap: 14,
    paddingVertical: 15,
  },
  infoText: {
    flex: 1,
    minWidth: 0,
  },
  infoValue: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 15,
    marginTop: 2,
  },
  kicker: {
    fontFamily: "Inter_700Bold",
    fontSize: 11,
    letterSpacing: 0.8,
    textTransform: "uppercase",
  },
  nameBlock: {
    alignItems: "center",
  },
  page: {
    alignSelf: "center",
    maxWidth: 1180,
    paddingTop: 28,
    width: "100%",
  },
  profileGrid: {
    gap: 22,
  },
  profileName: {
    fontFamily: "Inter_700Bold",
    fontSize: 30,
    fontWeight: "700",
    letterSpacing: -0.6,
    textAlign: "center",
  },
  profileSubline: {
    fontFamily: "Inter_500Medium",
    fontSize: 14,
    marginTop: 4,
    textAlign: "center",
  },
  sectionSubtitle: {
    fontFamily: "Inter_400Regular",
    fontSize: 13,
    marginTop: 3,
  },
  sectionTitle: {
    fontFamily: "Inter_700Bold",
    fontSize: 18,
    fontWeight: "700",
  },
  signOutRow: {
    alignItems: "center",
    borderRadius: 14,
    borderWidth: 1,
    flexDirection: "row",
    gap: 8,
    justifyContent: "center",
    paddingVertical: 14,
  },
  signOutRowDisabled: {
    opacity: 0.7,
  },
  signOutText: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 14,
  },
  statusCopy: {
    flex: 1,
    gap: 4,
  },
  statusDescription: {
    fontFamily: "Inter_400Regular",
    fontSize: 13,
    lineHeight: 20,
  },
  statusIcon: {
    alignItems: "center",
    backgroundColor: "#F8FAFC",
    borderRadius: 14,
    height: 46,
    justifyContent: "center",
    width: 46,
  },
  statusPanel: {
    alignItems: "center",
    flexDirection: "row",
    gap: 14,
  },
  statusTitle: {
    fontFamily: "Inter_700Bold",
    fontSize: 15,
  },
});
