import { Badge, Button, Card } from "@/components/UI";
import { ScreenHeader } from "@/components/ScreenHeader";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { getManagedStudentsForCourse } from "@/services/studentsService";
import { buildCsv, exportCsv } from "@/utils/csvExport";
import { Ionicons } from "@expo/vector-icons";
import { useLocalSearchParams } from "expo-router";
import React, { useEffect, useMemo, useState } from "react";
import { ActivityIndicator, FlatList, StyleSheet, Text, View } from "react-native";

import type { ManagedStudent } from "@/mocks/students";

export default function CourseStudentsScreen() {
  const colors = useColors();
  const { courses } = useApp();
  const params = useLocalSearchParams<{ courseId?: string; courseCode?: string }>();
  const courseId = typeof params.courseId === "string" ? params.courseId : "";
  const courseCode = typeof params.courseCode === "string" ? params.courseCode : "";
  const [isLoading, setIsLoading] = useState(true);
  const [students, setStudents] = useState<ManagedStudent[]>([]);
  const [errorMessage, setErrorMessage] = useState("");

  const course = useMemo(
    () =>
      courses.find((item) => item.id === courseId || item.courseIds?.includes(courseId)) ||
      courses.find((item) => item.code === courseCode) ||
      null,
    [courseCode, courseId, courses],
  );
  const faceReady = students.filter((student) => student.faceEnrolled).length;
  const avgAttendance =
    students.length > 0 ? Math.round(students.reduce((sum, student) => sum + student.attendanceRate, 0) / students.length) : 0;

  useEffect(() => {
    let mounted = true;
    void (async () => {
      try {
        setErrorMessage("");
        const enrolledStudents = await getManagedStudentsForCourse(courseId, courseCode);
        if (!mounted) return;
        setStudents(enrolledStudents);
      } catch (error) {
        if (!mounted) return;
        setStudents([]);
        setErrorMessage(error instanceof Error ? error.message : "Unable to load course roster.");
      } finally {
        if (mounted) setIsLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, [courseCode, courseId]);

  const handleExportStudents = async () => {
    const csv = [
      buildCsv(["Course Name", course?.name || "Course"], []),
      buildCsv(["Course Code", course?.code || courseCode || "Course"], []),
      buildCsv(["Total sessions", String(Number(course?.sessionsCount ?? 0))], []),
      "",
      buildCsv(
        ["University Code", "Full Name"],
        students.map((student) => [
          student.universityId,
          student.fullName,
        ]),
      ),
    ].join("\n");

    await exportCsv(`${course?.code || courseCode || "course"}-students.csv`, csv);
  };

  if (isLoading) {
    return (
      <View style={[styles.page, { backgroundColor: colors.background }]}>
        <ScreenHeader title={course?.name || "Course Students"} subtitle={course?.code || courseCode || "Course"} showBack />
        <View style={styles.loadingState}>
          <ActivityIndicator size="large" color={colors.primary} />
          <Text style={[styles.loadingText, { color: colors.mutedForeground }]}>Loading students...</Text>
        </View>
      </View>
    );
  }

  return (
    <View style={[styles.page, { backgroundColor: colors.background }]}>
      <ScreenHeader title={course?.name || "Course Students"} subtitle={course?.code || courseCode || "Course"} showBack />
      <View style={styles.shell}>
        <View style={styles.summaryGrid}>
          <Card style={styles.heroCard}>
            <Text style={[styles.eyebrow, { color: colors.mutedForeground }]}>Course roster</Text>
            <Text style={[styles.heroTitle, { color: colors.foreground }]}>{course?.name || "Course"}</Text>
            <Text style={[styles.heroCopy, { color: colors.mutedForeground }]}>
              {course?.code || courseCode} · {course?.department || "N/A"} · {course?.level || "N/A"}
            </Text>
            <Button title="Export CSV" onPress={handleExportStudents} variant="outline" disabled={students.length === 0} fullWidth={false} />
          </Card>
          <Card style={styles.metricCard}>
            <Text style={[styles.metricLabel, { color: colors.mutedForeground }]}>Students</Text>
            <Text style={[styles.metricValue, { color: colors.primary }]}>{students.length}</Text>
          </Card>
          <Card style={styles.metricCard}>
            <Text style={[styles.metricLabel, { color: colors.mutedForeground }]}>Face ready</Text>
            <Text style={[styles.metricValue, { color: colors.success }]}>{faceReady}</Text>
          </Card>
          <Card style={styles.metricCard}>
            <Text style={[styles.metricLabel, { color: colors.mutedForeground }]}>Avg. attendance</Text>
            <Text style={[styles.metricValue, { color: avgAttendance >= 75 ? colors.success : colors.warning }]}>{avgAttendance}%</Text>
          </Card>
        </View>

        {errorMessage ? (
          <Card style={styles.errorCard}>
            <Text style={[styles.errorText, { color: colors.destructive }]}>{errorMessage}</Text>
          </Card>
        ) : null}

        <FlatList
          data={students}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.list}
          renderItem={({ item }) => (
            <Card style={styles.studentCard}>
              <View style={styles.studentHeader}>
                <View style={[styles.avatar, { backgroundColor: colors.muted }]}>
                  <Ionicons name="person" size={20} color={colors.mutedForeground} />
                </View>
                <View style={styles.studentMain}>
                  <Text style={[styles.studentName, { color: colors.foreground }]}>{item.fullName}</Text>
                  <Text style={[styles.studentMeta, { color: colors.mutedForeground }]}>
                    {item.universityId} · {item.email || "No email"}
                  </Text>
                </View>
                <Badge label={item.faceEnrolled ? "Face Enrolled" : "Not Enrolled"} variant={item.faceEnrolled ? "success" : "danger"} />
              </View>
              <View style={styles.infoGrid}>
                <View>
                  <Text style={[styles.infoLabel, { color: colors.mutedForeground }]}>Major</Text>
                  <Text style={[styles.infoValue, { color: colors.foreground }]}>{item.major}</Text>
                </View>
                <View>
                  <Text style={[styles.infoLabel, { color: colors.mutedForeground }]}>Level</Text>
                  <Text style={[styles.infoValue, { color: colors.foreground }]}>{item.level}</Text>
                </View>
                <View>
                  <Text style={[styles.infoLabel, { color: colors.mutedForeground }]}>Attendance</Text>
                  <Text style={[styles.infoValue, { color: item.attendanceRate >= 75 ? colors.success : colors.warning }]}>
                    {item.attendanceRate}%
                  </Text>
                </View>
              </View>
            </Card>
          )}
          ListEmptyComponent={
            <Card style={styles.emptyCard}>
              <Ionicons name="people-outline" size={40} color={colors.mutedForeground} />
              <Text style={[styles.emptyTitle, { color: colors.foreground }]}>No students enrolled in this course</Text>
            </Card>
          }
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  avatar: {
    alignItems: "center",
    borderRadius: 14,
    height: 44,
    justifyContent: "center",
    width: 44,
  },
  emptyCard: {
    alignItems: "center",
    gap: 10,
    paddingVertical: 44,
  },
  emptyTitle: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 16,
    textAlign: "center",
  },
  errorCard: {
    borderColor: "rgba(220, 38, 38, 0.28)",
    borderWidth: 1,
    paddingVertical: 14,
  },
  errorText: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 14,
  },
  eyebrow: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 12,
    letterSpacing: 0.7,
    textTransform: "uppercase",
  },
  heroCard: {
    flex: 2,
    gap: 10,
    minWidth: 360,
  },
  heroCopy: {
    fontFamily: "Inter_400Regular",
    fontSize: 14,
  },
  heroTitle: {
    fontFamily: "Inter_700Bold",
    fontSize: 26,
    letterSpacing: -0.4,
  },
  infoGrid: {
    flexDirection: "row",
    gap: 28,
    paddingLeft: 58,
  },
  infoLabel: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 11,
    letterSpacing: 0.5,
    textTransform: "uppercase",
  },
  infoValue: {
    fontFamily: "Inter_700Bold",
    fontSize: 14,
    marginTop: 4,
  },
  list: {
    gap: 12,
    paddingBottom: 36,
  },
  loadingState: {
    alignItems: "center",
    flex: 1,
    gap: 12,
    justifyContent: "center",
  },
  loadingText: {
    fontFamily: "Inter_500Medium",
    fontSize: 14,
  },
  metricCard: {
    flex: 1,
    justifyContent: "center",
    minWidth: 180,
  },
  metricLabel: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 12,
    letterSpacing: 0.6,
    textTransform: "uppercase",
  },
  metricValue: {
    fontFamily: "Inter_700Bold",
    fontSize: 34,
    letterSpacing: -0.8,
    marginTop: 6,
  },
  page: {
    flex: 1,
  },
  shell: {
    alignSelf: "center",
    gap: 18,
    maxWidth: 1180,
    padding: 28,
    width: "100%",
  },
  studentCard: {
    gap: 16,
  },
  studentHeader: {
    alignItems: "center",
    flexDirection: "row",
    gap: 14,
  },
  studentMain: {
    flex: 1,
    gap: 3,
  },
  studentMeta: {
    fontFamily: "Inter_400Regular",
    fontSize: 12,
  },
  studentName: {
    fontFamily: "Inter_700Bold",
    fontSize: 16,
  },
  summaryGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 16,
  },
});
