import { Badge, Card, SectionHeader } from "@/components/UI";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import React from "react";
import { Pressable, ScrollView, StyleSheet, Text, useWindowDimensions, View } from "react-native";

const QUICK_ACTIONS = [
  { label: "Create Course", subtitle: "Add a course", icon: "add-circle", route: "/staff/create-course", color: "#2563EB", bg: "#DBEAFE" },
  { label: "Create Session", subtitle: "Schedule attendance", icon: "calendar-number", route: "/staff/create-session", color: "#6366F1", bg: "#EEF2FF" },
  { label: "Open Sessions", subtitle: "Start or manage attendance", icon: "play-circle", route: "/staff/open-session", color: "#0EA5E9", bg: "#E0F2FE" },
  { label: "Manage Courses", subtitle: "View course rosters", icon: "albums", route: "/staff/all-courses", color: "#10B981", bg: "#D1FAE5" },
  { label: "Reports", subtitle: "Review attendance", icon: "bar-chart", route: "/staff/reports", color: "#F59E0B", bg: "#FEF3C7" },
];

function formatDoctorName(name?: string | null) {
  const cleanName = (name || "Staff").replace(/\.cs$/i, "").trim();
  return cleanName.toUpperCase().startsWith("DR.") ? cleanName : `DR. ${cleanName}`;
}

export default function StaffDashboard() {
  const colors = useColors();
  const { width } = useWindowDimensions();
  const { staffProfile, courses, sessions } = useApp();
  const isCompact = width < 900;

  const openSessions = sessions.filter((s) => s.isOpen);
  const doctorName = formatDoctorName(staffProfile?.name);
  const activeStudentCount = courses.reduce((sum, course) => sum + course.enrolledCount, 0);

  return (
    <ScrollView
      style={[styles.page, { backgroundColor: colors.background }]}
      showsVerticalScrollIndicator={false}
      contentContainerStyle={styles.scrollContent}
    >
      <View style={[styles.shell, isCompact && styles.shellCompact]}>
        <LinearGradient
          colors={["#3730A3", "#4F46E5", "#6366F1"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.hero}
        >
          <View style={styles.heroTop}>
            <View style={styles.heroCopy}>
              <Text style={styles.eyebrow}>Staff operations</Text>
              <Text style={styles.heroTitle} numberOfLines={2}>
                Welcome back, {doctorName}
              </Text>
              <Text style={styles.heroSubtitle}>
                Manage live attendance, sessions, course rosters, and reports from one workspace.
              </Text>
            </View>
            <Pressable
              style={({ pressed, hovered }) => [
                styles.profileButton,
                hovered && styles.profileButtonHover,
                pressed && { opacity: 0.82 },
              ]}
              onPress={() => router.push("/staff/profile")}
            >
              <Ionicons name="briefcase" size={22} color="#6366F1" />
              <Text style={styles.profileButtonText}>Profile</Text>
            </Pressable>
          </View>

          <View style={[styles.heroStats, isCompact && styles.heroStatsCompact]}>
            <View style={styles.heroStat}>
              <Text style={styles.heroStatValue}>{courses.length}</Text>
              <Text style={styles.heroStatLabel}>Courses</Text>
            </View>
            <View style={styles.heroDivider} />
            <View style={styles.heroStat}>
              <Text style={styles.heroStatValue}>{openSessions.length}</Text>
              <Text style={styles.heroStatLabel}>Live sessions</Text>
            </View>
            <View style={styles.heroDivider} />
            <View style={styles.heroStat}>
              <Text style={styles.heroStatValue}>{activeStudentCount}</Text>
              <Text style={styles.heroStatLabel}>Enrolled students</Text>
            </View>
          </View>
        </LinearGradient>

        {openSessions.length > 0 && (
          <Pressable onPress={() => router.push("/staff/open-session")}>
            <View style={styles.liveBanner}>
              <View style={styles.liveIcon}>
                <Ionicons name="radio" size={22} color="#FFFFFF" />
              </View>
              <View style={styles.liveCopy}>
                <Text style={styles.liveTitle}>{openSessions[0].courseName} session is live</Text>
                <Text style={styles.liveMeta}>
                  {openSessions[0].presentCount}/{openSessions[0].totalCount} students present
                </Text>
              </View>
              <View style={styles.livePill}>
                <View style={styles.liveDot} />
                <Text style={styles.livePillText}>Live</Text>
              </View>
            </View>
          </Pressable>
        )}

        <View style={[styles.grid, isCompact && styles.gridCompact]}>
          <View style={styles.primaryColumn}>
            <View>
              <SectionHeader title="Quick actions" />
              <View style={[styles.actionsGrid, isCompact && styles.actionsGridCompact]}>
                {QUICK_ACTIONS.map((action) => (
                  <Pressable
                    key={action.label}
                    onPress={() => {
                      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                      router.push(action.route as any);
                    }}
                    style={({ pressed, hovered }) => [
                      styles.actionCard,
                      {
                        backgroundColor: colors.card,
                        borderColor: colors.border,
                      },
                      hovered && styles.actionCardHover,
                      pressed && { opacity: 0.84, transform: [{ scale: 0.985 }] },
                    ]}
                  >
                    <View style={[styles.actionIcon, { backgroundColor: action.bg }]}>
                      <Ionicons name={action.icon as any} size={23} color={action.color} />
                    </View>
                    <View style={styles.actionTextBlock}>
                      <Text style={[styles.actionLabel, { color: colors.foreground }]}>
                        {action.label}
                      </Text>
                      <Text style={[styles.actionMeta, { color: colors.mutedForeground }]}>
                        {action.subtitle}
                      </Text>
                    </View>
                    <Ionicons name="chevron-forward" size={15} color={colors.mutedForeground} />
                  </Pressable>
                ))}
              </View>
            </View>

            <View>
              <SectionHeader
                title="My courses"
                action="View all"
                onAction={() => router.push("/staff/all-courses")}
              />
              <View style={styles.courseStack}>
                {courses.slice(0, 3).map((course, index) => (
                  <Card key={course.id} style={styles.courseCard}>
                    <View style={styles.courseRow}>
                      <View
                        style={[
                          styles.courseIcon,
                          { backgroundColor: ["#DBEAFE", "#EEF2FF", "#D1FAE5"][index % 3] },
                        ]}
                      >
                        <Ionicons
                          name="book"
                          size={20}
                          color={["#2563EB", "#6366F1", "#10B981"][index % 3]}
                        />
                      </View>
                      <View style={styles.courseMain}>
                        <Text style={[styles.courseTitle, { color: colors.foreground }]}>
                          {course.name}
                        </Text>
                        <Text style={[styles.courseMeta, { color: colors.mutedForeground }]}>
                          {course.code} · {course.enrolledCount} students
                        </Text>
                      </View>
                      <Pressable
                        onPress={() =>
                          router.push({
                            pathname: "/staff/course-students",
                            params: { courseId: course.id, courseCode: course.code },
                          })
                        }
                        hitSlop={8}
                        style={({ pressed, hovered }) => [
                          styles.openButton,
                          { borderColor: colors.border },
                          hovered && { backgroundColor: colors.secondary },
                          pressed && { opacity: 0.7 },
                        ]}
                      >
                        <Text style={[styles.openButtonText, { color: colors.primary }]}>Open</Text>
                      </Pressable>
                    </View>
                  </Card>
                ))}
              </View>
            </View>
          </View>

          <View style={styles.sideColumn}>
            <Card style={styles.statusCard}>
              <Text style={[styles.panelKicker, { color: colors.mutedForeground }]}>Session control</Text>
              <Text style={[styles.panelTitle, { color: colors.foreground }]}>
                {openSessions.length > 0 ? "Attendance is running" : "No live session"}
              </Text>
              <Text style={[styles.panelText, { color: colors.mutedForeground }]}>
                {openSessions.length > 0
                  ? "Continue monitoring attendance capture or review the current roster."
                  : "Open a session when you are ready to start attendance capture."}
              </Text>
              <Pressable
                onPress={() => router.push(openSessions.length > 0 ? "/staff/open-session" : "/staff/create-session")}
                style={({ pressed }) => [
                  styles.statusAction,
                  { backgroundColor: colors.primary },
                  pressed && { opacity: 0.84 },
                ]}
              >
                <Text style={styles.statusActionText}>
                  {openSessions.length > 0 ? "Manage session" : "Create session"}
                </Text>
              </Pressable>
            </Card>

            <Card style={styles.summaryCard}>
              <View style={styles.summaryHeader}>
                <Text style={[styles.panelTitle, { color: colors.foreground }]}>Course load</Text>
                <Badge label={`${courses.length} total`} variant="primary" />
              </View>
              <View style={styles.summaryRows}>
                <View style={[styles.summaryRow, { borderBottomColor: colors.border }]}>
                  <Text style={[styles.summaryLabel, { color: colors.mutedForeground }]}>Students</Text>
                  <Text style={[styles.summaryValue, { color: colors.foreground }]}>{activeStudentCount}</Text>
                </View>
                <View style={[styles.summaryRow, { borderBottomColor: colors.border }]}>
                  <Text style={[styles.summaryLabel, { color: colors.mutedForeground }]}>Open sessions</Text>
                  <Text style={[styles.summaryValue, { color: colors.foreground }]}>{openSessions.length}</Text>
                </View>
                <View style={[styles.summaryRow, { borderBottomColor: colors.border }]}>
                  <Text style={[styles.summaryLabel, { color: colors.mutedForeground }]}>Reports</Text>
                  <Pressable onPress={() => router.push("/staff/reports")}>
                    <Text style={[styles.summaryLink, { color: colors.primary }]}>View</Text>
                  </Pressable>
                </View>
              </View>
            </Card>
          </View>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  actionCard: {
    alignItems: "center",
    borderRadius: 18,
    borderWidth: 1,
    flexDirection: "row",
    gap: 14,
    minWidth: 230,
    padding: 18,
  },
  actionCardHover: {
    boxShadow: "0 10px 22px rgba(13, 27, 62, 0.07)",
    transform: [{ translateY: -2 }],
  } as any,
  actionIcon: {
    alignItems: "center",
    borderRadius: 14,
    height: 50,
    justifyContent: "center",
    width: 50,
  },
  actionLabel: {
    fontFamily: "Inter_700Bold",
    fontSize: 15,
    fontWeight: "700",
  },
  actionMeta: {
    fontFamily: "Inter_400Regular",
    fontSize: 12,
    marginTop: 2,
  },
  actionTextBlock: {
    flex: 1,
  },
  actionsGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 14,
  },
  actionsGridCompact: {
    flexDirection: "column",
  },
  courseCard: {
    padding: 16,
  },
  courseIcon: {
    alignItems: "center",
    borderRadius: 14,
    height: 48,
    justifyContent: "center",
    width: 48,
  },
  courseMain: {
    flex: 1,
    minWidth: 0,
  },
  courseMeta: {
    fontFamily: "Inter_400Regular",
    fontSize: 12,
    marginTop: 3,
  },
  courseRow: {
    alignItems: "center",
    flexDirection: "row",
    gap: 14,
  },
  courseStack: {
    gap: 10,
  },
  courseTitle: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 14,
    fontWeight: "600",
  },
  eyebrow: {
    color: "rgba(255,255,255,0.62)",
    fontFamily: "Inter_600SemiBold",
    fontSize: 12,
    fontWeight: "600",
    letterSpacing: 1.2,
    textTransform: "uppercase",
  },
  grid: {
    alignItems: "flex-start",
    flexDirection: "row",
    gap: 24,
  },
  gridCompact: {
    flexDirection: "column",
  },
  hero: {
    borderRadius: 28,
    gap: 30,
    padding: 32,
  },
  heroCopy: {
    flex: 1,
    gap: 8,
  },
  heroDivider: {
    backgroundColor: "rgba(255,255,255,0.16)",
    height: 44,
    width: 1,
  },
  heroStat: {
    flex: 1,
    gap: 4,
  },
  heroStatLabel: {
    color: "rgba(255,255,255,0.58)",
    fontFamily: "Inter_400Regular",
    fontSize: 12,
  },
  heroStatValue: {
    color: "#FFFFFF",
    fontFamily: "Inter_700Bold",
    fontSize: 30,
    fontWeight: "700",
    letterSpacing: -0.7,
  },
  heroStats: {
    alignItems: "center",
    backgroundColor: "rgba(255,255,255,0.1)",
    borderColor: "rgba(255,255,255,0.12)",
    borderRadius: 20,
    borderWidth: 1,
    flexDirection: "row",
    padding: 20,
  },
  heroStatsCompact: {
    alignItems: "flex-start",
    gap: 16,
  },
  heroSubtitle: {
    color: "rgba(255,255,255,0.68)",
    fontFamily: "Inter_400Regular",
    fontSize: 15,
    lineHeight: 23,
    maxWidth: 620,
  },
  heroTitle: {
    color: "#FFFFFF",
    fontFamily: "Inter_700Bold",
    fontSize: 40,
    fontWeight: "700",
    letterSpacing: -1,
    lineHeight: 48,
  },
  heroTop: {
    alignItems: "flex-start",
    flexDirection: "row",
    gap: 20,
  },
  liveBanner: {
    alignItems: "center",
    backgroundColor: "#D1FAE5",
    borderColor: "#6EE7B7",
    borderRadius: 20,
    borderWidth: 1,
    flexDirection: "row",
    gap: 14,
    padding: 16,
  },
  liveCopy: {
    flex: 1,
  },
  liveDot: {
    backgroundColor: "#10B981",
    borderRadius: 4,
    height: 8,
    width: 8,
  },
  liveIcon: {
    alignItems: "center",
    backgroundColor: "#10B981",
    borderRadius: 14,
    height: 48,
    justifyContent: "center",
    width: 48,
  },
  liveMeta: {
    color: "#047857",
    fontFamily: "Inter_400Regular",
    fontSize: 13,
    marginTop: 2,
  },
  livePill: {
    alignItems: "center",
    backgroundColor: "rgba(255,255,255,0.55)",
    borderRadius: 999,
    flexDirection: "row",
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
  },
  livePillText: {
    color: "#065F46",
    fontFamily: "Inter_700Bold",
    fontSize: 12,
    fontWeight: "700",
  },
  liveTitle: {
    color: "#065F46",
    fontFamily: "Inter_700Bold",
    fontSize: 15,
    fontWeight: "700",
  },
  openButton: {
    borderRadius: 999,
    borderWidth: 1,
    paddingHorizontal: 13,
    paddingVertical: 8,
  },
  openButtonText: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 12,
    fontWeight: "600",
  },
  page: {
    flex: 1,
  },
  panelKicker: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 12,
    fontWeight: "600",
    letterSpacing: 0.8,
    textTransform: "uppercase",
  },
  panelText: {
    fontFamily: "Inter_400Regular",
    fontSize: 13,
    lineHeight: 20,
  },
  panelTitle: {
    fontFamily: "Inter_700Bold",
    fontSize: 18,
    fontWeight: "700",
    letterSpacing: -0.2,
  },
  primaryColumn: {
    flex: 1,
    gap: 28,
    minWidth: 0,
  },
  profileButton: {
    alignItems: "center",
    backgroundColor: "#FFFFFF",
    borderRadius: 999,
    flexDirection: "row",
    gap: 8,
    paddingHorizontal: 16,
    paddingVertical: 11,
  },
  profileButtonHover: {
    transform: [{ translateY: -1 }],
  },
  profileButtonText: {
    color: "#3730A3",
    fontFamily: "Inter_700Bold",
    fontSize: 13,
    fontWeight: "700",
  },
  scrollContent: {
    paddingBottom: 44,
  },
  shell: {
    alignSelf: "center",
    gap: 24,
    maxWidth: 1180,
    paddingHorizontal: 28,
    paddingTop: 28,
    width: "100%",
  },
  shellCompact: {
    paddingHorizontal: 16,
    paddingTop: 16,
  },
  sideColumn: {
    gap: 18,
    width: 320,
  },
  statusAction: {
    alignItems: "center",
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  statusActionText: {
    color: "#FFFFFF",
    fontFamily: "Inter_700Bold",
    fontSize: 13,
    fontWeight: "700",
  },
  statusCard: {
    gap: 14,
  },
  summaryCard: {
    gap: 16,
  },
  summaryHeader: {
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "space-between",
  },
  summaryLabel: {
    fontFamily: "Inter_400Regular",
    fontSize: 13,
  },
  summaryLink: {
    fontFamily: "Inter_700Bold",
    fontSize: 13,
    fontWeight: "700",
  },
  summaryRow: {
    alignItems: "center",
    borderBottomWidth: 1,
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 13,
  },
  summaryRows: {
    gap: 0,
  },
  summaryValue: {
    fontFamily: "Inter_700Bold",
    fontSize: 16,
    fontWeight: "700",
  },
});
