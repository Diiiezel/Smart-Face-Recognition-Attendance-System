import { Button, InputField, SelectionField } from "@/components/UI";
import { ScreenHeader } from "@/components/ScreenHeader";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { LEVEL_OPTIONS, MAJOR_OPTIONS } from "@/mocks/academicOptions";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import React, { useState } from "react";
import { KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const VALID_DEPARTMENTS = new Set<string>(MAJOR_OPTIONS.map((option) => option.value));

function initialDepartments(value?: string) {
  return (value || "")
    .split(",")
    .map((item) => item.trim())
    .filter((item) => VALID_DEPARTMENTS.has(item));
}

export default function CreateCourse() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { staffProfile, createCourse, isLoading } = useApp();

  const [courseName, setCourseName] = useState("");
  const [courseCode, setCourseCode] = useState("");
  const [selectedLevels, setSelectedLevels] = useState<string[]>([]);
  const [selectedDepartments, setSelectedDepartments] = useState<string[]>(initialDepartments(staffProfile?.department));
  const [done, setDone] = useState(false);
  const [error, setError] = useState("");
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  const handleCreate = async () => {
    if (!courseName || !courseCode || selectedDepartments.length === 0 || selectedLevels.length === 0) {
      setError("Please fill in all required fields.");
      return;
    }

    setError("");
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    try {
      await createCourse({
        name: courseName,
        code: courseCode.toUpperCase(),
        semester: selectedDepartments.join(", ") || undefined,
        level: selectedLevels.join(", "),
        departments: selectedDepartments,
        levels: selectedLevels,
      });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setDone(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to create course.");
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <ScreenHeader title="Create Course" showBack subtitle="Add a new course to the system" />
      <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: bottomPad + 20, gap: 16 }} keyboardShouldPersistTaps="handled">
          {done ? (
            <View style={[styles.successCard, { backgroundColor: colors.card }]}>
              <View style={{ width: 72, height: 72, borderRadius: 36, backgroundColor: "#D1FAE5", alignItems: "center", justifyContent: "center" }}>
                <Ionicons name="checkmark-circle" size={44} color="#10B981" />
              </View>
              <Text style={{ fontSize: 22, fontWeight: "700", color: colors.foreground, fontFamily: "Inter_700Bold" }}>
                Course Created!
              </Text>
              <Text style={{ fontSize: 14, color: colors.mutedForeground, textAlign: "center", fontFamily: "Inter_400Regular" }}>
                {courseCode.toUpperCase()} - {courseName} has been added successfully.
              </Text>
              <Button title="Back to Dashboard" onPress={() => router.back()} style={{ marginTop: 8 }} />
              <Button
                title="Create Another"
                onPress={() => {
                  setDone(false);
                  setCourseName("");
                  setCourseCode("");
                  setSelectedDepartments([]);
                  setSelectedLevels([]);
                }}
                variant="outline"
              />
            </View>
          ) : (
            <>
              <View style={[styles.formCard, { backgroundColor: colors.card }]}>
                <Text style={{ fontSize: 15, fontWeight: "700", color: colors.foreground, fontFamily: "Inter_700Bold", marginBottom: 4 }}>
                  Course Information
                </Text>
                <InputField
                  label="Course Name"
                  placeholder="e.g. Machine Learning"
                  value={courseName}
                  onChangeText={setCourseName}
                  icon={<Ionicons name="book-outline" size={18} color={colors.mutedForeground} />}
                />
                <InputField
                  label="Course Code"
                  placeholder="e.g. CS401"
                  value={courseCode}
                  onChangeText={setCourseCode}
                  autoCapitalize="characters"
                  icon={<Ionicons name="code-outline" size={18} color={colors.mutedForeground} />}
                />
                <SelectionField
                  label="Department"
                  placeholder="Select one or more departments"
                  selectedValues={selectedDepartments}
                  onSelect={(value) =>
                    setSelectedDepartments((current) =>
                      current.includes(value)
                        ? current.filter((item) => item !== value)
                        : [...current, value],
                    )
                  }
                  options={MAJOR_OPTIONS.map((option) => ({ ...option }))}
                  icon={<Ionicons name="business-outline" size={18} color={colors.mutedForeground} />}
                  multiSelect
                />
                <SelectionField
                  label="Level"
                  placeholder="Select one or more levels"
                  selectedValues={selectedLevels}
                  onSelect={(value) =>
                    setSelectedLevels((current) =>
                      current.includes(value)
                        ? current.filter((item) => item !== value)
                        : [...current, value],
                    )
                  }
                  options={LEVEL_OPTIONS.map((option) => ({ ...option }))}
                  icon={<Ionicons name="school-outline" size={18} color={colors.mutedForeground} />}
                  multiSelect
                />
              </View>

              <View style={[styles.formCard, { backgroundColor: colors.card }]}>
                <Text style={{ fontSize: 15, fontWeight: "700", color: colors.foreground, fontFamily: "Inter_700Bold", marginBottom: 4 }}>
                  Instructor
                </Text>
                <View style={{ flexDirection: "row", alignItems: "center", gap: 12, padding: 14, backgroundColor: colors.muted, borderRadius: 12 }}>
                  <View style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: "#EEF2FF", alignItems: "center", justifyContent: "center" }}>
                    <Ionicons name="person" size={22} color="#6366F1" />
                  </View>
                  <View>
                    <Text style={{ fontSize: 15, fontWeight: "600", color: colors.foreground, fontFamily: "Inter_600SemiBold" }}>
                      {staffProfile?.name}
                    </Text>
                    <Text style={{ fontSize: 12, color: colors.mutedForeground, fontFamily: "Inter_400Regular" }}>
                      {staffProfile?.title}
                    </Text>
                  </View>
                </View>
              </View>

              {error ? (
                <Text style={{ color: colors.destructive, fontFamily: "Inter_500Medium" }}>
                  {error}
                </Text>
              ) : null}

              <Button
                title="Create Course"
                onPress={handleCreate}
                loading={isLoading}
                disabled={
                  !courseName ||
                  !courseCode ||
                  selectedDepartments.length === 0 ||
                  selectedLevels.length === 0
                }
                size="lg"
              />
            </>
          )}
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  formCard: {
    borderRadius: 16,
    padding: 16,
    gap: 14,
    shadowColor: "#0F1B3C",
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.07,
    shadowRadius: 10,
    elevation: 3,
  },
  successCard: {
    borderRadius: 20,
    padding: 32,
    alignItems: "center",
    gap: 12,
    shadowColor: "#0F1B3C",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 16,
    elevation: 4,
  },
});
