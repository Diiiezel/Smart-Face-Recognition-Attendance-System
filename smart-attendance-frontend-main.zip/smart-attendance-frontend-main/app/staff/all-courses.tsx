import { Card } from "@/components/UI";
import { ScreenHeader } from "@/components/ScreenHeader";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useMemo, useState } from "react";
import { FlatList, Platform, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const COURSE_COLORS = ["#DBEAFE", "#EEF2FF", "#D1FAE5", "#FEF3C7"];
const COURSE_ICON_COLORS = ["#2563EB", "#6366F1", "#10B981", "#F59E0B"];

export default function AllCoursesScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { courses } = useApp();
  const [search, setSearch] = useState("");
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  const filteredCourses = useMemo(() => {
    const query = search.trim().toLowerCase();
    if (!query) return courses;

    return courses.filter(
      (course) =>
        course.name.toLowerCase().includes(query) ||
        course.code.toLowerCase().includes(query) ||
        course.department.toLowerCase().includes(query),
    );
  }, [courses, search]);

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <ScreenHeader title="Manage Courses" showBack subtitle={`${courses.length} total courses`} />

      <View style={styles.searchContainer}>
        <View style={[styles.searchBox, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Ionicons name="search-outline" size={18} color={colors.mutedForeground} />
          <TextInput
            style={{
              flex: 1,
              fontSize: 15,
              color: colors.foreground,
              fontFamily: "Inter_400Regular",
            }}
            placeholder="Search courses"
            placeholderTextColor={colors.mutedForeground}
            value={search}
            onChangeText={setSearch}
          />
        </View>
      </View>

      <FlatList
        data={filteredCourses}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ padding: 16, paddingBottom: bottomPad + 20, gap: 12 }}
        renderItem={({ item, index }) => (
          <Pressable
            onPress={() =>
              router.push({
                pathname: "/staff/course-students",
                params: { courseId: item.id, courseCode: item.code },
              })
            }
          >
            <Card style={{ padding: 14 }}>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
                <View
                  style={{
                    width: 44,
                    height: 44,
                    borderRadius: 12,
                    backgroundColor: COURSE_COLORS[index % COURSE_COLORS.length],
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <Ionicons name="book" size={20} color={COURSE_ICON_COLORS[index % COURSE_ICON_COLORS.length]} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text
                    style={{
                      fontSize: 15,
                      fontWeight: "600",
                      color: colors.foreground,
                      fontFamily: "Inter_600SemiBold",
                    }}
                  >
                    {item.name}
                  </Text>
                  <Text
                    style={{
                      fontSize: 12,
                      color: colors.mutedForeground,
                      fontFamily: "Inter_400Regular",
                      marginTop: 2,
                    }}
                  >
                    {item.code} · {item.enrolledCount} students
                  </Text>
                </View>
                <Ionicons name="chevron-forward" size={16} color={colors.mutedForeground} />
              </View>
            </Card>
          </Pressable>
        )}
        ListEmptyComponent={
          <View style={{ alignItems: "center", paddingTop: 60, gap: 12 }}>
            <Ionicons name="book-outline" size={48} color={colors.mutedForeground} />
            <Text style={{ fontSize: 16, color: colors.mutedForeground, fontFamily: "Inter_500Medium" }}>
              No courses found
            </Text>
          </View>
        }
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  searchContainer: {
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  searchBox: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    borderRadius: 14,
    borderWidth: 1.5,
  },
});
