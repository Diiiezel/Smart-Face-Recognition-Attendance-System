import { Button, Card } from "@/components/UI";
import { ScreenHeader } from "@/components/ScreenHeader";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { buildFutureSessionDateTimes } from "@/utils/dateTime";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import React, { useState } from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

const SESSION_DATE_TIME_ERROR = "Please enter a valid session date and time.";
const SESSION_FUTURE_DATE_TIME_ERROR = "Please choose a valid future session date and time.";

function WebDateTimeInput({
  label,
  type,
  value,
  onChange,
  icon,
}: {
  label: string;
  type: "date" | "time";
  value: string;
  onChange: (value: string) => void;
  icon: React.ReactNode;
}) {
  const colors = useColors();

  return (
    <View style={styles.webFieldStack}>
      <Text style={[styles.webFieldLabel, { color: colors.foreground }]}>{label}</Text>
      <View style={[styles.webInputShell, { backgroundColor: colors.card, borderColor: colors.border }]}>
        {icon}
        {React.createElement("input", {
          type,
          value,
          onChange: (event: React.ChangeEvent<HTMLInputElement>) => onChange(event.target.value),
          style: {
            border: "none",
            outline: "none",
            flex: 1,
            minWidth: 0,
            background: "transparent",
            color: colors.foreground,
            fontFamily: "Inter_400Regular",
            fontSize: 15,
          },
        })}
      </View>
    </View>
  );
}

export default function CreateSession() {
  const colors = useColors();
  const { courses, createSession, isLoading } = useApp();
  const [selectedCourse, setSelectedCourse] = useState<string | null>(null);
  const [date, setDate] = useState("2026-03-31");
  const [startTime, setStartTime] = useState("10:00");
  const [endTime, setEndTime] = useState("11:30");
  const [type, setType] = useState<"face" | "qr" | "both">("face");
  const [done, setDone] = useState(false);
  const [error, setError] = useState("");
  const selectedCourseData = courses.find((course) => course.id === selectedCourse);
  const typeOptions = [
    { key: "face" as const, label: "Face Recognition", icon: "scan", color: "#2563EB", bg: "#DBEAFE" },
    { key: "qr" as const, label: "QR Code", icon: "qr-code", color: "#6366F1", bg: "#EEF2FF" },
    { key: "both" as const, label: "Both", icon: "apps", color: "#10B981", bg: "#D1FAE5" },
  ];

  const handleCreate = async () => {
    if (!selectedCourse || !type) {
      setError(SESSION_DATE_TIME_ERROR);
      return;
    }

    const dateTimes = buildFutureSessionDateTimes(date, startTime, endTime);

    if (!dateTimes) {
      setError(SESSION_FUTURE_DATE_TIME_ERROR);
      return;
    }

    try {
      setError("");
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      await createSession({
        courseId: selectedCourse,
        method: type,
        startsAt: dateTimes.startsAt,
        endsAt: dateTimes.endsAt,
      });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setDone(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to create session.");
    }
  };

  return (
    <View style={[styles.page, { backgroundColor: colors.background }]}>
      <ScreenHeader title="Create Session" showBack subtitle="Schedule an attendance session" />
      <ScrollView contentContainerStyle={styles.shell} showsVerticalScrollIndicator={false}>
        {done ? (
          <Card style={styles.successCard}>
            <View style={styles.successIcon}>
              <Ionicons name="checkmark-circle" size={46} color={colors.success} />
            </View>
            <Text style={[styles.successTitle, { color: colors.foreground }]}>Session Created</Text>
            <Text style={[styles.successCopy, { color: colors.mutedForeground }]}>
              {selectedCourseData?.code} session for {date} has been scheduled.
            </Text>
            <View style={styles.actionRow}>
              <Button title="Open Session Now" onPress={() => router.push("/staff/open-session")} fullWidth={false} />
              <Button title="Back to Dashboard" onPress={() => router.replace("/staff/dashboard")} variant="outline" fullWidth={false} />
            </View>
          </Card>
        ) : (
          <View style={styles.layout}>
            <Card style={styles.coursePanel}>
              <Text style={[styles.cardTitle, { color: colors.foreground }]}>Select Course</Text>
              <View style={styles.courseList}>
                {courses.map((course) => {
                  const active = selectedCourse === course.id;
                  return (
                    <Pressable
                      key={course.id}
                      onPress={() => setSelectedCourse(course.id)}
                      style={[
                        styles.courseOption,
                        { backgroundColor: active ? colors.secondary : colors.background, borderColor: active ? colors.primary : colors.border },
                      ]}
                    >
                      <View style={styles.courseMain}>
                        <Text style={[styles.courseTitle, { color: colors.foreground }]}>{course.code} - {course.name}</Text>
                        <Text style={[styles.courseMeta, { color: colors.mutedForeground }]}>{course.enrolledCount} students enrolled</Text>
                      </View>
                      <Ionicons name={active ? "checkmark-circle" : "ellipse-outline"} size={22} color={active ? colors.primary : colors.mutedForeground} />
                    </Pressable>
                  );
                })}
              </View>
            </Card>
            <View style={styles.formColumn}>
              <Card style={styles.formCard}>
                <Text style={[styles.cardTitle, { color: colors.foreground }]}>Date & Time</Text>
                <WebDateTimeInput label="Date" type="date" value={date} onChange={setDate} icon={<Ionicons name="calendar-outline" size={16} color={colors.mutedForeground} />} />
                <WebDateTimeInput label="Start Time" type="time" value={startTime} onChange={setStartTime} icon={<Ionicons name="time-outline" size={16} color={colors.mutedForeground} />} />
                <WebDateTimeInput label="End Time" type="time" value={endTime} onChange={setEndTime} icon={<Ionicons name="time-outline" size={16} color={colors.mutedForeground} />} />
              </Card>
              <Card style={styles.formCard}>
                <Text style={[styles.cardTitle, { color: colors.foreground }]}>Attendance Type</Text>
                <View style={styles.typeGrid}>
                  {typeOptions.map((option) => {
                    const active = type === option.key;
                    return (
                      <Pressable
                        key={option.key}
                        onPress={() => setType(option.key)}
                        style={[
                          styles.typeBtn,
                          { backgroundColor: active ? option.bg : colors.background, borderColor: active ? option.color : colors.border },
                        ]}
                      >
                        <Ionicons name={option.icon as any} size={22} color={active ? option.color : colors.mutedForeground} />
                        <Text style={[styles.typeLabel, { color: active ? option.color : colors.foreground }]}>{option.label}</Text>
                      </Pressable>
                    );
                  })}
                </View>
              </Card>
              {error ? <Text style={[styles.errorText, { color: colors.destructive }]}>{error}</Text> : null}
              <Button title="Create Session" onPress={handleCreate} loading={isLoading} disabled={!selectedCourse} size="lg" />
            </View>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  actionRow: {
    flexDirection: "row",
    gap: 12,
  },
  cardTitle: {
    fontFamily: "Inter_700Bold",
    fontSize: 18,
  },
  courseList: {
    gap: 10,
  },
  courseMain: {
    flex: 1,
    gap: 4,
  },
  courseMeta: {
    fontFamily: "Inter_400Regular",
    fontSize: 12,
  },
  courseOption: {
    alignItems: "center",
    borderRadius: 14,
    borderWidth: 1,
    flexDirection: "row",
    gap: 12,
    padding: 14,
  },
  coursePanel: {
    flex: 1,
    gap: 18,
    minWidth: 430,
  },
  courseTitle: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 14,
  },
  errorText: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 13,
  },
  formCard: {
    gap: 16,
  },
  formColumn: {
    flex: 1,
    gap: 16,
    minWidth: 430,
  },
  layout: {
    flexDirection: "row",
    gap: 18,
  },
  page: {
    flex: 1,
  },
  shell: {
    alignSelf: "center",
    maxWidth: 1180,
    padding: 28,
    width: "100%",
  },
  successCard: {
    alignItems: "center",
    gap: 14,
    paddingVertical: 54,
  },
  successCopy: {
    fontFamily: "Inter_400Regular",
    fontSize: 15,
  },
  successIcon: {
    alignItems: "center",
    backgroundColor: "#DCFCE7",
    borderRadius: 40,
    height: 80,
    justifyContent: "center",
    width: 80,
  },
  successTitle: {
    fontFamily: "Inter_700Bold",
    fontSize: 28,
    letterSpacing: -0.4,
  },
  typeBtn: {
    alignItems: "center",
    borderRadius: 14,
    borderWidth: 1,
    flex: 1,
    gap: 8,
    justifyContent: "center",
    minHeight: 92,
    minWidth: 130,
    padding: 14,
  },
  typeGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
  },
  typeLabel: {
    fontFamily: "Inter_700Bold",
    fontSize: 12,
    textAlign: "center",
  },
  webFieldLabel: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 13,
  },
  webFieldStack: {
    gap: 7,
  },
  webInputShell: {
    alignItems: "center",
    borderRadius: 14,
    borderWidth: 1,
    flexDirection: "row",
    gap: 10,
    minHeight: 52,
    paddingHorizontal: 14,
  },
});
