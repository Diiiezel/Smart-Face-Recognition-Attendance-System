import { Badge, Button, Card } from "@/components/UI";
import { ScreenHeader } from "@/components/ScreenHeader";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import {
  getManagedStudentsForCourse,
} from "@/services/studentsService";
import { buildCsv, exportCsv } from "@/utils/csvExport";
import { Ionicons } from "@expo/vector-icons";
import { useLocalSearchParams } from "expo-router";
import React, { useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import type { ManagedStudent } from "@/mocks/students";

export default function CourseStudentsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { courses } = useApp();
  const params = useLocalSearchParams<{ courseId?: string; courseCode?: string }>();
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;
  const courseId = typeof params.courseId === "string" ? params.courseId : "";
  const courseCode = typeof params.courseCode === "string" ? params.courseCode : "";

  const [isLoading, setIsLoading] = useState(true);
  const [students, setStudents] = useState<ManagedStudent[]>([]);
  const [errorMessage, setErrorMessage] = useState("");

  const course = useMemo(
    () =>
      courses.find((item) => item.id === courseId || item.courseIds?.includes(courseId)) ||
      courses.find((item) => item.code === courseCode) ||
      null,
    [courseCode, courseId, courses],
  );

  useEffect(() => {
    let mounted = true;

    void (async () => {
      try {
        setErrorMessage("");
        const enrolledStudents = await getManagedStudentsForCourse(courseId, courseCode);
        if (!mounted) return;
        setStudents(enrolledStudents);
      } catch (error) {
        if (!mounted) return;
        setStudents([]);
        setErrorMessage(error instanceof Error ? error.message : "Unable to load course roster.");
      } finally {
        if (mounted) {
          setIsLoading(false);
        }
      }
    })();

    return () => {
      mounted = false;
    };
  }, [courseCode, courseId]);

  const handleExportStudents = async () => {
    const csv = [
      buildCsv(["Course Name", course?.name || "Course"], []),
      buildCsv(["Course Code", course?.code || courseCode || "Course"], []),
      buildCsv(["Total sessions", String(Number(course?.sessionsCount ?? 0))], []),
      "",
      buildCsv(
        ["University Code", "Full Name"],
        students.map((student) => [
          student.universityId,
          student.fullName,
        ]),
      ),
    ].join("\n");

    await exportCsv(`${course?.code || courseCode || "course"}-students.csv`, csv);
  };

  if (isLoading) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.background }}>
        <ScreenHeader
          title={course?.name || "Course Students"}
          subtitle={course?.code || courseCode || "Course"}
          showBack
        />
        <View style={styles.loadingState}>
          <ActivityIndicator size="large" color={colors.primary} />
          <Text style={[styles.loadingText, { color: colors.mutedForeground }]}>
            Loading students...
          </Text>
        </View>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <ScreenHeader
        title={course?.name || "Course Students"}
        subtitle={course?.code || courseCode || "Course"}
        showBack
      />
      <ScrollView
        contentContainerStyle={{ padding: 20, paddingBottom: bottomPad + 20, gap: 16 }}
        showsVerticalScrollIndicator={false}
      >
        <Card style={{ gap: 14 }}>
          <View style={styles.summaryRow}>
            <View style={styles.summaryBlock}>
              <Text style={[styles.summaryLabel, { color: colors.mutedForeground }]}>
                Enrolled Students
              </Text>
              <Text style={[styles.summaryValue, { color: colors.foreground }]}>
                {students.length}
              </Text>
            </View>
            <View style={styles.summaryBlock}>
              <Text style={[styles.summaryLabel, { color: colors.mutedForeground }]}>Level</Text>
              <Text style={[styles.summaryValue, { color: colors.foreground }]}>
                {course?.level || "N/A"}
              </Text>
            </View>
            <View style={styles.summaryBlock}>
              <Text style={[styles.summaryLabel, { color: colors.mutedForeground }]}>Major</Text>
              <Text style={[styles.summaryValue, { color: colors.foreground }]}>
                {course?.department || "N/A"}
              </Text>
            </View>
          </View>
          <Button
            title="Export CSV"
            onPress={handleExportStudents}
            variant="outline"
            disabled={students.length === 0}
          />
        </Card>

        {errorMessage ? (
          <Card style={styles.errorCard}>
            <Text style={[styles.errorText, { color: colors.destructive }]}>{errorMessage}</Text>
          </Card>
        ) : null}

        <View style={{ gap: 12 }}>
          {students.length === 0 ? (
            <Card style={styles.emptyStateCard}>
              <Ionicons name="people-outline" size={32} color={colors.mutedForeground} />
              <Text style={[styles.emptyStateTitle, { color: colors.foreground }]}>
                No students enrolled in this course
              </Text>
            </Card>
          ) : (
            students.map((student) => (
              <Card key={student.id} style={{ gap: 14 }}>
                <View style={styles.studentHeader}>
                  <View style={{ flex: 1, gap: 4 }}>
                    <Text style={[styles.studentName, { color: colors.foreground }]}>
                      {student.fullName}
                    </Text>
                    <Text style={[styles.studentMeta, { color: colors.mutedForeground }]}>
                      {student.universityId}
                    </Text>
                    <Text style={[styles.studentMeta, { color: colors.mutedForeground }]}>
                      {student.email || "No email"}
                    </Text>
                  </View>
                  <Badge
                    label={student.faceEnrolled ? "Face Enrolled" : "Not Enrolled"}
                    variant={student.faceEnrolled ? "success" : "danger"}
                  />
                </View>

                <View style={styles.infoGrid}>
                  <View style={styles.infoBlock}>
                    <Text style={[styles.infoLabel, { color: colors.mutedForeground }]}>Major</Text>
                    <Text style={[styles.infoValue, { color: colors.foreground }]}>
                      {student.major}
                    </Text>
                  </View>
                  <View style={styles.infoBlock}>
                    <Text style={[styles.infoLabel, { color: colors.mutedForeground }]}>Level</Text>
                    <Text style={[styles.infoValue, { color: colors.foreground }]}>
                      {student.level}
                    </Text>
                  </View>
                  <View style={styles.infoBlock}>
                    <Text style={[styles.infoLabel, { color: colors.mutedForeground }]}>
                      Attendance
                    </Text>
                    <Text style={[styles.infoValue, { color: colors.foreground }]}>
                      {student.attendanceRate}%
                    </Text>
                  </View>
                </View>
              </Card>
            ))
          )}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  loadingState: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 12,
  },
  loadingText: {
    fontSize: 14,
    fontFamily: "Inter_500Medium",
  },
  summaryRow: {
    flexDirection: "row",
    gap: 12,
  },
  summaryBlock: {
    flex: 1,
    gap: 6,
  },
  summaryLabel: {
    fontSize: 11,
    textTransform: "uppercase",
    letterSpacing: 0.5,
    fontFamily: "Inter_500Medium",
  },
  summaryValue: {
    fontSize: 16,
    fontFamily: "Inter_700Bold",
  },
  emptyStateCard: {
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 36,
    gap: 10,
  },
  emptyStateTitle: {
    fontSize: 16,
    fontFamily: "Inter_600SemiBold",
    textAlign: "center",
  },
  errorCard: {
    borderColor: "rgba(220, 38, 38, 0.28)",
    borderWidth: 1,
    paddingVertical: 14,
  },
  errorText: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 14,
  },
  studentHeader: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 12,
  },
  studentName: {
    fontSize: 16,
    fontFamily: "Inter_700Bold",
  },
  studentMeta: {
    fontSize: 12,
    fontFamily: "Inter_400Regular",
  },
  infoGrid: {
    flexDirection: "row",
    gap: 12,
  },
  infoBlock: {
    flex: 1,
    gap: 4,
  },
  infoLabel: {
    fontSize: 11,
    textTransform: "uppercase",
    letterSpacing: 0.5,
    fontFamily: "Inter_500Medium",
  },
  infoValue: {
    fontSize: 14,
    fontFamily: "Inter_600SemiBold",
  },
});
