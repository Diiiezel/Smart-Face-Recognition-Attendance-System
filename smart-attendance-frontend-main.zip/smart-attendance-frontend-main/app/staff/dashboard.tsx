import { Badge, Card, SectionHeader, StatCard } from "@/components/UI";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import React from "react";
import { Platform, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const QUICK_ACTIONS = [
  { label: "Create Course", icon: "add-circle", route: "/staff/create-course", color: "#2563EB", bg: "#DBEAFE" },
  { label: "Create Session", icon: "calendar-number", route: "/staff/create-session", color: "#6366F1", bg: "#EEF2FF" },
  { label: "Open Sessions", subtitle: "Start or manage attendance", icon: "play-circle", route: "/staff/open-session", color: "#0EA5E9", bg: "#E0F2FE" },
  { label: "Manage Courses", icon: "albums", route: "/staff/all-courses", color: "#10B981", bg: "#D1FAE5" },
  { label: "Reports", icon: "bar-chart", route: "/staff/reports", color: "#F59E0B", bg: "#FEF3C7" },
];

function formatDoctorName(name?: string | null) {
  const cleanName = (name || "Staff").replace(/\.cs$/i, "").trim();
  return cleanName.toUpperCase().startsWith("DR.") ? cleanName : `DR. ${cleanName}`;
}

export default function StaffDashboard() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { staffProfile, courses, sessions } = useApp();

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  const openSessions = sessions.filter((s) => s.isOpen);
  const doctorName = formatDoctorName(staffProfile?.name);

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.background }}
      showsVerticalScrollIndicator={false}
      contentContainerStyle={{ paddingBottom: bottomPad + 20 }}
    >
      <LinearGradient
        colors={["#3730A3", "#4F46E5", "#6366F1"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[styles.header, { paddingTop: topPad + 16 }]}
      >
        <View style={styles.headerTop}>
          <View style={{ flex: 1 }}>
            <Text style={styles.greeting}>Welcome back,</Text>
            <Text style={styles.name} numberOfLines={1}>{doctorName}</Text>
          </View>
          <Pressable style={styles.avatarCircle} onPress={() => router.push("/staff/profile")}>
            <Ionicons name="briefcase" size={26} color="#6366F1" />
          </Pressable>
        </View>
      </LinearGradient>

      <View style={styles.content}>
        {openSessions.length > 0 && (
          <Pressable onPress={() => router.push("/staff/open-session")}>
            <Card style={{ backgroundColor: "#D1FAE5", borderWidth: 1.5, borderColor: "#6EE7B7" }} elevated={false}>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
                <View style={{ width: 44, height: 44, borderRadius: 12, backgroundColor: "#10B981", alignItems: "center", justifyContent: "center" }}>
                  <Ionicons name="radio" size={22} color="#FFFFFF" />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontSize: 14, fontWeight: "700", color: "#065F46", fontFamily: "Inter_700Bold" }}>
                    {openSessions[0].courseName} session is live
                  </Text>
                  <Text style={{ fontSize: 12, color: "#047857", fontFamily: "Inter_400Regular" }}>
                    {openSessions[0].presentCount}/{openSessions[0].totalCount} students present
                  </Text>
                </View>
                <View style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
                  <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: "#10B981" }} />
                  <Text style={{ fontSize: 12, color: "#065F46", fontFamily: "Inter_600SemiBold" }}>Live</Text>
                </View>
              </View>
            </Card>
          </Pressable>
        )}

        <View>
          <SectionHeader title="Quick Actions" />
          <View style={styles.actionsGrid}>
            {QUICK_ACTIONS.map((action) => (
              <Pressable
                key={action.label}
                onPress={() => {
                  Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                  router.push(action.route as any);
                }}
                style={({ pressed }) => [styles.actionCard, { backgroundColor: colors.card, opacity: pressed ? 0.85 : 1, transform: [{ scale: pressed ? 0.95 : 1 }] }]}
              >
                <View style={[styles.actionIcon, { backgroundColor: action.bg }]}>
                  <Ionicons name={action.icon as any} size={24} color={action.color} />
                </View>
                <Text style={{ fontSize: 12, fontWeight: "600", color: colors.foreground, fontFamily: "Inter_600SemiBold", textAlign: "center" }}>
                  {action.label}
                </Text>
                {"subtitle" in action ? (
                  <Text style={{ fontSize: 10, color: colors.mutedForeground, fontFamily: "Inter_400Regular", textAlign: "center" }}>
                    {action.subtitle}
                  </Text>
                ) : null}
              </Pressable>
            ))}
          </View>
        </View>

        <View>
          <SectionHeader title="My Courses" action="View All" onAction={() => router.push("/staff/all-courses")} />
          <View style={{ gap: 10 }}>
            {courses.slice(0, 3).map((course, index) => (
              <Card key={course.id} style={{ padding: 14 }}>
                <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
                  <View style={{ width: 44, height: 44, borderRadius: 12, backgroundColor: ["#DBEAFE", "#EEF2FF", "#D1FAE5"][index % 3], alignItems: "center", justifyContent: "center" }}>
                    <Ionicons name="book" size={20} color={["#2563EB", "#6366F1", "#10B981"][index % 3]} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={{ fontSize: 14, fontWeight: "600", color: colors.foreground, fontFamily: "Inter_600SemiBold" }}>
                      {course.name}
                    </Text>
                    <Text style={{ fontSize: 12, color: colors.mutedForeground, fontFamily: "Inter_400Regular" }}>
                      {course.code} · {course.enrolledCount} students
                    </Text>
                  </View>
                  <Pressable
                    onPress={() =>
                      router.push({
                        pathname: "/staff/course-students",
                        params: { courseId: course.id, courseCode: course.code },
                      })
                    }
                    hitSlop={8}
                    style={({ pressed }) => ({ opacity: pressed ? 0.7 : 1 })}
                  >
                    <Ionicons name="chevron-forward" size={16} color={colors.mutedForeground} />
                  </Pressable>
                </View>
              </Card>
            ))}
          </View>
        </View>

      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: 20,
    paddingBottom: 28,
    borderBottomLeftRadius: 28,
    borderBottomRightRadius: 28,
    gap: 20,
  },
  headerTop: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 12,
  },
  greeting: {
    fontSize: 14,
    color: "rgba(255,255,255,0.7)",
    fontFamily: "Inter_400Regular",
  },
  name: {
    fontSize: 22,
    fontWeight: "700",
    color: "#FFFFFF",
    fontFamily: "Inter_700Bold",
  },
  avatarCircle: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: "#FFFFFF",
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 6,
  },
  content: {
    padding: 20,
    gap: 24,
  },
  actionsGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 12,
  },
  actionCard: {
    width: "47%",
    borderRadius: 16,
    padding: 16,
    alignItems: "center",
    gap: 10,
    shadowColor: "#0F1B3C",
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.07,
    shadowRadius: 10,
    elevation: 3,
  },
  actionIcon: {
    width: 52,
    height: 52,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
  },
});
