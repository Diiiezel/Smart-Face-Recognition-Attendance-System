import { Card } from "@/components/UI";
import { AccountSettingsCard } from "@/components/AccountSettingsCard";
import { ScreenHeader } from "@/components/ScreenHeader";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useState } from "react";
import { ActivityIndicator, Alert, Platform, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

interface InfoRowProps {
  label: string;
  value: string;
  icon: string;
}

function InfoRow({ label, value, icon }: InfoRowProps) {
  const colors = useColors();

  return (
    <View
      style={{
        flexDirection: "row",
        alignItems: "center",
        gap: 14,
        paddingVertical: 14,
        borderBottomWidth: 1,
        borderBottomColor: colors.border,
      }}
    >
      <View
        style={{
          width: 36,
          height: 36,
          borderRadius: 10,
          backgroundColor: colors.muted,
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Ionicons name={icon as any} size={18} color={colors.primary} />
      </View>
      <View style={{ flex: 1 }}>
        <Text
          style={{
            fontSize: 11,
            color: colors.mutedForeground,
            fontFamily: "Inter_500Medium",
            textTransform: "uppercase",
            letterSpacing: 0.5,
          }}
        >
          {label}
        </Text>
        <Text
          style={{
            fontSize: 15,
            color: colors.foreground,
            fontFamily: "Inter_500Medium",
            marginTop: 2,
          }}
        >
          {value}
        </Text>
      </View>
    </View>
  );
}

function formatDoctorName(name?: string | null) {
  const cleanName = (name || "Doctor").replace(/\.cs$/i, "").trim();
  return cleanName.toUpperCase().startsWith("DR.") ? cleanName : `DR. ${cleanName}`;
}

export default function StaffProfile() {
  const colors = useColors();
  const { staffProfile, logout } = useApp();
  const insets = useSafeAreaInsets();
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;
  const [isSigningOut, setIsSigningOut] = useState(false);
  const doctorName = formatDoctorName(staffProfile?.name);

  const performSignOut = async () => {
    setIsSigningOut(true);

    try {
      await logout();
      router.replace("/role-select");
    } catch {
      setIsSigningOut(false);
      Alert.alert("Sign Out", "Unable to sign out. Please try again.");
    }
  };

  const handleSignOut = () => {
    if (isSigningOut) {
      return;
    }

    if (Platform.OS === "web") {
      const confirmed =
        typeof globalThis.confirm === "function"
          ? globalThis.confirm("Are you sure you want to sign out?")
          : true;

      if (confirmed) {
        void performSignOut();
      }
      return;
    }

    Alert.alert("Sign Out", "Are you sure you want to sign out?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Sign Out",
        style: "destructive",
        onPress: () => void performSignOut(),
      },
    ]);
  };

  if (!staffProfile) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.background }}>
        <ScreenHeader title="My Profile" showBack subtitle="Staff" />
        <View style={styles.emptyState}>
          {isSigningOut ? (
            <>
              <ActivityIndicator size="small" color={colors.primary} />
              <Text style={{ color: colors.mutedForeground, fontFamily: "Inter_500Medium" }}>
                Signing out...
              </Text>
            </>
          ) : (
            <Text style={{ color: colors.mutedForeground, fontFamily: "Inter_500Medium" }}>
              Profile unavailable.
            </Text>
          )}
        </View>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <ScreenHeader title="My Profile" showBack subtitle="Doctor Settings" />
      <ScrollView
        contentContainerStyle={{ padding: 20, paddingBottom: bottomPad + 20, gap: 20 }}
        showsVerticalScrollIndicator={false}
      >
        <Card style={{ alignItems: "center", gap: 12, paddingVertical: 28 }}>
          <View style={styles.avatarLarge}>
            <Ionicons name="briefcase" size={48} color="#6366F1" />
          </View>
          <View style={{ alignItems: "center" }}>
            <Text
              style={{
                fontSize: 20,
                fontWeight: "700",
                color: colors.foreground,
                fontFamily: "Inter_700Bold",
              }}
            >
              {doctorName}
            </Text>
            <Text
              style={{
                fontSize: 14,
                color: colors.mutedForeground,
                fontFamily: "Inter_400Regular",
              }}
            >
              {staffProfile.email}
            </Text>
          </View>
          <View style={{ flexDirection: "row", gap: 8 }}>
            <View
              style={{
                backgroundColor: "#EEF2FF",
                borderRadius: 20,
                paddingHorizontal: 12,
                paddingVertical: 4,
              }}
            >
              <Text style={{ fontSize: 12, color: "#4F46E5", fontFamily: "Inter_600SemiBold" }}>
                Staff
              </Text>
            </View>
          </View>
        </Card>

        <Card>
          <InfoRow label="Full Name" value={doctorName} icon="person-outline" />
          <InfoRow label="Email" value={staffProfile.email} icon="mail-outline" />
        </Card>

        <AccountSettingsCard mode="staff" />

        <Pressable onPress={handleSignOut} disabled={isSigningOut}>
          <View style={[styles.signOutRow, isSigningOut && styles.signOutRowDisabled]}>
            <Ionicons name="log-out-outline" size={17} color={colors.mutedForeground} />
            {isSigningOut ? (
              <ActivityIndicator size="small" color={colors.mutedForeground} />
            ) : (
              <Text style={{ color: colors.mutedForeground, fontSize: 14, fontFamily: "Inter_500Medium" }}>
                Sign Out
              </Text>
            )}
          </View>
        </Pressable>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  avatarLarge: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: "#EEF2FF",
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 4,
    borderColor: "#C7D2FE",
  },
  signOutRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    paddingVertical: 14,
    backgroundColor: "#FFFFFF",
    borderRadius: 14,
    borderWidth: 1,
    borderColor: "#E8ECF4",
  },
  signOutRowDisabled: {
    opacity: 0.7,
  },
  emptyState: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 12,
    paddingHorizontal: 24,
  },
});
