import { Button, Card, InputField } from "@/components/UI";
import { ScreenHeader } from "@/components/ScreenHeader";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { buildFutureSessionDateTimes } from "@/utils/dateTime";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import React, { useState } from "react";
import { Alert, Platform, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

function sanitizeDateInput(value: string) {
  return value.replace(/[^\d-]/g, "").slice(0, 10);
}

function sanitizeTimeInput(value: string) {
  return value.replace(/[^\d:]/g, "").slice(0, 5);
}

function sessionAudienceLabel(session: { levelLabels?: string[]; levels?: string[] }) {
  const labels = session.levelLabels?.length
    ? session.levelLabels
    : session.levels?.map((level) => `Year ${level}`);

  return labels?.length ? labels.join(", ") : "";
}

export default function OpenSession() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { sessions, openSession, closeSession, updateSession, deleteSession, isLoading } = useApp();
  const [selectedSession, setSelectedSession] = useState<string | null>(null);
  const [editingSessionId, setEditingSessionId] = useState<string | null>(null);
  const [editDate, setEditDate] = useState("");
  const [editStartTime, setEditStartTime] = useState("");
  const [editEndTime, setEditEndTime] = useState("");
  const [editType, setEditType] = useState<"face" | "qr" | "both">("face");
  const [error, setError] = useState("");
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  const session = sessions.find((s) => s.id === selectedSession);

  const TYPE_OPTIONS = [
    { key: "face" as const, label: "Face", icon: "scan" },
    { key: "qr" as const, label: "QR", icon: "qr-code" },
    { key: "both" as const, label: "Both", icon: "apps" },
  ];

  const beginEditScheduledSession = (scheduledSession: typeof sessions[number]) => {
    setError("");
    setSelectedSession(scheduledSession.id);
    setEditingSessionId(scheduledSession.id);
    setEditDate(scheduledSession.date === "Not scheduled" ? "" : scheduledSession.date);
    setEditStartTime(scheduledSession.startTime === "--" ? "" : scheduledSession.startTime);
    setEditEndTime(scheduledSession.endTime === "--" ? "" : scheduledSession.endTime);
    setEditType(scheduledSession.type);
  };

  const handleSaveScheduledSession = async (scheduledSession: typeof sessions[number]) => {
    const dateTimes = buildFutureSessionDateTimes(editDate, editStartTime, editEndTime);

    if (!dateTimes) {
      setError("Please choose a valid future session date and time.");
      return;
    }

    try {
      setError("");
      await updateSession(scheduledSession.id, {
        method: editType,
        startsAt: dateTimes.startsAt,
        endsAt: dateTimes.endsAt,
      });
      setEditingSessionId(null);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to update session.");
    }
  };

  const performDeleteScheduledSession = async (sessionId: string) => {
    setError("");

    try {
      await deleteSession(sessionId);
      if (selectedSession === sessionId) {
        setSelectedSession(null);
      }
      if (editingSessionId === sessionId) {
        setEditingSessionId(null);
      }
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to delete session.");
    }
  };

  const handleDeleteScheduledSession = (sessionId: string) => {
    if (Platform.OS === "web") {
      const confirmed =
        typeof globalThis.confirm === "function"
          ? globalThis.confirm("Delete this scheduled session?")
          : true;

      if (confirmed) {
        void performDeleteScheduledSession(sessionId);
      }
      return;
    }

    Alert.alert(
      "Delete Session",
      "Delete this scheduled session?",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete",
          style: "destructive",
          onPress: () => void performDeleteScheduledSession(sessionId),
        },
      ],
    );
  };

  const handleOpen = async (sessionId: string, routeMode: "face" | "qr") => {
    try {
      setError("");
      await openSession(sessionId);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      router.push(`/staff/${routeMode}-scan?sessionId=${sessionId}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to open session.");
    }
  };

  const performCloseLiveSession = async (sessionId: string) => {
    setError("");

    try {
      await closeSession(sessionId);
      if (selectedSession === sessionId) {
        setSelectedSession(null);
      }
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to close session.");
    }
  };

  const handleCloseLiveSession = (sessionId: string) => {
    if (Platform.OS === "web") {
      const confirmed =
        typeof globalThis.confirm === "function"
          ? globalThis.confirm("Are you sure you want to close this session?")
          : true;

      if (confirmed) {
        void performCloseLiveSession(sessionId);
      }
      return;
    }

    Alert.alert(
      "Close Session",
      "Are you sure you want to close this session?",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Confirm",
          style: "destructive",
          onPress: () => void performCloseLiveSession(sessionId),
        },
      ],
    );
  };

  const openSessions = sessions.filter((s) => s.status === "open");
  const scheduledSessions = sessions.filter((s) => s.status === "scheduled");

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <ScreenHeader title="Open Session" showBack subtitle="Start taking attendance" />
      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: bottomPad + 20, gap: 16 }} showsVerticalScrollIndicator={false}>
        {openSessions.length > 0 && (
          <View>
            <Text style={{ fontSize: 14, fontWeight: "700", color: colors.foreground, fontFamily: "Inter_700Bold", marginBottom: 10 }}>
              Live Sessions
            </Text>
            {openSessions.map((s) => (
              <View key={s.id} style={{ marginBottom: 10 }}>
                <LinearGradient colors={["#10B981", "#059669"]} style={styles.liveCard}>
                  <View style={styles.liveCardHeader}>
                    <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
                      <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: "#FFF" }} />
                      <Text style={{ fontSize: 12, color: "#FFFFFF", fontFamily: "Inter_600SemiBold" }}>LIVE</Text>
                    </View>
                    <View style={styles.liveActions}>
                      <Pressable style={styles.closeSessionBtn} onPress={() => handleCloseLiveSession(s.id)}>
                        <Text style={styles.closeSessionBtnText}>Close Session</Text>
                      </Pressable>
                    </View>
                  </View>
                  <Text style={{ fontSize: 17, fontWeight: "700", color: "#FFFFFF", fontFamily: "Inter_700Bold" }}>{s.courseName}</Text>
                  <Text style={{ fontSize: 13, color: "rgba(255,255,255,0.8)", fontFamily: "Inter_400Regular" }}>
                    {s.courseCode} · {s.startTime} - {s.endTime}
                  </Text>
                  {sessionAudienceLabel(s) ? (
                    <Text style={{ fontSize: 12, color: "rgba(255,255,255,0.8)", fontFamily: "Inter_500Medium" }}>
                      {sessionAudienceLabel(s)}
                    </Text>
                  ) : null}
                  <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: 12 }}>
                    <Text style={{ fontSize: 13, color: "rgba(255,255,255,0.9)", fontFamily: "Inter_500Medium" }}>
                      {s.presentCount}/{s.totalCount} students present
                    </Text>
                    <View style={{ flexDirection: "row", gap: 8 }}>
                      {(s.type === "face" || s.type === "both") && (
                        <Pressable style={styles.scanBtn} onPress={() => router.push(`/staff/face-scan?sessionId=${s.id}`)}>
                          <Ionicons name="scan" size={16} color="#FFF" />
                        </Pressable>
                      )}
                      {(s.type === "qr" || s.type === "both") && (
                        <Pressable style={styles.scanBtn} onPress={() => router.push(`/staff/qr-scan?sessionId=${s.id}`)}>
                          <Ionicons name="qr-code" size={16} color="#FFF" />
                        </Pressable>
                      )}
                    </View>
                  </View>
                </LinearGradient>
              </View>
            ))}
          </View>
        )}

        <View>
          <Text style={{ fontSize: 14, fontWeight: "700", color: colors.foreground, fontFamily: "Inter_700Bold", marginBottom: 10 }}>
            Scheduled Sessions
          </Text>
          {scheduledSessions.length === 0 ? (
            <Card style={{ alignItems: "center", paddingVertical: 28, gap: 8 }}>
              <Ionicons name="calendar-outline" size={36} color={colors.mutedForeground} />
              <Text style={{ color: colors.mutedForeground, fontFamily: "Inter_500Medium" }}>No scheduled sessions</Text>
              <Button title="Create Session" onPress={() => router.push("/staff/create-session")} variant="outline" size="sm" fullWidth={false} />
            </Card>
          ) : (
            scheduledSessions.map((s) => (
              <View key={s.id} style={{ marginBottom: 10 }}>
                <Pressable onPress={() => setSelectedSession(selectedSession === s.id ? null : s.id)}>
                  <Card style={{ borderWidth: selectedSession === s.id ? 2 : 0, borderColor: colors.primary }}>
                  <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
                    <View style={{ width: 44, height: 44, borderRadius: 12, backgroundColor: colors.secondary, alignItems: "center", justifyContent: "center" }}>
                      <Ionicons name="calendar" size={22} color={colors.primary} />
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text style={{ fontSize: 15, fontWeight: "600", color: colors.foreground, fontFamily: "Inter_600SemiBold" }}>
                        {s.courseName}
                      </Text>
                      <Text style={{ fontSize: 12, color: colors.mutedForeground, fontFamily: "Inter_400Regular" }}>
                        {s.courseCode} · {s.date} · {s.startTime}-{s.endTime}
                      </Text>
                      {sessionAudienceLabel(s) ? (
                        <Text style={{ fontSize: 12, color: colors.mutedForeground, fontFamily: "Inter_500Medium", marginTop: 2 }}>
                          {sessionAudienceLabel(s)}
                        </Text>
                      ) : null}
                    </View>
                    <Ionicons
                      name={selectedSession === s.id ? "checkmark-circle" : "ellipse-outline"}
                      size={22}
                      color={selectedSession === s.id ? colors.primary : colors.mutedForeground}
                    />
                  </View>
                  <View style={styles.scheduledActionsRow}>
                    <Button title="Edit" onPress={() => beginEditScheduledSession(s)} variant="outline" size="sm" fullWidth={false} style={styles.scheduledActionButton} />
                    <Button title="Delete" onPress={() => handleDeleteScheduledSession(s.id)} variant="danger" size="sm" fullWidth={false} style={styles.scheduledActionButton} />
                  </View>
                  </Card>
                </Pressable>
                {editingSessionId === s.id ? (
                  <Card style={{ gap: 14, marginTop: 10 }}>
                    <Text style={{ fontSize: 15, fontWeight: "700", color: colors.foreground, fontFamily: "Inter_700Bold" }}>
                      Edit Scheduled Session
                    </Text>
                    <InputField
                      label="Date"
                      placeholder="YYYY-MM-DD"
                      value={editDate}
                      onChangeText={(value) => setEditDate(sanitizeDateInput(value))}
                      icon={<Ionicons name="calendar-outline" size={16} color={colors.mutedForeground} />}
                    />
                    <InputField
                      label="Start Time"
                      placeholder="HH:mm"
                      value={editStartTime}
                      onChangeText={(value) => setEditStartTime(sanitizeTimeInput(value))}
                      icon={<Ionicons name="time-outline" size={16} color={colors.mutedForeground} />}
                    />
                    <InputField
                      label="End Time"
                      placeholder="HH:mm"
                      value={editEndTime}
                      onChangeText={(value) => setEditEndTime(sanitizeTimeInput(value))}
                      icon={<Ionicons name="time-outline" size={16} color={colors.mutedForeground} />}
                    />
                    <View style={{ gap: 8 }}>
                      <Text style={{ fontSize: 12, color: colors.mutedForeground, fontFamily: "Inter_600SemiBold" }}>
                        Attendance Method
                      </Text>
                      <View style={styles.editMethodRow}>
                        {TYPE_OPTIONS.map((option) => {
                          const isActive = editType === option.key;

                          return (
                            <Pressable
                              key={option.key}
                              onPress={() => setEditType(option.key)}
                              style={[
                                styles.editMethodBtn,
                                {
                                  backgroundColor: isActive ? colors.primary : colors.muted,
                                  borderColor: isActive ? colors.primary : colors.border,
                                },
                              ]}
                            >
                              <Ionicons
                                name={option.icon as any}
                                size={16}
                                color={isActive ? "#FFFFFF" : colors.mutedForeground}
                              />
                              <Text
                                style={{
                                  color: isActive ? "#FFFFFF" : colors.foreground,
                                  fontSize: 12,
                                  fontFamily: "Inter_600SemiBold",
                                }}
                              >
                                {option.label}
                              </Text>
                            </Pressable>
                          );
                        })}
                      </View>
                    </View>
                    <View style={styles.editActionsRow}>
                      <Button
                        title="Save"
                        onPress={() => handleSaveScheduledSession(s)}
                        loading={isLoading}
                        size="md"
                        fullWidth={false}
                        style={styles.editActionButton}
                      />
                      <Button
                        title="Cancel"
                        onPress={() => setEditingSessionId(null)}
                        variant="outline"
                        size="md"
                        fullWidth={false}
                        style={styles.editActionButton}
                      />
                    </View>
                  </Card>
                ) : null}
              </View>
            ))
          )}
        </View>

        {error ? (
          <Card style={{ backgroundColor: "#FEF2F2", borderColor: "#FECACA", borderWidth: 1 }}>
            <Text style={{ color: "#B91C1C", fontFamily: "Inter_500Medium" }}>{error}</Text>
          </Card>
        ) : null}

        {selectedSession && !openSessions.find((s) => s.id === selectedSession) && session && (
          <Card style={{ gap: 14 }}>
            <Text style={{ fontSize: 15, fontWeight: "700", color: colors.foreground, fontFamily: "Inter_700Bold" }}>
              Choose Attendance Mode
            </Text>
            <View style={{ flexDirection: "row", gap: 12 }}>
              {(session.type === "face" || session.type === "both") && (
                <Pressable onPress={() => handleOpen(session.id, "face")} style={styles.modeBtn} disabled={isLoading}>
                  <LinearGradient colors={["#2563EB", "#1D4ED8"]} style={styles.modeBtnGrad}>
                    <Ionicons name="scan" size={28} color="#FFF" />
                    <Text style={{ color: "#FFF", fontSize: 13, fontFamily: "Inter_700Bold" }}>Face</Text>
                    <Text style={{ color: "rgba(255,255,255,0.8)", fontSize: 11, fontFamily: "Inter_400Regular" }}>Recognition</Text>
                  </LinearGradient>
                </Pressable>
              )}
              {(session.type === "qr" || session.type === "both") && (
                <Pressable onPress={() => handleOpen(session.id, "qr")} style={styles.modeBtn} disabled={isLoading}>
                  <LinearGradient colors={["#6366F1", "#4F46E5"]} style={styles.modeBtnGrad}>
                    <Ionicons name="qr-code" size={28} color="#FFF" />
                    <Text style={{ color: "#FFF", fontSize: 13, fontFamily: "Inter_700Bold" }}>QR Code</Text>
                    <Text style={{ color: "rgba(255,255,255,0.8)", fontSize: 11, fontFamily: "Inter_400Regular" }}>Scanning</Text>
                  </LinearGradient>
                </Pressable>
              )}
            </View>
          </Card>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  liveCard: {
    padding: 16,
    borderRadius: 16,
  },
  liveCardHeader: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
    gap: 12,
    marginBottom: 8,
  },
  liveActions: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "flex-end",
    gap: 8,
    flexShrink: 1,
  },
  editSessionBtn: {
    borderRadius: 999,
    paddingHorizontal: 12,
    paddingVertical: 7,
    backgroundColor: "rgba(255,255,255,0.2)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.45)",
  },
  closeSessionBtn: {
    borderRadius: 999,
    paddingHorizontal: 12,
    paddingVertical: 7,
    backgroundColor: "rgba(153,27,27,0.18)",
    borderWidth: 1,
    borderColor: "rgba(254,226,226,0.55)",
  },
  closeSessionBtnText: {
    color: "#FFFFFF",
    fontSize: 12,
    fontFamily: "Inter_600SemiBold",
  },
  scanBtn: {
    width: 34,
    height: 34,
    borderRadius: 8,
    backgroundColor: "rgba(255,255,255,0.2)",
    alignItems: "center",
    justifyContent: "center",
  },
  modeBtn: {
    flex: 1,
    borderRadius: 16,
    overflow: "hidden",
  },
  modeBtnGrad: {
    padding: 20,
    alignItems: "center",
    gap: 6,
  },
  scheduledActionsRow: {
    flexDirection: "row",
    gap: 8,
    marginTop: 12,
  },
  scheduledActionButton: {
    flex: 1,
    minWidth: 0,
  },
  editMethodRow: {
    flexDirection: "row",
    gap: 8,
  },
  editMethodBtn: {
    flex: 1,
    minHeight: 42,
    borderRadius: 12,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    gap: 6,
  },
  editActionsRow: {
    flexDirection: "row",
    gap: 10,
    alignItems: "center",
  },
  editActionButton: {
    flex: 1,
    minWidth: 0,
  },
});
