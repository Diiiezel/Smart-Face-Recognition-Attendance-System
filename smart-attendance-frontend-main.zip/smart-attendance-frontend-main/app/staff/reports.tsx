import { Button, Card, SectionHeader } from "@/components/UI";
import { ScreenHeader } from "@/components/ScreenHeader";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { exportCsv } from "@/utils/csvExport";
import { buildSessionReportsCsv } from "@/utils/sessionReportsCsv";
import { Ionicons } from "@expo/vector-icons";
import React, { useMemo, useState } from "react";
import { Platform, ScrollView, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

export default function Reports() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { loadSessionReport, reportsOverview, sessions } = useApp();
  const [isExporting, setIsExporting] = useState(false);
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  const logicalReport = useMemo(() => {
    const fallbackCourses = reportsOverview?.courses || [];

    if (sessions.length === 0) {
      return {
        averageAttendanceRate: reportsOverview?.totals.averageAttendanceRate ?? 0,
        sessionsCount: reportsOverview?.totals.sessionsCount ?? 0,
        studentsCount: reportsOverview?.totals.studentsCount ?? 0,
        courses: fallbackCourses,
      };
    }

    const groupedCourses = new Map<string, {
      id: string;
      code: string;
      name: string;
      totalStudents: number;
      sessionsCount: number;
      attendanceRate: number;
      presentCount: number;
      possibleAttendances: number;
    }>();

    for (const session of sessions) {
      const key = `${session.courseCode}-${session.courseName}`;
      const current = groupedCourses.get(key) || {
        id: session.courseId || session.id,
        code: session.courseCode,
        name: session.courseName,
        totalStudents: 0,
        sessionsCount: 0,
        attendanceRate: 0,
        presentCount: 0,
        possibleAttendances: 0,
      };

      current.sessionsCount += 1;
      current.totalStudents = Math.max(current.totalStudents, session.totalCount);
      current.presentCount += session.presentCount;
      current.possibleAttendances += session.totalCount;
      current.attendanceRate = current.possibleAttendances > 0
        ? Math.round((current.presentCount / current.possibleAttendances) * 100)
        : 0;

      groupedCourses.set(key, current);
    }

    const courses = Array.from(groupedCourses.values());
    const possibleAttendances = sessions.reduce((sum, session) => sum + session.totalCount, 0);
    const presentCount = sessions.reduce((sum, session) => sum + session.presentCount, 0);

    return {
      averageAttendanceRate: possibleAttendances > 0 ? Math.round((presentCount / possibleAttendances) * 100) : 0,
      sessionsCount: sessions.length,
      studentsCount: reportsOverview?.totals.studentsCount ?? Math.max(...courses.map((course) => course.totalStudents), 0),
      courses,
    };
  }, [reportsOverview, sessions]);
  const courses = logicalReport.courses;
  const sessionsByCourse = useMemo(() => {
    const grouped = new Map<string, typeof sessions>();

    sessions.forEach((session) => {
      const key = `${session.courseCode}-${session.courseName}`;
      grouped.set(key, [...(grouped.get(key) || []), session]);
    });

    return Array.from(grouped.values());
  }, [sessions]);

  const handleExportReports = async () => {
    setIsExporting(true);
    try {
      const csv = await buildSessionReportsCsv(sessions, loadSessionReport);
      await exportCsv("attendance-session-records.csv", csv);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <ScreenHeader title="Attendance Reports" showBack subtitle="Analytics & insights" />
      <ScrollView
        contentContainerStyle={{ padding: 20, paddingBottom: bottomPad + 20, gap: 20 }}
        showsVerticalScrollIndicator={false}
      >
        <View style={{ flexDirection: "row", gap: 10 }}>
          <Card style={{ flex: 1, padding: 16 }}>
            <Text style={styles.cardLabel}>Avg. Rate</Text>
            <Text style={[styles.cardValue, { color: "#10B981" }]}>
              {logicalReport.averageAttendanceRate}%
            </Text>
          </Card>
          <Card style={{ flex: 1, padding: 16 }}>
            <Text style={styles.cardLabel}>Sessions</Text>
            <Text style={[styles.cardValue, { color: colors.primary }]}>
              {logicalReport.sessionsCount}
            </Text>
          </Card>
          <Card style={{ flex: 1, padding: 16 }}>
            <Text style={styles.cardLabel}>Students</Text>
            <Text style={[styles.cardValue, { color: "#6366F1" }]}>
              {logicalReport.studentsCount}
            </Text>
          </Card>
        </View>

        <Card style={{ gap: 16 }}>
          <View style={styles.sectionHeaderRow}>
            <Text style={styles.sectionTitle}>Session Records</Text>
            <Button
              title={isExporting ? "Exporting..." : "Export CSV"}
              onPress={handleExportReports}
              variant="outline"
              size="sm"
              fullWidth={false}
              disabled={sessions.length === 0 || isExporting}
            />
          </View>
          {sessionsByCourse.length === 0 ? (
            <View style={{ alignItems: "center", paddingVertical: 24, gap: 8 }}>
              <Ionicons name="calendar-outline" size={36} color={colors.mutedForeground} />
              <Text style={{ color: colors.mutedForeground, fontFamily: "Inter_500Medium" }}>
                No session records yet
              </Text>
            </View>
          ) : (
            sessionsByCourse.map((courseSessions) => (
              <View key={`${courseSessions[0].courseCode}-${courseSessions[0].courseName}`} style={{ gap: 10 }}>
                <View>
                  <Text style={styles.courseName}>{courseSessions[0].courseName}</Text>
                  <Text style={styles.courseMeta}>
                    {courseSessions[0].courseCode} · {courseSessions.length} sessions
                  </Text>
                </View>
                {courseSessions.map((session, index) => (
                  <View key={session.id} style={styles.sessionRecord}>
                    <View style={{ flex: 1 }}>
                      <Text style={styles.sessionTitle}>Session {index + 1}</Text>
                      <Text style={styles.courseMeta}>
                        {session.date} · {session.startTime}-{session.endTime} · {session.type.toUpperCase()}
                      </Text>
                    </View>
                    <View style={{ alignItems: "flex-end" }}>
                      <Text style={styles.sessionCount}>{session.presentCount}</Text>
                      <Text style={styles.courseMeta}>attended</Text>
                    </View>
                  </View>
                ))}
              </View>
            ))
          )}
        </Card>

        <Card>
          <SectionHeader title="By Course" />
          {courses.length === 0 ? (
            <View style={{ alignItems: "center", paddingVertical: 24, gap: 8 }}>
              <Ionicons name="analytics-outline" size={36} color={colors.mutedForeground} />
              <Text style={{ color: colors.mutedForeground, fontFamily: "Inter_500Medium" }}>
                No report data yet
              </Text>
            </View>
          ) : (
            courses.map((stat, i) => (
              <View key={stat.id} style={{ marginBottom: i < courses.length - 1 ? 18 : 0 }}>
                <View style={styles.courseRow}>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.courseName}>{stat.name}</Text>
                    <Text style={styles.courseMeta}>
                      {stat.code} · {stat.totalStudents} students · {stat.sessionsCount} sessions
                    </Text>
                  </View>
                  <Text
                    style={{
                      fontSize: 17,
                      fontWeight: "700",
                      color:
                        stat.attendanceRate >= 85
                          ? "#10B981"
                          : stat.attendanceRate >= 75
                            ? "#F59E0B"
                            : "#EF4444",
                      fontFamily: "Inter_700Bold",
                    }}
                  >
                    {stat.attendanceRate}%
                  </Text>
                </View>
                <View style={styles.progressTrack}>
                  <View
                    style={{
                      width: `${stat.attendanceRate}%`,
                      height: 6,
                      backgroundColor:
                        stat.attendanceRate >= 85
                          ? "#10B981"
                          : stat.attendanceRate >= 75
                            ? "#F59E0B"
                            : "#EF4444",
                      borderRadius: 3,
                    }}
                  />
                </View>
              </View>
            ))
          )}
        </Card>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  cardLabel: {
    fontSize: 10,
    color: "#64748B",
    fontFamily: "Inter_600SemiBold",
    textTransform: "uppercase",
    letterSpacing: 0.8,
    marginBottom: 6,
  },
  cardValue: {
    fontSize: 26,
    fontWeight: "700",
    fontFamily: "Inter_700Bold",
    letterSpacing: -0.5,
  },
  sectionTitle: {
    fontSize: 15,
    fontWeight: "700",
    color: "#0F172A",
    fontFamily: "Inter_700Bold",
  },
  sectionHeaderRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 12,
  },
  courseRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: 8,
  },
  courseName: {
    fontSize: 14,
    fontWeight: "600",
    color: "#0F172A",
    fontFamily: "Inter_600SemiBold",
  },
  courseMeta: {
    fontSize: 11,
    color: "#64748B",
    fontFamily: "Inter_400Regular",
    marginTop: 2,
  },
  progressTrack: {
    height: 6,
    backgroundColor: "#E2E8F0",
    borderRadius: 3,
    overflow: "hidden",
  },
  sessionRecord: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    borderRadius: 12,
    backgroundColor: "#F8FAFC",
    padding: 12,
  },
  sessionTitle: {
    fontSize: 13,
    fontFamily: "Inter_700Bold",
    color: "#0F172A",
  },
  sessionCount: {
    fontSize: 20,
    fontFamily: "Inter_700Bold",
    color: "#10B981",
  },
});
