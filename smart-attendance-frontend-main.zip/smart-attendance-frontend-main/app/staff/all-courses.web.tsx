import { Card } from "@/components/UI";
import { ScreenHeader } from "@/components/ScreenHeader";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useMemo, useState } from "react";
import { FlatList, Pressable, StyleSheet, Text, TextInput, View } from "react-native";

const COURSE_TINTS = [
  { bg: "#DBEAFE", fg: "#2563EB" },
  { bg: "#EEF2FF", fg: "#6366F1" },
  { bg: "#D1FAE5", fg: "#10B981" },
  { bg: "#FEF3C7", fg: "#F59E0B" },
];

export default function AllCoursesScreen() {
  const colors = useColors();
  const { courses } = useApp();
  const [search, setSearch] = useState("");

  const filteredCourses = useMemo(() => {
    const query = search.trim().toLowerCase();
    if (!query) return courses;
    return courses.filter(
      (course) =>
        course.name.toLowerCase().includes(query) ||
        course.code.toLowerCase().includes(query) ||
        course.department.toLowerCase().includes(query),
    );
  }, [courses, search]);

  return (
    <View style={[styles.page, { backgroundColor: colors.background }]}>
      <ScreenHeader title="Manage Courses" showBack subtitle={`${courses.length} total courses`} />
      <View style={styles.shell}>
        <Card style={styles.toolbar}>
          <View style={styles.toolbarText}>
            <Text style={[styles.eyebrow, { color: colors.mutedForeground }]}>Course operations</Text>
            <Text style={[styles.title, { color: colors.foreground }]}>Courses and enrolled student rosters</Text>
          </View>
          <View style={[styles.searchBox, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Ionicons name="search-outline" size={18} color={colors.mutedForeground} />
            <TextInput
              style={[styles.searchInput, { color: colors.foreground }]}
              placeholder="Search courses"
              placeholderTextColor={colors.mutedForeground}
              value={search}
              onChangeText={setSearch}
            />
          </View>
        </Card>

        <FlatList
          data={filteredCourses}
          keyExtractor={(item) => item.id}
          numColumns={2}
          columnWrapperStyle={styles.gridRow}
          contentContainerStyle={styles.grid}
          renderItem={({ item, index }) => {
            const tint = COURSE_TINTS[index % COURSE_TINTS.length];
            return (
              <Card
                style={styles.courseCard}
                onPress={() =>
                  router.push({
                    pathname: "/staff/course-students",
                    params: { courseId: item.id, courseCode: item.code },
                  })
                }
              >
                <View style={styles.cardTop}>
                  <View style={[styles.courseIcon, { backgroundColor: tint.bg }]}>
                    <Ionicons name="book" size={22} color={tint.fg} />
                  </View>
                  <Ionicons name="chevron-forward" size={18} color={colors.mutedForeground} />
                </View>
                <View>
                  <Text style={[styles.courseCode, { color: tint.fg }]}>{item.code}</Text>
                  <Text style={[styles.courseName, { color: colors.foreground }]}>{item.name}</Text>
                </View>
                <View style={styles.metaRow}>
                  <View>
                    <Text style={[styles.metaLabel, { color: colors.mutedForeground }]}>Students</Text>
                    <Text style={[styles.metaValue, { color: colors.foreground }]}>{item.enrolledCount}</Text>
                  </View>
                  <View>
                    <Text style={[styles.metaLabel, { color: colors.mutedForeground }]}>Department</Text>
                    <Text style={[styles.metaValue, { color: colors.foreground }]}>{item.department}</Text>
                  </View>
                </View>
              </Card>
            );
          }}
          ListEmptyComponent={
            <Card style={styles.emptyCard}>
              <Ionicons name="book-outline" size={40} color={colors.mutedForeground} />
              <Text style={[styles.emptyTitle, { color: colors.foreground }]}>No courses found</Text>
            </Card>
          }
          showsVerticalScrollIndicator={false}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  cardTop: {
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "space-between",
  },
  courseCard: {
    flex: 1,
    gap: 18,
    minWidth: 320,
  },
  courseCode: {
    fontFamily: "Inter_700Bold",
    fontSize: 13,
    marginBottom: 4,
  },
  courseIcon: {
    alignItems: "center",
    borderRadius: 14,
    height: 48,
    justifyContent: "center",
    width: 48,
  },
  courseName: {
    fontFamily: "Inter_700Bold",
    fontSize: 19,
    letterSpacing: -0.2,
  },
  emptyCard: {
    alignItems: "center",
    gap: 10,
    paddingVertical: 50,
  },
  emptyTitle: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 16,
  },
  eyebrow: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 12,
    letterSpacing: 0.7,
    textTransform: "uppercase",
  },
  grid: {
    gap: 16,
    paddingBottom: 36,
  },
  gridRow: {
    gap: 16,
  },
  metaLabel: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 11,
    letterSpacing: 0.5,
    textTransform: "uppercase",
  },
  metaRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 24,
  },
  metaValue: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 14,
    marginTop: 4,
  },
  page: {
    flex: 1,
  },
  searchBox: {
    alignItems: "center",
    borderRadius: 14,
    borderWidth: 1,
    flexDirection: "row",
    gap: 10,
    minWidth: 320,
    paddingHorizontal: 14,
    paddingVertical: 12,
  },
  searchInput: {
    flex: 1,
    fontFamily: "Inter_400Regular",
    fontSize: 15,
    outlineStyle: "none",
  } as any,
  shell: {
    alignSelf: "center",
    gap: 18,
    maxWidth: 1180,
    padding: 28,
    width: "100%",
  },
  title: {
    fontFamily: "Inter_700Bold",
    fontSize: 24,
    letterSpacing: -0.3,
  },
  toolbar: {
    alignItems: "center",
    flexDirection: "row",
    gap: 18,
  },
  toolbarText: {
    flex: 1,
    gap: 4,
  },
});
