import { Button, Card, InputField, SelectionField } from "@/components/UI";
import { ScreenHeader } from "@/components/ScreenHeader";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { LEVEL_OPTIONS, MAJOR_OPTIONS } from "@/mocks/academicOptions";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import React, { useState } from "react";
import { ScrollView, StyleSheet, Text, View } from "react-native";

const VALID_DEPARTMENTS = new Set<string>(MAJOR_OPTIONS.map((option) => option.value));

function initialDepartments(value?: string) {
  return (value || "")
    .split(",")
    .map((item) => item.trim())
    .filter((item) => VALID_DEPARTMENTS.has(item));
}

export default function CreateCourse() {
  const colors = useColors();
  const { staffProfile, createCourse, isLoading } = useApp();
  const [courseName, setCourseName] = useState("");
  const [courseCode, setCourseCode] = useState("");
  const [selectedLevels, setSelectedLevels] = useState<string[]>([]);
  const [selectedDepartments, setSelectedDepartments] = useState<string[]>(initialDepartments(staffProfile?.department));
  const [done, setDone] = useState(false);
  const [error, setError] = useState("");

  const handleCreate = async () => {
    if (!courseName || !courseCode || selectedDepartments.length === 0 || selectedLevels.length === 0) {
      setError("Please fill in all required fields.");
      return;
    }

    setError("");
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    try {
      await createCourse({
        name: courseName,
        code: courseCode.toUpperCase(),
        semester: selectedDepartments.join(", ") || undefined,
        level: selectedLevels.join(", "),
        departments: selectedDepartments,
        levels: selectedLevels,
      });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setDone(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to create course.");
    }
  };

  return (
    <View style={[styles.page, { backgroundColor: colors.background }]}>
      <ScreenHeader title="Create Course" showBack subtitle="Add a new course to the system" />
      <ScrollView contentContainerStyle={styles.shell} keyboardShouldPersistTaps="handled">
        {done ? (
          <Card style={styles.successCard}>
            <View style={styles.successIcon}>
              <Ionicons name="checkmark-circle" size={46} color={colors.success} />
            </View>
            <Text style={[styles.successTitle, { color: colors.foreground }]}>Course Created</Text>
            <Text style={[styles.successCopy, { color: colors.mutedForeground }]}>
              {courseCode.toUpperCase()} - {courseName} has been added successfully.
            </Text>
            <View style={styles.actionRow}>
              <Button title="Back to Dashboard" onPress={() => router.back()} fullWidth={false} />
              <Button
                title="Create Another"
                onPress={() => {
                  setDone(false);
                  setCourseName("");
                  setCourseCode("");
                  setSelectedDepartments([]);
                  setSelectedLevels([]);
                }}
                variant="outline"
                fullWidth={false}
              />
            </View>
          </Card>
        ) : (
          <View style={styles.layout}>
            <View style={styles.formColumn}>
              <Card style={styles.formCard}>
                <Text style={[styles.cardTitle, { color: colors.foreground }]}>Course Information</Text>
                <InputField
                  label="Course Name"
                  placeholder="e.g. Machine Learning"
                  value={courseName}
                  onChangeText={setCourseName}
                  icon={<Ionicons name="book-outline" size={18} color={colors.mutedForeground} />}
                />
                <InputField
                  label="Course Code"
                  placeholder="e.g. CS401"
                  value={courseCode}
                  onChangeText={setCourseCode}
                  autoCapitalize="characters"
                  icon={<Ionicons name="code-outline" size={18} color={colors.mutedForeground} />}
                />
                <SelectionField
                  label="Department"
                  placeholder="Select one or more departments"
                  selectedValues={selectedDepartments}
                  onSelect={(value) =>
                    setSelectedDepartments((current) =>
                      current.includes(value) ? current.filter((item) => item !== value) : [...current, value],
                    )
                  }
                  options={MAJOR_OPTIONS.map((option) => ({ ...option }))}
                  icon={<Ionicons name="business-outline" size={18} color={colors.mutedForeground} />}
                  multiSelect
                />
                <SelectionField
                  label="Level"
                  placeholder="Select one or more levels"
                  selectedValues={selectedLevels}
                  onSelect={(value) =>
                    setSelectedLevels((current) =>
                      current.includes(value) ? current.filter((item) => item !== value) : [...current, value],
                    )
                  }
                  options={LEVEL_OPTIONS.map((option) => ({ ...option }))}
                  icon={<Ionicons name="school-outline" size={18} color={colors.mutedForeground} />}
                  multiSelect
                />
              </Card>
              {error ? <Text style={[styles.errorText, { color: colors.destructive }]}>{error}</Text> : null}
              <Button
                title="Create Course"
                onPress={handleCreate}
                loading={isLoading}
                disabled={!courseName || !courseCode || selectedDepartments.length === 0 || selectedLevels.length === 0}
                size="lg"
              />
            </View>
            <Card style={styles.sideCard}>
              <Text style={[styles.eyebrow, { color: colors.mutedForeground }]}>Instructor</Text>
              <View style={styles.instructorRow}>
                <View style={[styles.avatar, { backgroundColor: colors.secondary }]}>
                  <Ionicons name="person" size={24} color={colors.primary} />
                </View>
                <View>
                  <Text style={[styles.instructorName, { color: colors.foreground }]}>{staffProfile?.name}</Text>
                  <Text style={[styles.instructorMeta, { color: colors.mutedForeground }]}>{staffProfile?.title}</Text>
                </View>
              </View>
              <Text style={[styles.sideCopy, { color: colors.mutedForeground }]}>
                New courses remain connected to the current staff profile and existing frontend course workflow.
              </Text>
            </Card>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  actionRow: {
    flexDirection: "row",
    gap: 12,
  },
  avatar: {
    alignItems: "center",
    borderRadius: 16,
    height: 52,
    justifyContent: "center",
    width: 52,
  },
  cardTitle: {
    fontFamily: "Inter_700Bold",
    fontSize: 18,
  },
  errorText: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 13,
  },
  eyebrow: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 12,
    letterSpacing: 0.7,
    textTransform: "uppercase",
  },
  formCard: {
    gap: 18,
  },
  formColumn: {
    flex: 1,
    gap: 14,
    minWidth: 520,
  },
  instructorMeta: {
    fontFamily: "Inter_400Regular",
    fontSize: 13,
    marginTop: 2,
  },
  instructorName: {
    fontFamily: "Inter_700Bold",
    fontSize: 18,
  },
  instructorRow: {
    alignItems: "center",
    flexDirection: "row",
    gap: 14,
    marginTop: 18,
  },
  layout: {
    flexDirection: "row",
    gap: 18,
  },
  page: {
    flex: 1,
  },
  shell: {
    alignSelf: "center",
    maxWidth: 1180,
    padding: 28,
    width: "100%",
  },
  sideCard: {
    flex: 0.7,
    minWidth: 320,
  },
  sideCopy: {
    fontFamily: "Inter_400Regular",
    fontSize: 14,
    lineHeight: 21,
    marginTop: 22,
  },
  successCard: {
    alignItems: "center",
    gap: 14,
    paddingVertical: 54,
  },
  successCopy: {
    fontFamily: "Inter_400Regular",
    fontSize: 15,
    textAlign: "center",
  },
  successIcon: {
    alignItems: "center",
    backgroundColor: "#DCFCE7",
    borderRadius: 40,
    height: 80,
    justifyContent: "center",
    width: 80,
  },
  successTitle: {
    fontFamily: "Inter_700Bold",
    fontSize: 28,
    letterSpacing: -0.4,
  },
});
