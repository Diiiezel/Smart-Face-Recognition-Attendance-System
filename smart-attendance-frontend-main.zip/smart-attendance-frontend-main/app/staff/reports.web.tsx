import { Button, Card, SectionHeader } from "@/components/UI";
import { ScreenHeader } from "@/components/ScreenHeader";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { exportCsv } from "@/utils/csvExport";
import { buildSessionReportsCsv } from "@/utils/sessionReportsCsv";
import { Ionicons } from "@expo/vector-icons";
import React, { useMemo, useState } from "react";
import { ScrollView, StyleSheet, Text, View } from "react-native";

export default function Reports() {
  const colors = useColors();
  const { loadSessionReport, reportsOverview, sessions } = useApp();
  const [isExporting, setIsExporting] = useState(false);
  const logicalReport = useMemo(() => {
    const fallbackCourses = reportsOverview?.courses || [];

    if (sessions.length === 0) {
      return {
        averageAttendanceRate: reportsOverview?.totals.averageAttendanceRate ?? 0,
        sessionsCount: reportsOverview?.totals.sessionsCount ?? 0,
        studentsCount: reportsOverview?.totals.studentsCount ?? 0,
        courses: fallbackCourses,
      };
    }

    const groupedCourses = new Map<string, {
      id: string;
      code: string;
      name: string;
      totalStudents: number;
      sessionsCount: number;
      attendanceRate: number;
      presentCount: number;
      possibleAttendances: number;
    }>();

    for (const session of sessions) {
      const key = `${session.courseCode}-${session.courseName}`;
      const current = groupedCourses.get(key) || {
        id: session.courseId || session.id,
        code: session.courseCode,
        name: session.courseName,
        totalStudents: 0,
        sessionsCount: 0,
        attendanceRate: 0,
        presentCount: 0,
        possibleAttendances: 0,
      };

      current.sessionsCount += 1;
      current.totalStudents = Math.max(current.totalStudents, session.totalCount);
      current.presentCount += session.presentCount;
      current.possibleAttendances += session.totalCount;
      current.attendanceRate = current.possibleAttendances > 0
        ? Math.round((current.presentCount / current.possibleAttendances) * 100)
        : 0;

      groupedCourses.set(key, current);
    }

    const courses = Array.from(groupedCourses.values());
    const possibleAttendances = sessions.reduce((sum, session) => sum + session.totalCount, 0);
    const presentCount = sessions.reduce((sum, session) => sum + session.presentCount, 0);

    return {
      averageAttendanceRate: possibleAttendances > 0 ? Math.round((presentCount / possibleAttendances) * 100) : 0,
      sessionsCount: sessions.length,
      studentsCount: reportsOverview?.totals.studentsCount ?? Math.max(...courses.map((course) => course.totalStudents), 0),
      courses,
    };
  }, [reportsOverview, sessions]);
  const courses = logicalReport.courses;
  const sessionsByCourse = useMemo(() => {
    const grouped = new Map<string, typeof sessions>();
    sessions.forEach((session) => {
      const key = `${session.courseCode}-${session.courseName}`;
      grouped.set(key, [...(grouped.get(key) || []), session]);
    });
    return Array.from(grouped.values());
  }, [sessions]);

  const handleExportReports = async () => {
    setIsExporting(true);
    try {
      const csv = await buildSessionReportsCsv(sessions, loadSessionReport);
      await exportCsv("attendance-session-records.csv", csv);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <View style={[styles.page, { backgroundColor: colors.background }]}>
      <ScreenHeader title="Attendance Reports" showBack subtitle="Analytics & insights" />
      <ScrollView contentContainerStyle={styles.shell} showsVerticalScrollIndicator={false}>
        <View style={styles.metricGrid}>
          <Card style={styles.metricCard}>
            <Text style={[styles.metricLabel, { color: colors.mutedForeground }]}>Avg. Rate</Text>
            <Text style={[styles.metricValue, { color: colors.success }]}>{logicalReport.averageAttendanceRate}%</Text>
          </Card>
          <Card style={styles.metricCard}>
            <Text style={[styles.metricLabel, { color: colors.mutedForeground }]}>Sessions</Text>
            <Text style={[styles.metricValue, { color: colors.primary }]}>{logicalReport.sessionsCount}</Text>
          </Card>
          <Card style={styles.metricCard}>
            <Text style={[styles.metricLabel, { color: colors.mutedForeground }]}>Students</Text>
            <Text style={[styles.metricValue, { color: colors.accent }]}>{logicalReport.studentsCount}</Text>
          </Card>
        </View>

        <View style={styles.layout}>
          <Card style={styles.recordsPanel}>
            <View style={styles.sectionHeaderRow}>
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Session Records</Text>
              <Button title={isExporting ? "Exporting..." : "Export CSV"} onPress={handleExportReports} variant="outline" size="sm" fullWidth={false} disabled={sessions.length === 0 || isExporting} />
            </View>
            {sessionsByCourse.length === 0 ? (
              <View style={styles.emptyState}>
                <Ionicons name="calendar-outline" size={36} color={colors.mutedForeground} />
                <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>No session records yet</Text>
              </View>
            ) : (
              <View style={styles.courseStack}>
                {sessionsByCourse.map((courseSessions) => (
                  <View key={`${courseSessions[0].courseCode}-${courseSessions[0].courseName}`} style={styles.courseGroup}>
                    <View>
                      <Text style={[styles.courseName, { color: colors.foreground }]}>{courseSessions[0].courseName}</Text>
                      <Text style={[styles.courseMeta, { color: colors.mutedForeground }]}>
                        {courseSessions[0].courseCode} · {courseSessions.length} sessions
                      </Text>
                    </View>
                    {courseSessions.map((session, index) => (
                      <View key={session.id} style={[styles.sessionRecord, { backgroundColor: colors.background, borderColor: colors.border }]}>
                        <View style={styles.sessionMain}>
                          <Text style={[styles.sessionTitle, { color: colors.foreground }]}>Session {index + 1}</Text>
                          <Text style={[styles.courseMeta, { color: colors.mutedForeground }]}>
                            {session.date} · {session.startTime}-{session.endTime} · {session.type.toUpperCase()}
                          </Text>
                        </View>
                        <View style={styles.sessionCountBlock}>
                          <Text style={[styles.sessionCount, { color: colors.success }]}>{session.presentCount}</Text>
                          <Text style={[styles.courseMeta, { color: colors.mutedForeground }]}>attended</Text>
                        </View>
                      </View>
                    ))}
                  </View>
                ))}
              </View>
            )}
          </Card>

          <Card style={styles.coursePanel}>
            <SectionHeader title="By Course" />
            {courses.length === 0 ? (
              <View style={styles.emptyState}>
                <Ionicons name="analytics-outline" size={36} color={colors.mutedForeground} />
                <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>No report data yet</Text>
              </View>
            ) : (
              <View style={styles.courseStack}>
                {courses.map((stat) => {
                  const statColor = stat.attendanceRate >= 85 ? colors.success : stat.attendanceRate >= 75 ? colors.warning : colors.destructive;
                  return (
                    <View key={stat.id} style={styles.courseStat}>
                      <View style={styles.courseRow}>
                        <View style={styles.sessionMain}>
                          <Text style={[styles.courseName, { color: colors.foreground }]}>{stat.name}</Text>
                          <Text style={[styles.courseMeta, { color: colors.mutedForeground }]}>
                            {stat.code} · {stat.totalStudents} students · {stat.sessionsCount} sessions
                          </Text>
                        </View>
                        <Text style={[styles.rateText, { color: statColor }]}>{stat.attendanceRate}%</Text>
                      </View>
                      <View style={[styles.progressTrack, { backgroundColor: colors.muted }]}>
                        <View style={[styles.progressFill, { width: `${stat.attendanceRate}%`, backgroundColor: statColor }]} />
                      </View>
                    </View>
                  );
                })}
              </View>
            )}
          </Card>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  courseGroup: {
    gap: 10,
  },
  courseMeta: {
    fontFamily: "Inter_400Regular",
    fontSize: 12,
  },
  courseName: {
    fontFamily: "Inter_700Bold",
    fontSize: 15,
  },
  coursePanel: {
    flex: 0.85,
    minWidth: 360,
  },
  courseRow: {
    alignItems: "flex-start",
    flexDirection: "row",
    gap: 12,
  },
  courseStack: {
    gap: 16,
  },
  courseStat: {
    gap: 9,
  },
  emptyState: {
    alignItems: "center",
    gap: 8,
    paddingVertical: 34,
  },
  emptyText: {
    fontFamily: "Inter_500Medium",
    fontSize: 14,
  },
  layout: {
    flexDirection: "row",
    gap: 18,
  },
  metricCard: {
    flex: 1,
    minWidth: 220,
  },
  metricGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 16,
  },
  metricLabel: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 12,
    letterSpacing: 0.7,
    textTransform: "uppercase",
  },
  metricValue: {
    fontFamily: "Inter_700Bold",
    fontSize: 38,
    letterSpacing: -0.9,
    marginTop: 6,
  },
  page: {
    flex: 1,
  },
  progressFill: {
    borderRadius: 999,
    height: 8,
  },
  progressTrack: {
    borderRadius: 999,
    height: 8,
    overflow: "hidden",
  },
  rateText: {
    fontFamily: "Inter_700Bold",
    fontSize: 18,
  },
  recordsPanel: {
    flex: 1.25,
    gap: 18,
    minWidth: 520,
  },
  sectionHeaderRow: {
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 12,
  },
  sectionTitle: {
    fontFamily: "Inter_700Bold",
    fontSize: 18,
  },
  sessionCount: {
    fontFamily: "Inter_700Bold",
    fontSize: 22,
  },
  sessionCountBlock: {
    alignItems: "flex-end",
  },
  sessionMain: {
    flex: 1,
    gap: 3,
  },
  sessionRecord: {
    alignItems: "center",
    borderRadius: 14,
    borderWidth: 1,
    flexDirection: "row",
    gap: 12,
    padding: 14,
  },
  sessionTitle: {
    fontFamily: "Inter_700Bold",
    fontSize: 14,
  },
  shell: {
    alignSelf: "center",
    gap: 18,
    maxWidth: 1180,
    padding: 28,
    width: "100%",
  },
});
