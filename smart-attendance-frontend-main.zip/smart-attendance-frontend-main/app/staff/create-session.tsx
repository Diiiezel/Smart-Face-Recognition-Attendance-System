import { Button, Card, InputField } from "@/components/UI";
import { ScreenHeader } from "@/components/ScreenHeader";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { buildFutureSessionDateTimes } from "@/utils/dateTime";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import React, { useState } from "react";
import { Platform, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const SESSION_DATE_TIME_ERROR = "Please enter a valid session date and time.";
const SESSION_FUTURE_DATE_TIME_ERROR = "Please choose a valid future session date and time.";

export default function CreateSession() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { courses, createSession, isLoading } = useApp();

  const [selectedCourse, setSelectedCourse] = useState<string | null>(null);
  const [date, setDate] = useState("2026-03-31");
  const [startTime, setStartTime] = useState("10:00");
  const [endTime, setEndTime] = useState("11:30");
  const [type, setType] = useState<"face" | "qr" | "both">("face");
  const [done, setDone] = useState(false);
  const [error, setError] = useState("");
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  const selectedCourseData = courses.find((c) => c.id === selectedCourse);

  const handleCreate = async () => {
    if (!selectedCourse || !type) {
      setError(SESSION_DATE_TIME_ERROR);
      return;
    }

    const dateTimes = buildFutureSessionDateTimes(date, startTime, endTime);

    if (!dateTimes) {
      setError(SESSION_FUTURE_DATE_TIME_ERROR);
      return;
    }

    try {
      setError("");
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      await createSession({
        courseId: selectedCourse,
        method: type,
        startsAt: dateTimes.startsAt,
        endsAt: dateTimes.endsAt,
      });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setDone(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to create session.");
    }
  };

  const TYPE_OPTIONS = [
    { key: "face" as const, label: "Face Recognition", icon: "scan", color: "#2563EB", bg: "#DBEAFE" },
    { key: "qr" as const, label: "QR Code", icon: "qr-code", color: "#6366F1", bg: "#EEF2FF" },
    { key: "both" as const, label: "Both", icon: "apps", color: "#10B981", bg: "#D1FAE5" },
  ];

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <ScreenHeader title="Create Session" showBack subtitle="Schedule an attendance session" />
      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: bottomPad + 20, gap: 16 }} showsVerticalScrollIndicator={false}>
        {done ? (
          <Card style={{ alignItems: "center", paddingVertical: 40, gap: 14 }}>
            <View style={{ width: 72, height: 72, borderRadius: 36, backgroundColor: "#D1FAE5", alignItems: "center", justifyContent: "center" }}>
              <Ionicons name="checkmark-circle" size={44} color="#10B981" />
            </View>
            <Text style={{ fontSize: 22, fontWeight: "700", color: colors.foreground, fontFamily: "Inter_700Bold" }}>Session Created!</Text>
            <Text style={{ fontSize: 14, color: colors.mutedForeground, textAlign: "center", fontFamily: "Inter_400Regular" }}>
              {selectedCourseData?.code} session for {date} has been scheduled.
            </Text>
            <Button title="Open Session Now" onPress={() => router.push("/staff/open-session")} />
            <Button title="Back to Dashboard" onPress={() => router.replace("/staff/dashboard")} variant="outline" />
          </Card>
        ) : (
          <>
            <Card>
              <Text style={{ fontSize: 15, fontWeight: "700", color: colors.foreground, fontFamily: "Inter_700Bold", marginBottom: 14 }}>
                Select Course
              </Text>
              {courses.map((course) => (
                <Pressable
                  key={course.id}
                  onPress={() => setSelectedCourse(course.id)}
                  style={[
                    styles.courseOption,
                    {
                      backgroundColor: selectedCourse === course.id ? "#DBEAFE" : colors.muted,
                      borderWidth: selectedCourse === course.id ? 1.5 : 0,
                      borderColor: colors.primary,
                    },
                  ]}
                >
                  <View style={{ flex: 1 }}>
                    <Text style={{ fontSize: 14, fontWeight: "600", color: colors.foreground, fontFamily: "Inter_600SemiBold" }}>
                      {course.code} – {course.name}
                    </Text>
                    <Text style={{ fontSize: 12, color: colors.mutedForeground, fontFamily: "Inter_400Regular" }}>
                      {course.enrolledCount} students enrolled
                    </Text>
                  </View>
                  {selectedCourse === course.id && (
                    <Ionicons name="checkmark-circle" size={22} color={colors.primary} />
                  )}
                </Pressable>
              ))}
            </Card>

            <Card>
              <Text style={{ fontSize: 15, fontWeight: "700", color: colors.foreground, fontFamily: "Inter_700Bold", marginBottom: 14 }}>
                Date & Time
              </Text>
              <InputField
                label="Date"
                placeholder="YYYY-MM-DD"
                value={date}
                onChangeText={setDate}
                icon={<Ionicons name="calendar-outline" size={16} color={colors.mutedForeground} />}
              />
              <InputField
                label="Start Time"
                placeholder="HH:mm"
                value={startTime}
                onChangeText={setStartTime}
                icon={<Ionicons name="time-outline" size={16} color={colors.mutedForeground} />}
              />
              <InputField
                label="End Time"
                placeholder="HH:mm"
                value={endTime}
                onChangeText={setEndTime}
                icon={<Ionicons name="time-outline" size={16} color={colors.mutedForeground} />}
              />
            </Card>

            <Card>
              <Text style={{ fontSize: 15, fontWeight: "700", color: colors.foreground, fontFamily: "Inter_700Bold", marginBottom: 14 }}>
                Attendance Type
              </Text>
              <View style={{ flexDirection: "row", gap: 10 }}>
                {TYPE_OPTIONS.map((opt) => (
                  <Pressable
                    key={opt.key}
                    onPress={() => setType(opt.key)}
                    style={[
                      styles.typeBtn,
                      {
                        backgroundColor: type === opt.key ? opt.bg : colors.muted,
                        borderWidth: type === opt.key ? 1.5 : 0,
                        borderColor: opt.color,
                        flex: 1,
                      },
                    ]}
                  >
                    <Ionicons name={opt.icon as any} size={20} color={type === opt.key ? opt.color : colors.mutedForeground} />
                    <Text style={{ fontSize: 11, fontFamily: "Inter_600SemiBold", color: type === opt.key ? opt.color : colors.mutedForeground, textAlign: "center" }}>
                      {opt.label}
                    </Text>
                  </Pressable>
                ))}
              </View>
            </Card>

            {error ? (
              <Text style={{ color: colors.destructive, fontFamily: "Inter_500Medium" }}>
                {error}
              </Text>
            ) : null}

            <Button
              title="Create Session"
              onPress={handleCreate}
              loading={isLoading}
              disabled={!selectedCourse}
              size="lg"
            />
          </>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  courseOption: {
    flexDirection: "row",
    alignItems: "center",
    padding: 12,
    borderRadius: 12,
    marginBottom: 8,
  },
  typeBtn: {
    alignItems: "center",
    gap: 6,
    padding: 12,
    borderRadius: 12,
  },
});
