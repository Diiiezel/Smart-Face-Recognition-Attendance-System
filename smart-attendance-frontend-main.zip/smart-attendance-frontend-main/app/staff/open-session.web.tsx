import { Button, Card } from "@/components/UI";
import { ScreenHeader } from "@/components/ScreenHeader";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { buildFutureSessionDateTimes } from "@/utils/dateTime";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import React, { useState } from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

function WebDateTimeInput({
  label,
  type,
  value,
  onChange,
  icon,
}: {
  label: string;
  type: "date" | "time";
  value: string;
  onChange: (value: string) => void;
  icon: React.ReactNode;
}) {
  const colors = useColors();

  return (
    <View style={styles.webFieldStack}>
      <Text style={[styles.webFieldLabel, { color: colors.foreground }]}>{label}</Text>
      <View style={[styles.webInputShell, { backgroundColor: colors.card, borderColor: colors.border }]}>
        {icon}
        {React.createElement("input", {
          type,
          value,
          onChange: (event: React.ChangeEvent<HTMLInputElement>) => onChange(event.target.value),
          style: {
            border: "none",
            outline: "none",
            flex: 1,
            minWidth: 0,
            background: "transparent",
            color: colors.foreground,
            fontFamily: "Inter_400Regular",
            fontSize: 15,
          },
        })}
      </View>
    </View>
  );
}

function sessionAudienceLabel(session: { levelLabels?: string[]; levels?: string[] }) {
  const labels = session.levelLabels?.length
    ? session.levelLabels
    : session.levels?.map((level) => `Year ${level}`);

  return labels?.length ? labels.join(", ") : "";
}

export default function OpenSession() {
  const colors = useColors();
  const { sessions, openSession, closeSession, updateSession, deleteSession, isLoading } = useApp();
  const [selectedSession, setSelectedSession] = useState<string | null>(null);
  const [editingSessionId, setEditingSessionId] = useState<string | null>(null);
  const [editDate, setEditDate] = useState("");
  const [editStartTime, setEditStartTime] = useState("");
  const [editEndTime, setEditEndTime] = useState("");
  const [editType, setEditType] = useState<"face" | "qr" | "both">("face");
  const [error, setError] = useState("");
  const session = sessions.find((item) => item.id === selectedSession);
  const openSessions = sessions.filter((item) => item.status === "open");
  const scheduledSessions = sessions.filter((item) => item.status === "scheduled");
  const typeOptions = [
    { key: "face" as const, label: "Face", icon: "scan" },
    { key: "qr" as const, label: "QR", icon: "qr-code" },
    { key: "both" as const, label: "Both", icon: "apps" },
  ];

  const beginEditScheduledSession = (scheduledSession: typeof sessions[number]) => {
    setError("");
    setSelectedSession(scheduledSession.id);
    setEditingSessionId(scheduledSession.id);
    setEditDate(scheduledSession.date === "Not scheduled" ? "" : scheduledSession.date);
    setEditStartTime(scheduledSession.startTime === "--" ? "" : scheduledSession.startTime);
    setEditEndTime(scheduledSession.endTime === "--" ? "" : scheduledSession.endTime);
    setEditType(scheduledSession.type);
  };

  const handleSaveScheduledSession = async (scheduledSession: typeof sessions[number]) => {
    const dateTimes = buildFutureSessionDateTimes(editDate, editStartTime, editEndTime);

    if (!dateTimes) {
      setError("Please choose a valid future session date and time.");
      return;
    }

    try {
      setError("");
      await updateSession(scheduledSession.id, {
        method: editType,
        startsAt: dateTimes.startsAt,
        endsAt: dateTimes.endsAt,
      });
      setEditingSessionId(null);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to update session.");
    }
  };

  const performDeleteScheduledSession = async (sessionId: string) => {
    setError("");
    try {
      await deleteSession(sessionId);
      if (selectedSession === sessionId) setSelectedSession(null);
      if (editingSessionId === sessionId) setEditingSessionId(null);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to delete session.");
    }
  };

  const handleDeleteScheduledSession = (sessionId: string) => {
    const confirmed =
      typeof globalThis.confirm === "function"
        ? globalThis.confirm("Delete this scheduled session?")
        : true;
    if (confirmed) void performDeleteScheduledSession(sessionId);
  };

  const handleOpen = async (sessionId: string, routeMode: "face" | "qr") => {
    try {
      setError("");
      await openSession(sessionId);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      router.push(`/staff/${routeMode}-scan?sessionId=${sessionId}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to open session.");
    }
  };

  const performCloseLiveSession = async (sessionId: string) => {
    setError("");
    try {
      await closeSession(sessionId);
      if (selectedSession === sessionId) setSelectedSession(null);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to close session.");
    }
  };

  const handleCloseLiveSession = (sessionId: string) => {
    const confirmed =
      typeof globalThis.confirm === "function"
        ? globalThis.confirm("Are you sure you want to close this session?")
        : true;
    if (confirmed) void performCloseLiveSession(sessionId);
  };

  return (
    <View style={[styles.page, { backgroundColor: colors.background }]}>
      <ScreenHeader title="Open Session" showBack subtitle="Start taking attendance" />
      <ScrollView contentContainerStyle={styles.shell} showsVerticalScrollIndicator={false}>
        {openSessions.length > 0 ? (
          <View style={styles.sectionStack}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Live Sessions</Text>
            {openSessions.map((item) => (
              <Card key={item.id} style={styles.liveCard}>
                  <View style={styles.liveHeader}>
                  <View style={styles.liveStatus}>
                    <View style={[styles.liveDot, { backgroundColor: colors.success }]} />
                    <Text style={[styles.liveLabel, { color: colors.success }]}>LIVE</Text>
                  </View>
                  <View style={styles.liveActions}>
                    <Button title="Close Session" onPress={() => handleCloseLiveSession(item.id)} variant="danger" size="sm" fullWidth={false} />
                  </View>
                </View>
                <Text style={[styles.sessionName, { color: colors.foreground }]}>{item.courseName}</Text>
                <Text style={[styles.sessionMeta, { color: colors.mutedForeground }]}>
                  {item.courseCode} · {item.startTime} - {item.endTime}
                </Text>
                {sessionAudienceLabel(item) ? (
                  <Text style={[styles.sessionMeta, { color: colors.mutedForeground }]}>{sessionAudienceLabel(item)}</Text>
                ) : null}
                <View style={styles.liveFooter}>
                  <Text style={[styles.presentText, { color: colors.foreground }]}>
                    {item.presentCount}/{item.totalCount} students present
                  </Text>
                  <View style={styles.scanActions}>
                    {(item.type === "face" || item.type === "both") && (
                      <Pressable style={[styles.scanBtn, { backgroundColor: colors.primary }]} onPress={() => router.push(`/staff/face-scan?sessionId=${item.id}`)}>
                        <Ionicons name="scan" size={16} color={colors.primaryForeground} />
                        <Text style={[styles.scanText, { color: colors.primaryForeground }]}>Face</Text>
                      </Pressable>
                    )}
                    {(item.type === "qr" || item.type === "both") && (
                      <Pressable style={[styles.scanBtn, { backgroundColor: colors.accent }]} onPress={() => router.push(`/staff/qr-scan?sessionId=${item.id}`)}>
                        <Ionicons name="qr-code" size={16} color={colors.accentForeground} />
                        <Text style={[styles.scanText, { color: colors.accentForeground }]}>QR</Text>
                      </Pressable>
                    )}
                  </View>
                </View>
              </Card>
            ))}
          </View>
        ) : null}

        <View style={styles.layout}>
          <Card style={styles.scheduledPanel}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Scheduled Sessions</Text>
            {scheduledSessions.length === 0 ? (
              <View style={styles.emptyState}>
                <Ionicons name="calendar-outline" size={36} color={colors.mutedForeground} />
                <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>No scheduled sessions</Text>
                <Button title="Create Session" onPress={() => router.push("/staff/create-session")} variant="outline" size="sm" fullWidth={false} />
              </View>
            ) : (
              <View style={styles.sessionList}>
                {scheduledSessions.map((item) => {
                  const active = selectedSession === item.id;
                  return (
                    <View key={item.id} style={styles.sessionItem}>
                      <Pressable
                        onPress={() => setSelectedSession(active ? null : item.id)}
                        style={[
                          styles.sessionRow,
                          { backgroundColor: active ? colors.secondary : colors.background, borderColor: active ? colors.primary : colors.border },
                        ]}
                      >
                        <View style={styles.sessionMain}>
                        <Text style={[styles.rowTitle, { color: colors.foreground }]}>{item.courseName}</Text>
                        <Text style={[styles.sessionMeta, { color: colors.mutedForeground }]}>
                          {item.courseCode} · {item.date} · {item.startTime}-{item.endTime}
                        </Text>
                        {sessionAudienceLabel(item) ? (
                          <Text style={[styles.sessionMeta, { color: colors.mutedForeground }]}>{sessionAudienceLabel(item)}</Text>
                        ) : null}
                        </View>
                       <View style={styles.rowActions}>
                         <Button title="Edit" onPress={() => beginEditScheduledSession(item)} variant="outline" size="sm" fullWidth={false} />
                         <Button title="Delete" onPress={() => handleDeleteScheduledSession(item.id)} variant="danger" size="sm" fullWidth={false} />
                         <Ionicons name={active ? "checkmark-circle" : "ellipse-outline"} size={22} color={active ? colors.primary : colors.mutedForeground} />
                       </View>
                      </Pressable>
                      {editingSessionId === item.id ? (
                      <View style={[styles.editPanel, { borderColor: colors.border }]}>
                        <WebDateTimeInput label="Date" type="date" value={editDate} onChange={setEditDate} icon={<Ionicons name="calendar-outline" size={16} color={colors.mutedForeground} />} />
                        <WebDateTimeInput label="Start Time" type="time" value={editStartTime} onChange={setEditStartTime} icon={<Ionicons name="time-outline" size={16} color={colors.mutedForeground} />} />
                        <WebDateTimeInput label="End Time" type="time" value={editEndTime} onChange={setEditEndTime} icon={<Ionicons name="time-outline" size={16} color={colors.mutedForeground} />} />
                        <View style={styles.methodRow}>
                          {typeOptions.map((option) => {
                            const methodActive = editType === option.key;
                            return (
                              <Pressable
                                key={option.key}
                                onPress={() => setEditType(option.key)}
                                style={[
                                  styles.methodBtn,
                                  { backgroundColor: methodActive ? colors.primary : colors.card, borderColor: methodActive ? colors.primary : colors.border },
                                ]}
                              >
                                <Ionicons name={option.icon as any} size={16} color={methodActive ? colors.primaryForeground : colors.mutedForeground} />
                                <Text style={[styles.methodText, { color: methodActive ? colors.primaryForeground : colors.foreground }]}>{option.label}</Text>
                              </Pressable>
                            );
                          })}
                        </View>
                        <View style={styles.editActions}>
                          <Button title="Save" onPress={() => handleSaveScheduledSession(item)} loading={isLoading} size="md" fullWidth={false} />
                          <Button title="Cancel" onPress={() => setEditingSessionId(null)} variant="outline" size="md" fullWidth={false} />
                        </View>
                      </View>
                      ) : null}
                    </View>
                  );
                })}
              </View>
            )}
          </Card>

          <Card style={styles.modePanel}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Choose Attendance Mode</Text>
            {selectedSession && !openSessions.find((item) => item.id === selectedSession) && session ? (
              <View style={styles.modeGrid}>
                {(session.type === "face" || session.type === "both") && (
                  <Pressable onPress={() => handleOpen(session.id, "face")} style={[styles.modeBtn, { backgroundColor: colors.primary }]} disabled={isLoading}>
                    <Ionicons name="scan" size={30} color={colors.primaryForeground} />
                    <Text style={[styles.modeTitle, { color: colors.primaryForeground }]}>Face Recognition</Text>
                  </Pressable>
                )}
                {(session.type === "qr" || session.type === "both") && (
                  <Pressable onPress={() => handleOpen(session.id, "qr")} style={[styles.modeBtn, { backgroundColor: colors.accent }]} disabled={isLoading}>
                    <Ionicons name="qr-code" size={30} color={colors.accentForeground} />
                    <Text style={[styles.modeTitle, { color: colors.accentForeground }]}>QR Code</Text>
                  </Pressable>
                )}
              </View>
            ) : (
              <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>Select a scheduled session to open attendance capture.</Text>
            )}
            {error ? <Text style={[styles.errorText, { color: colors.destructive }]}>{error}</Text> : null}
          </Card>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  editActions: {
    flexDirection: "row",
    gap: 10,
  },
  editPanel: {
    borderTopWidth: 1,
    gap: 14,
    paddingTop: 16,
  },
  emptyState: {
    alignItems: "center",
    gap: 10,
    paddingVertical: 32,
  },
  emptyText: {
    fontFamily: "Inter_500Medium",
    fontSize: 14,
  },
  errorText: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 13,
  },
  layout: {
    flexDirection: "row",
    gap: 18,
  },
  liveActions: {
    flexDirection: "row",
    gap: 8,
  },
  liveCard: {
    borderLeftColor: "#10B981",
    borderLeftWidth: 4,
    gap: 12,
  },
  liveDot: {
    borderRadius: 4,
    height: 8,
    width: 8,
  },
  liveFooter: {
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 12,
  },
  liveHeader: {
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 12,
  },
  liveLabel: {
    fontFamily: "Inter_700Bold",
    fontSize: 12,
    letterSpacing: 0.8,
  },
  liveStatus: {
    alignItems: "center",
    flexDirection: "row",
    gap: 8,
  },
  methodBtn: {
    alignItems: "center",
    borderRadius: 12,
    borderWidth: 1,
    flex: 1,
    flexDirection: "row",
    gap: 7,
    justifyContent: "center",
    padding: 11,
  },
  methodRow: {
    flexDirection: "row",
    gap: 8,
  },
  methodText: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 12,
  },
  modeBtn: {
    alignItems: "center",
    borderRadius: 16,
    flex: 1,
    gap: 10,
    minHeight: 130,
    justifyContent: "center",
    padding: 20,
  },
  modeGrid: {
    flexDirection: "row",
    gap: 12,
  },
  modePanel: {
    flex: 0.8,
    gap: 16,
    minWidth: 340,
  },
  modeTitle: {
    fontFamily: "Inter_700Bold",
    fontSize: 14,
  },
  page: {
    flex: 1,
  },
  presentText: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 14,
  },
  rowTitle: {
    fontFamily: "Inter_700Bold",
    fontSize: 15,
  },
  rowActions: {
    alignItems: "center",
    flexDirection: "row",
    gap: 8,
  },
  scanActions: {
    flexDirection: "row",
    gap: 8,
  },
  scanBtn: {
    alignItems: "center",
    borderRadius: 12,
    flexDirection: "row",
    gap: 7,
    paddingHorizontal: 12,
    paddingVertical: 9,
  },
  scanText: {
    fontFamily: "Inter_700Bold",
    fontSize: 12,
  },
  scheduledPanel: {
    flex: 1,
    gap: 16,
    minWidth: 520,
  },
  sectionStack: {
    gap: 12,
  },
  sectionTitle: {
    fontFamily: "Inter_700Bold",
    fontSize: 18,
  },
  sessionList: {
    gap: 10,
  },
  sessionItem: {
    gap: 10,
  },
  sessionMain: {
    flex: 1,
    gap: 4,
  },
  sessionMeta: {
    fontFamily: "Inter_400Regular",
    fontSize: 12,
  },
  sessionName: {
    fontFamily: "Inter_700Bold",
    fontSize: 21,
    letterSpacing: -0.3,
  },
  sessionRow: {
    alignItems: "center",
    borderRadius: 14,
    borderWidth: 1,
    flexDirection: "row",
    gap: 12,
    padding: 14,
  },
  shell: {
    alignSelf: "center",
    gap: 18,
    maxWidth: 1180,
    padding: 28,
    width: "100%",
  },
  webFieldLabel: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 13,
  },
  webFieldStack: {
    gap: 8,
  },
  webInputShell: {
    alignItems: "center",
    borderRadius: 14,
    borderWidth: 1,
    flexDirection: "row",
    gap: 10,
    minHeight: 50,
    paddingHorizontal: 14,
  },
});
