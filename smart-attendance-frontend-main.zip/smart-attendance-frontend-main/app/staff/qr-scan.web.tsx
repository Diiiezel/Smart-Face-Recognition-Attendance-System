import { Badge, Button, Card } from "@/components/UI";
import { ScreenHeader } from "@/components/ScreenHeader";
import { useApp, type SessionReportStudent } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { parseStudentQrPayload } from "@/utils/qr";
import { Ionicons } from "@expo/vector-icons";
import { CameraView, useCameraPermissions, type BarcodeScanningResult } from "expo-camera";
import * as Haptics from "expo-haptics";
import jsQR from "jsqr";
import { useLocalSearchParams } from "expo-router";
import React, { useEffect, useMemo, useRef, useState } from "react";
import { Platform, ScrollView, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const SCAN_INTERVAL_MS = 700;
const QR_COOLDOWN_MS = 2000;

type ToastState = {
  tone: "success" | "warning" | "error";
  message: string;
} | null;

type ScannerState = "active" | "processing" | "success" | "duplicate" | "invalid" | "error";

export default function QRScan() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { sessions, loadSessionReport, markQrAttendance, isLoading } = useApp();
  const params = useLocalSearchParams<{ sessionId?: string }>();
  const [cameraPermission, requestCameraPermission] = useCameraPermissions();
  const session = sessions.find((s) => s.id === params.sessionId) || sessions[0];

  const [scanned, setScanned] = useState<SessionReportStudent[]>([]);
  const [currentScan, setCurrentScan] = useState<SessionReportStudent | null>(null);
  const [error, setError] = useState("");
  const [toast, setToast] = useState<ToastState>(null);
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraReady, setCameraReady] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [scannerState, setScannerState] = useState<ScannerState>("active");
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const scanTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const toastTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const scanCooldownRef = useRef<Record<string, number>>({});
  const isProcessingScanRef = useRef(false);
  const scannedRef = useRef<SessionReportStudent[]>([]);

  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  const showToast = (nextToast: ToastState) => {
    if (toastTimeoutRef.current) {
      clearTimeout(toastTimeoutRef.current);
    }

    setToast(nextToast);

    if (nextToast) {
      toastTimeoutRef.current = setTimeout(() => {
        setToast(null);
      }, 2600);
    }
  };

  const clearScheduledScan = () => {
    if (scanTimeoutRef.current) {
      clearTimeout(scanTimeoutRef.current);
      scanTimeoutRef.current = null;
    }
  };

  const refreshScanned = async () => {
    if (!session?.id) return;
    const report = await loadSessionReport(session.id);
    const presentStudents = report.students.filter((student) => student.status === "present");
    scannedRef.current = presentStudents;
    setScanned(presentStudents);
  };

  const stopCamera = () => {
    clearScheduledScan();
    streamRef.current?.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
    setCameraActive(false);
    setCameraReady(false);
    setIsScanning(false);
    isProcessingScanRef.current = false;
    setScannerState("active");
    setError("");
  };

  useEffect(() => {
    if (!session?.id) return;
    void refreshScanned();
  }, [loadSessionReport, session?.id]);

  useEffect(() => {
    return () => {
      clearScheduledScan();
      if (toastTimeoutRef.current) {
        clearTimeout(toastTimeoutRef.current);
      }
      streamRef.current?.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    };
  }, []);

  const getScanErrorDetails = (scanError: unknown) => {
    const rawMessage =
      scanError instanceof Error ? scanError.message : "Unable to mark attendance. Please try again.";
    const lowerMessage = rawMessage.toLowerCase();

    if (/already|duplicate|conflict|marked present/.test(lowerMessage)) {
      return {
        state: "duplicate" as const,
        tone: "warning" as const,
        message: "This student is already marked present for this session.",
      };
    }

    if (/invalid qr|payload|json|format|student account|incomplete|qr code/.test(lowerMessage)) {
      return {
        state: "invalid" as const,
        tone: "warning" as const,
        message: "Please scan a student QR code from this app.",
      };
    }

    return {
      state: "error" as const,
      tone: "error" as const,
      message: "Unable to mark attendance. Please try again.",
    };
  };

  const handleScanResult = async (rawPayload: string) => {
    if (!session?.id || isProcessingScanRef.current) {
      return;
    }

    const now = Date.now();
    const lastSeenAt = scanCooldownRef.current[rawPayload] ?? 0;
    if (now - lastSeenAt < QR_COOLDOWN_MS) {
      return;
    }

    scanCooldownRef.current[rawPayload] = now;
    setError("");
    setScannerState("processing");
    isProcessingScanRef.current = true;
    setIsScanning(true);

    try {
      const parsedPayload = parseStudentQrPayload(rawPayload);
      const alreadyScanned = scannedRef.current.some(
        (student) => student.universityId === parsedPayload.universityCode,
      );

      if (alreadyScanned) {
        throw new Error("Attendance already recorded for this student in this session.");
      }

      const student = await markQrAttendance(session.id, rawPayload);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setCurrentScan(student);
      setScannerState("success");
      showToast({
        tone: "success",
        message: "Attendance marked successfully",
      });
      await refreshScanned();
    } catch (scanError) {
      const { state, tone, message } = getScanErrorDetails(scanError);
      setScannerState(state);
      setError(message);
      showToast({
        tone,
        message,
      });
    } finally {
      isProcessingScanRef.current = false;
      setIsScanning(false);
    }
  };

  const scanCurrentFrame = async () => {
    if (Platform.OS !== "web" || !videoRef.current || !cameraActive || !cameraReady || isLoading) {
      scheduleNextScan();
      return;
    }

    const video = videoRef.current;
    const canvas = document.createElement("canvas");
    const width = video.videoWidth || 720;
    const height = video.videoHeight || 720;
    canvas.width = width;
    canvas.height = height;
    const context = canvas.getContext("2d", { willReadFrequently: true });

    if (!context) {
      setError("Unable to read camera frames for QR scanning.");
      setScannerState("error");
      scheduleNextScan();
      return;
    }

    context.drawImage(video, 0, 0, width, height);
    const imageData = context.getImageData(0, 0, width, height);
    const decoded = jsQR(imageData.data, width, height, {
      inversionAttempts: "attemptBoth",
    });

    if (decoded?.data) {
      await handleScanResult(decoded.data);
    }

    scheduleNextScan();
  };

  const scheduleNextScan = () => {
    clearScheduledScan();

    if (Platform.OS !== "web" || !cameraActive) {
      return;
    }

    scanTimeoutRef.current = setTimeout(() => {
      void scanCurrentFrame();
    }, SCAN_INTERVAL_MS);
  };

  const startCamera = async () => {
    if (Platform.OS !== "web") {
      setError("");
      setScannerState("active");
      const permission = cameraPermission?.granted
        ? cameraPermission
        : await requestCameraPermission();

      if (!permission.granted) {
        const message = "Camera access is required to scan student QR codes.";
        setError(message);
        showToast({
          tone: "error",
          message,
        });
        return;
      }

      setCameraActive(true);
      return;
    }

    try {
      setError("");
      setScannerState("active");
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: "environment",
          width: { ideal: 960 },
          height: { ideal: 960 },
        },
        audio: false,
      });
      streamRef.current?.getTracks().forEach((track) => track.stop());
      streamRef.current = stream;
      setCameraActive(true);
    } catch {
      const message = "Unable to access the camera. Please allow permission and try again.";
      setError(message);
      showToast({
        tone: "error",
        message,
      });
    }
  };

  useEffect(() => {
    void startCamera();
  }, []);

  const handleNativeBarcodeScanned = (result: BarcodeScanningResult) => {
    if (!cameraActive || !cameraReady || isProcessingScanRef.current || isLoading || !result.data) {
      return;
    }

    void handleScanResult(result.data);
  };

  useEffect(() => {
    if (Platform.OS !== "web" || !cameraActive || !videoRef.current || !streamRef.current) {
      return;
    }

    const video = videoRef.current;
    video.srcObject = streamRef.current;

    const handleLoadedMetadata = () => {
      setCameraReady(true);
    };

    video.addEventListener("loadedmetadata", handleLoadedMetadata);

    void video.play().catch(() => {
      setError("Camera preview could not start.");
      setCameraReady(false);
    });

    return () => {
      video.removeEventListener("loadedmetadata", handleLoadedMetadata);
    };
  }, [cameraActive]);

  useEffect(() => {
    if (!cameraActive || !cameraReady || isLoading || isScanning) {
      clearScheduledScan();
      return;
    }

    scheduleNextScan();

    return () => {
      clearScheduledScan();
    };
  }, [cameraActive, cameraReady, isLoading, isScanning]);

  const scannerStatus = useMemo(() => {
    if (!cameraActive) {
      return "Camera closed";
    }
    if (isScanning || isLoading) {
      return "Processing attendance...";
    }
    if (scannerState === "success") {
      return "Attendance marked successfully";
    }
    if (scannerState === "duplicate") {
      return "Student already marked present";
    }
    if (scannerState === "invalid") {
      return "Invalid student QR code";
    }
    if (scannerState === "error" || error) {
      return "Unable to mark attendance. Please try again.";
    }
    return "Scanner active";
  }, [cameraActive, error, isLoading, isScanning, scannerState]);

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <ScreenHeader title="QR Scanner" showBack subtitle={session ? `${session.courseName} · ${session.courseCode}` : "Scanning"} dark />
      <ScrollView contentContainerStyle={[styles.webContent, { paddingBottom: bottomPad + 32 }]} showsVerticalScrollIndicator={false}>
        <View style={styles.cameraArea}>
          <View style={styles.qrFrame}>
            {Platform.OS === "web" && cameraActive ? (
              <View style={styles.videoFrame}>
                <video
                  ref={videoRef}
                  muted
                  playsInline
                  autoPlay
                  style={styles.webVideo as never}
                />
                <View style={styles.videoOverlay}>
                  <View style={[styles.qrCorner, styles.cornerTopLeft, isScanning ? styles.cornerDetected : null]} />
                  <View style={[styles.qrCorner, styles.cornerTopRight, isScanning ? styles.cornerDetected : null]} />
                  <View style={[styles.qrCorner, styles.cornerBottomLeft, isScanning ? styles.cornerDetected : null]} />
                  <View style={[styles.qrCorner, styles.cornerBottomRight, isScanning ? styles.cornerDetected : null]} />
                </View>
              </View>
            ) : Platform.OS !== "web" && cameraActive ? (
              <View style={styles.videoFrame}>
                <CameraView
                  style={StyleSheet.absoluteFill}
                  facing="back"
                  active={cameraActive}
                  barcodeScannerSettings={{ barcodeTypes: ["qr"] }}
                  onBarcodeScanned={
                    cameraReady && !isScanning && !isLoading
                      ? handleNativeBarcodeScanned
                      : undefined
                  }
                  onCameraReady={() => setCameraReady(true)}
                  onMountError={(event) => {
                    setCameraReady(false);
                    setError(event.message || "Camera preview could not start.");
                  }}
                />
                <View style={styles.videoOverlay} pointerEvents="none">
                  <View style={[styles.qrCorner, styles.cornerTopLeft, isScanning ? styles.cornerDetected : null]} />
                  <View style={[styles.qrCorner, styles.cornerTopRight, isScanning ? styles.cornerDetected : null]} />
                  <View style={[styles.qrCorner, styles.cornerBottomLeft, isScanning ? styles.cornerDetected : null]} />
                  <View style={[styles.qrCorner, styles.cornerBottomRight, isScanning ? styles.cornerDetected : null]} />
                </View>
              </View>
            ) : (
              <>
                <View style={[styles.qrCorner, styles.cornerTopLeft]} />
                <View style={[styles.qrCorner, styles.cornerTopRight]} />
                <View style={[styles.qrCorner, styles.cornerBottomLeft]} />
                <View style={[styles.qrCorner, styles.cornerBottomRight]} />
                <Ionicons name="qr-code" size={72} color="rgba(255,255,255,0.2)" />
              </>
            )}
            <Text style={styles.helperText}>
              {cameraActive
                ? "Align the student's QR code inside the frame"
                : "Camera closed. Tap Open Camera to resume scanning."}
            </Text>
          </View>
          <View style={styles.sessionInfo}>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
              <View
                style={{
                  width: 8,
                  height: 8,
                  borderRadius: 4,
                  backgroundColor: error ? "#EF4444" : "#6366F1",
                }}
              />
              <Text style={{ color: "#FFF", fontSize: 12, fontFamily: "Inter_600SemiBold" }}>{scannerStatus}</Text>
            </View>
            <Text style={{ color: "rgba(255,255,255,0.7)", fontSize: 12, fontFamily: "Inter_400Regular" }}>
              {scanned.length}/{session?.totalCount ?? 0} scanned
            </Text>
          </View>
        </View>

        <View style={{ gap: 12 }}>
          {toast ? (
            <Card
              style={{
                backgroundColor:
                  toast.tone === "success" ? "#EEF2FF" : toast.tone === "warning" ? "#FFFBEB" : "#FEF2F2",
                borderColor:
                  toast.tone === "success" ? "#C7D2FE" : toast.tone === "warning" ? "#FDE68A" : "#FECACA",
                borderWidth: 1,
              }}
            >
              <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
                <Ionicons
                  name={toast.tone === "success" ? "checkmark-circle" : toast.tone === "warning" ? "warning" : "alert-circle"}
                  size={18}
                  color={toast.tone === "success" ? "#4338CA" : toast.tone === "warning" ? "#B45309" : "#B91C1C"}
                />
                <Text
                  style={{
                    flex: 1,
                    color: toast.tone === "success" ? "#3730A3" : toast.tone === "warning" ? "#92400E" : "#B91C1C",
                    fontFamily: "Inter_600SemiBold",
                    fontSize: 13,
                  }}
                >
                  {toast.message}
                </Text>
              </View>
            </Card>
          ) : null}

          {error ? (
            <Card style={{ backgroundColor: "#FEF2F2", borderColor: "#FECACA", borderWidth: 1 }}>
              <Text style={{ color: "#B91C1C", fontFamily: "Inter_500Medium" }}>{error}</Text>
            </Card>
          ) : null}

          <View style={styles.actionsRow}>
            <Button
              title={cameraActive ? "Close Camera" : "Open Camera"}
              onPress={() => void (cameraActive ? Promise.resolve(stopCamera()) : startCamera())}
              variant={cameraActive ? "outline" : "primary"}
              fullWidth={false}
              style={{ minWidth: 150 }}
              disabled={isScanning || isLoading}
            />
          </View>
        </View>

        {currentScan && (
          <View>
            <Card style={{ backgroundColor: "#EEF2FF", borderWidth: 2, borderColor: "#A5B4FC" }}>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
                <View style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: "#6366F1", alignItems: "center", justifyContent: "center" }}>
                  <Ionicons name="checkmark" size={24} color="#FFF" />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontSize: 15, fontWeight: "700", color: "#3730A3", fontFamily: "Inter_700Bold" }}>
                    {currentScan.name}
                  </Text>
                  <Text style={{ fontSize: 12, color: "#4338CA", fontFamily: "Inter_400Regular" }}>
                    {currentScan.universityId} · QR verified
                  </Text>
                </View>
                <Badge label="Marked" variant="primary" />
              </View>
            </Card>
          </View>
        )}

        <View style={{ gap: 10 }}>
          <Text style={{ fontSize: 15, fontWeight: "700", color: colors.foreground, fontFamily: "Inter_700Bold" }}>
            Scanned ({scanned.length})
          </Text>
          {scanned.map((student) => (
            <Card key={student.id} style={{ padding: 12 }}>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
                <View style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: "#EEF2FF", alignItems: "center", justifyContent: "center" }}>
                  <Ionicons name="person" size={20} color="#6366F1" />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontSize: 14, fontWeight: "600", color: colors.foreground, fontFamily: "Inter_600SemiBold" }}>
                    {student.name}
                  </Text>
                  <Text style={{ fontSize: 12, color: colors.mutedForeground, fontFamily: "Inter_400Regular" }}>
                    {student.universityId}
                    {student.time ? ` · ${student.time}` : ""}
                  </Text>
                </View>
                <Badge label="Present" variant="success" />
              </View>
            </Card>
          ))}
          {scanned.length === 0 && (
            <View style={{ alignItems: "center", padding: 24, gap: 8 }}>
              <Ionicons name="qr-code-outline" size={36} color={colors.mutedForeground} />
              <Text style={{ color: colors.mutedForeground, fontFamily: "Inter_500Medium" }}>
                Waiting for student QR codes...
              </Text>
            </View>
          )}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  webContent: {
    alignSelf: "center",
    gap: 18,
    maxWidth: 1120,
    padding: 28,
    width: "100%",
  },
  cameraArea: {
    height: 420,
    backgroundColor: "#0F1B3C",
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
    overflow: "hidden",
    borderRadius: 28,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.08)",
  },
  qrFrame: {
    width: 280,
    height: 280,
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
  },
  videoFrame: {
    width: 280,
    height: 280,
    borderRadius: 24,
    overflow: "hidden",
    position: "relative",
    backgroundColor: "#0B1530",
  },
  webVideo: {
    width: "100%",
    height: "100%",
    objectFit: "cover",
  },
  videoOverlay: {
    ...StyleSheet.absoluteFillObject,
  },
  qrCorner: {
    position: "absolute",
    width: 32,
    height: 32,
    borderColor: "#6366F1",
  },
  cornerDetected: {
    borderColor: "#10B981",
  },
  cornerTopLeft: {
    top: 0,
    left: 0,
    borderTopWidth: 3,
    borderLeftWidth: 3,
  },
  cornerTopRight: {
    top: 0,
    right: 0,
    borderTopWidth: 3,
    borderRightWidth: 3,
  },
  cornerBottomLeft: {
    bottom: 0,
    left: 0,
    borderBottomWidth: 3,
    borderLeftWidth: 3,
  },
  cornerBottomRight: {
    bottom: 0,
    right: 0,
    borderBottomWidth: 3,
    borderRightWidth: 3,
  },
  helperText: {
    position: "absolute",
    bottom: 18,
    color: "rgba(255,255,255,0.65)",
    fontSize: 13,
    fontFamily: "Inter_500Medium",
    textAlign: "center",
  },
  sessionInfo: {
    position: "absolute",
    bottom: 18,
    left: 22,
    right: 22,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  actionsRow: {
    alignItems: "center",
  },
});
