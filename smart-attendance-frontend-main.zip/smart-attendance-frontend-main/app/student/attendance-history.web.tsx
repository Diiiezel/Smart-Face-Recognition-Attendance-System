import { Badge, Card } from "@/components/UI";
import { ScreenHeader } from "@/components/ScreenHeader";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { Ionicons } from "@expo/vector-icons";
import React, { useMemo, useState } from "react";
import { FlatList, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

export default function AttendanceHistory() {
  const colors = useColors();
  const { attendanceHistory } = useApp();
  const [filter, setFilter] = useState<"all" | "present" | "absent">("all");
  const [courseFilter, setCourseFilter] = useState("all");

  const courseOptions = useMemo(() => {
    const courseMap = new Map<string, string>();
    attendanceHistory.forEach((record) => {
      if (record.courseCode) {
        courseMap.set(record.courseCode, record.courseName || record.courseCode);
      }
    });
    return Array.from(courseMap, ([code, name]) => ({ code, name }));
  }, [attendanceHistory]);

  const filtered = attendanceHistory.filter(
    (record) =>
      (filter === "all" || record.status === filter) &&
      (courseFilter === "all" || record.courseCode === courseFilter),
  );
  const presentCount = attendanceHistory.filter((record) => record.status === "present").length;
  const absentCount = attendanceHistory.filter((record) => record.status === "absent").length;
  const rate = attendanceHistory.length > 0 ? Math.round((presentCount / attendanceHistory.length) * 100) : 0;
  const filters = [
    { key: "all" as const, label: "All" },
    { key: "present" as const, label: "Present" },
    { key: "absent" as const, label: "Absent" },
  ];

  return (
    <View style={[styles.page, { backgroundColor: colors.background }]}>
      <ScreenHeader title="Attendance History" showBack subtitle="Track your class participation" />
      <View style={styles.shell}>
        <View style={styles.summaryGrid}>
          <Card style={styles.heroCard}>
            <Text style={[styles.eyebrow, { color: colors.mutedForeground }]}>Overall attendance</Text>
            <Text style={[styles.heroMetric, { color: rate >= 75 ? colors.success : colors.destructive }]}>{rate}%</Text>
            <Text style={[styles.heroCopy, { color: colors.mutedForeground }]}>
              {presentCount} present out of {attendanceHistory.length} recorded classes.
            </Text>
          </Card>
          <Card style={styles.metricCard}>
            <Text style={[styles.metricLabel, { color: colors.mutedForeground }]}>Present</Text>
            <Text style={[styles.metricValue, { color: colors.success }]}>{presentCount}</Text>
          </Card>
          <Card style={styles.metricCard}>
            <Text style={[styles.metricLabel, { color: colors.mutedForeground }]}>Absent</Text>
            <Text style={[styles.metricValue, { color: colors.destructive }]}>{absentCount}</Text>
          </Card>
        </View>

        <Card style={styles.filtersPanel}>
          <View style={styles.filterGroup}>
            {filters.map((item) => {
              const active = filter === item.key;
              return (
                <Pressable
                  key={item.key}
                  onPress={() => setFilter(item.key)}
                  style={[
                    styles.filterButton,
                    { backgroundColor: active ? colors.primary : colors.card, borderColor: active ? colors.primary : colors.border },
                  ]}
                >
                  <Text style={[styles.filterText, { color: active ? colors.primaryForeground : colors.foreground }]}>
                    {item.label}
                  </Text>
                </Pressable>
              );
            })}
          </View>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.courseFilters}>
            {[{ code: "all", name: "All Courses" }, ...courseOptions].map((course) => {
              const active = courseFilter === course.code;
              return (
                <Pressable
                  key={course.code}
                  onPress={() => setCourseFilter(course.code)}
                  style={[
                    styles.courseFilter,
                    { backgroundColor: active ? colors.secondary : colors.card, borderColor: active ? colors.primary : colors.border },
                  ]}
                >
                  <Text style={[styles.courseFilterText, { color: active ? colors.primary : colors.foreground }]} numberOfLines={1}>
                    {course.name}
                  </Text>
                </Pressable>
              );
            })}
          </ScrollView>
        </Card>

        <FlatList
          data={filtered}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.list}
          renderItem={({ item }) => (
            <Card style={styles.recordCard}>
              <View style={styles.recordIconRow}>
                <View
                  style={[
                    styles.statusIcon,
                    { backgroundColor: item.status === "present" ? "#DCFCE7" : "#FEE2E2" },
                  ]}
                >
                  <Ionicons
                    name={item.status === "present" ? "checkmark-circle" : "close-circle"}
                    size={22}
                    color={item.status === "present" ? colors.success : colors.destructive}
                  />
                </View>
                <View style={styles.recordMain}>
                  <Text style={[styles.recordTitle, { color: colors.foreground }]}>{item.courseName}</Text>
                  <Text style={[styles.recordMeta, { color: colors.mutedForeground }]}>
                    {item.courseCode} · {item.date}
                    {item.time ? ` · ${item.time}` : ""}
                  </Text>
                </View>
                <Badge
                  label={item.status.charAt(0).toUpperCase() + item.status.slice(1)}
                  variant={item.status === "present" ? "success" : "danger"}
                />
              </View>
              <View style={[styles.progressTrack, { backgroundColor: colors.muted }]}>
                <View
                  style={[
                    styles.progressFill,
                    {
                      width: `${item.attendanceRate}%`,
                      backgroundColor: item.attendanceRate >= 75 ? colors.success : colors.destructive,
                    },
                  ]}
                />
              </View>
              <Text style={[styles.recordMeta, { color: colors.mutedForeground }]}>
                Course attendance rate: {item.attendanceRate}%
              </Text>
            </Card>
          )}
          ListEmptyComponent={
            <Card style={styles.emptyCard}>
              <Ionicons name="calendar-outline" size={40} color={colors.mutedForeground} />
              <Text style={[styles.emptyTitle, { color: colors.foreground }]}>No records found</Text>
            </Card>
          }
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  courseFilter: {
    borderRadius: 999,
    borderWidth: 1,
    maxWidth: 220,
    paddingHorizontal: 14,
    paddingVertical: 9,
  },
  courseFilterText: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 12,
  },
  courseFilters: {
    gap: 8,
  },
  emptyCard: {
    alignItems: "center",
    gap: 10,
    paddingVertical: 42,
  },
  emptyTitle: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 16,
  },
  eyebrow: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 12,
    letterSpacing: 0.7,
    textTransform: "uppercase",
  },
  filterButton: {
    borderRadius: 12,
    borderWidth: 1,
    paddingHorizontal: 18,
    paddingVertical: 10,
  },
  filterGroup: {
    flexDirection: "row",
    gap: 8,
  },
  filterText: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 13,
  },
  filtersPanel: {
    gap: 14,
  },
  heroCard: {
    flex: 2,
    gap: 6,
    minWidth: 360,
  },
  heroCopy: {
    fontFamily: "Inter_400Regular",
    fontSize: 14,
  },
  heroMetric: {
    fontFamily: "Inter_700Bold",
    fontSize: 52,
    letterSpacing: -1.2,
  },
  list: {
    gap: 12,
    paddingBottom: 36,
  },
  metricCard: {
    flex: 1,
    justifyContent: "center",
    minWidth: 180,
  },
  metricLabel: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 12,
    letterSpacing: 0.6,
    textTransform: "uppercase",
  },
  metricValue: {
    fontFamily: "Inter_700Bold",
    fontSize: 36,
    letterSpacing: -0.8,
    marginTop: 6,
  },
  page: {
    flex: 1,
  },
  progressFill: {
    borderRadius: 999,
    height: 8,
  },
  progressTrack: {
    borderRadius: 999,
    height: 8,
    overflow: "hidden",
  },
  recordCard: {
    gap: 12,
  },
  recordIconRow: {
    alignItems: "center",
    flexDirection: "row",
    gap: 14,
  },
  recordMain: {
    flex: 1,
    gap: 3,
  },
  recordMeta: {
    fontFamily: "Inter_400Regular",
    fontSize: 12,
  },
  recordTitle: {
    fontFamily: "Inter_700Bold",
    fontSize: 16,
  },
  shell: {
    alignSelf: "center",
    gap: 18,
    maxWidth: 1180,
    padding: 28,
    width: "100%",
  },
  statusIcon: {
    alignItems: "center",
    borderRadius: 14,
    height: 44,
    justifyContent: "center",
    width: 44,
  },
  summaryGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 16,
  },
});
