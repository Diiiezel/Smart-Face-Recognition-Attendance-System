import { Badge, Button, Card } from "@/components/UI";
import { ScreenHeader } from "@/components/ScreenHeader";
import { useApp, type Course } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { coursesService } from "@/services/coursesService";
import { Ionicons } from "@expo/vector-icons";
import React, { useEffect, useMemo, useState } from "react";
import { FlatList, Modal, Pressable, StyleSheet, Text, TextInput, View } from "react-native";

const COURSE_TINTS = [
  { bg: "#DBEAFE", fg: "#2563EB" },
  { bg: "#EEF2FF", fg: "#6366F1" },
  { bg: "#D1FAE5", fg: "#10B981" },
  { bg: "#FEF3C7", fg: "#F59E0B" },
];

function normalizeCourse(course: any): Course {
  const departments = Array.isArray(course.departments)
    ? course.departments.filter(Boolean)
    : String(course.department || course.semester || course.doctor?.major || "")
        .split(",")
        .map((item) => item.trim())
        .filter((item) => item === "CS" || item === "IS");
  const levels = Array.isArray(course.levels)
    ? course.levels.filter(Boolean)
    : course.level
      ? [course.level]
      : [];

  return {
    id: String(course.id),
    code: course.code,
    name: course.name,
    instructor: course.doctor?.name || "Doctor",
    department: course.department || departments.join(", ") || "General",
    level: levels.join(", ") || course.level || "N/A",
    departments,
    levels,
    enrolledCount: Number(course.enrollments_count || 0),
    schedule: course.semester || "TBD",
  };
}

function CourseCard({
  course,
  index,
  enrolled,
  onEnroll,
  isAdding,
}: {
  course: Course;
  index: number;
  enrolled: boolean;
  onEnroll?: () => void;
  isAdding?: boolean;
}) {
  const colors = useColors();
  const tint = COURSE_TINTS[index % COURSE_TINTS.length];

  return (
    <Card style={enrolled ? { ...styles.courseCard, borderColor: tint.fg } : styles.courseCard}>
      <View style={styles.courseTop}>
        <View style={[styles.courseIcon, { backgroundColor: tint.bg }]}>
          <Ionicons name="book" size={20} color={tint.fg} />
        </View>
        <View style={styles.courseIdentity}>
          <Text style={[styles.courseCode, { color: tint.fg }]}>{course.code}</Text>
          <Text style={[styles.courseName, { color: colors.foreground }]}>{course.name}</Text>
        </View>
        {enrolled ? <Badge label="Enrolled" variant="primary" /> : null}
      </View>
      <View style={styles.courseMetaGrid}>
        <View>
          <Text style={[styles.metaLabel, { color: colors.mutedForeground }]}>Instructor</Text>
          <Text style={[styles.metaValue, { color: colors.foreground }]}>{course.instructor}</Text>
        </View>
        <View>
          <Text style={[styles.metaLabel, { color: colors.mutedForeground }]}>Department</Text>
          <Text style={[styles.metaValue, { color: colors.foreground }]}>{course.department}</Text>
        </View>
        <View>
          <Text style={[styles.metaLabel, { color: colors.mutedForeground }]}>Level</Text>
          <Text style={[styles.metaValue, { color: colors.foreground }]}>{course.level}</Text>
        </View>
        <View>
          <Text style={[styles.metaLabel, { color: colors.mutedForeground }]}>Schedule</Text>
          <Text style={[styles.metaValue, { color: colors.foreground }]}>{course.schedule}</Text>
        </View>
      </View>
      {!enrolled && onEnroll ? (
        <Button title="Enroll" onPress={onEnroll} loading={isAdding} disabled={isAdding} fullWidth={false} />
      ) : null}
    </Card>
  );
}

export default function MyCourses() {
  const colors = useColors();
  const { courses, studentProfile, refreshData } = useApp();
  const [search, setSearch] = useState("");
  const [availableCourses, setAvailableCourses] = useState<Course[]>([]);
  const [showPicker, setShowPicker] = useState(false);
  const [isAdding, setIsAdding] = useState(false);

  useEffect(() => {
    void (async () => {
      const nextCourses = await coursesService.getStudentAvailableCourses();
      setAvailableCourses((nextCourses || []).map(normalizeCourse));
    })();
  }, [courses.length, studentProfile?.department, studentProfile?.level]);

  const enrolledCodes = useMemo(() => new Set(courses.map((course) => course.code)), [courses]);
  const filteredEnrolled = useMemo(
    () =>
      courses.filter(
        (course) =>
          course.name.toLowerCase().includes(search.toLowerCase()) ||
          course.code.toLowerCase().includes(search.toLowerCase()) ||
          course.instructor.toLowerCase().includes(search.toLowerCase()),
      ),
    [courses, search],
  );
  const remainingCourses = useMemo(
    () => availableCourses.filter((course) => !enrolledCodes.has(course.code)),
    [availableCourses, enrolledCodes],
  );
  const hasEnrolledCourses = courses.length > 0;
  const emptyAvailableTitle = hasEnrolledCourses
    ? "All matching courses selected"
    : "No available courses for your current level";
  const emptyAvailableMessage = hasEnrolledCourses
    ? "You have already enrolled in all available courses for your current level."
    : "Ask your doctor to create a course for your current level, then refresh this screen.";

  const handleEnroll = async (course: Course) => {
    setIsAdding(true);
    try {
      await coursesService.enrollStudent(course.code);
      await refreshData();
      const nextCourses = await coursesService.getStudentAvailableCourses();
      setAvailableCourses((nextCourses || []).map(normalizeCourse));
      setShowPicker(false);
    } finally {
      setIsAdding(false);
    }
  };

  return (
    <View style={[styles.page, { backgroundColor: colors.background }]}>
      <ScreenHeader title="My Courses" showBack subtitle={`${courses.length} enrolled courses`} />
      <View style={styles.shell}>
        <Card style={styles.toolbar}>
          <View style={styles.toolbarText}>
            <Text style={[styles.eyebrow, { color: colors.mutedForeground }]}>Student course plan</Text>
            <Text style={[styles.title, { color: colors.foreground }]}>Enrolled courses and available additions</Text>
          </View>
          <View style={[styles.searchBox, { borderColor: colors.border, backgroundColor: colors.card }]}>
            <Ionicons name="search-outline" size={18} color={colors.mutedForeground} />
            <TextInput
              style={[styles.searchInput, { color: colors.foreground }]}
              placeholder="Search courses..."
              placeholderTextColor={colors.mutedForeground}
              value={search}
              onChangeText={setSearch}
            />
          </View>
          <Button title="Add Course" onPress={() => setShowPicker(true)} fullWidth={false} />
        </Card>

        <FlatList
          data={filteredEnrolled}
          keyExtractor={(item) => item.id}
          numColumns={2}
          columnWrapperStyle={styles.gridRow}
          contentContainerStyle={styles.grid}
          renderItem={({ item, index }) => <CourseCard course={item} index={index} enrolled />}
          ListEmptyComponent={
            <Card style={styles.emptyCard}>
              <Ionicons name="book-outline" size={36} color={colors.mutedForeground} />
              <Text style={[styles.emptyTitle, { color: colors.foreground }]}>No enrolled courses yet</Text>
              <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
                Add courses available for your major and year.
              </Text>
            </Card>
          }
          showsVerticalScrollIndicator={false}
        />
      </View>

      <Modal visible={showPicker} transparent animationType="fade" onRequestClose={() => setShowPicker(false)}>
        <View style={styles.modalOverlay}>
          <View style={[styles.modalCard, { backgroundColor: colors.card }]}>
            <View style={styles.modalHeader}>
              <View>
                <Text style={[styles.modalTitle, { color: colors.foreground }]}>Available Courses</Text>
                <Text style={[styles.modalSubtitle, { color: colors.mutedForeground }]}>
                  Matching {studentProfile?.department || "your major"} · {studentProfile?.level || "your year"}
                </Text>
              </View>
              <Pressable onPress={() => setShowPicker(false)} style={[styles.closeButton, { backgroundColor: colors.muted }]}>
                <Ionicons name="close" size={18} color={colors.foreground} />
              </Pressable>
            </View>
            {remainingCourses.length === 0 ? (
              <View style={styles.emptyPicker}>
                <Ionicons name="checkmark-done-circle-outline" size={42} color={colors.mutedForeground} />
                <Text style={[styles.emptyTitle, { color: colors.foreground }]}>{emptyAvailableTitle}</Text>
                <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
                  {emptyAvailableMessage}
                </Text>
              </View>
            ) : (
              <FlatList
                data={remainingCourses}
                keyExtractor={(item) => `available-${item.id}`}
                numColumns={2}
                columnWrapperStyle={styles.gridRow}
                contentContainerStyle={styles.grid}
                renderItem={({ item, index }) => (
                  <CourseCard
                    course={item}
                    index={index}
                    enrolled={false}
                    onEnroll={() => void handleEnroll(item)}
                    isAdding={isAdding}
                  />
                )}
              />
            )}
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  closeButton: {
    alignItems: "center",
    borderRadius: 12,
    height: 38,
    justifyContent: "center",
    width: 38,
  },
  courseCard: {
    flex: 1,
    gap: 18,
    minWidth: 320,
  },
  courseCode: {
    fontFamily: "Inter_700Bold",
    fontSize: 13,
  },
  courseIcon: {
    alignItems: "center",
    borderRadius: 14,
    height: 46,
    justifyContent: "center",
    width: 46,
  },
  courseIdentity: {
    flex: 1,
    gap: 3,
  },
  courseMetaGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 18,
  },
  courseName: {
    fontFamily: "Inter_700Bold",
    fontSize: 18,
  },
  courseTop: {
    alignItems: "flex-start",
    flexDirection: "row",
    gap: 14,
  },
  emptyCard: {
    alignItems: "center",
    gap: 10,
    paddingVertical: 50,
  },
  emptyPicker: {
    alignItems: "center",
    gap: 10,
    paddingVertical: 44,
  },
  emptyText: {
    fontFamily: "Inter_400Regular",
    fontSize: 14,
    textAlign: "center",
  },
  emptyTitle: {
    fontFamily: "Inter_700Bold",
    fontSize: 18,
  },
  eyebrow: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 12,
    letterSpacing: 0.7,
    textTransform: "uppercase",
  },
  grid: {
    gap: 16,
    paddingBottom: 36,
  },
  gridRow: {
    gap: 16,
  },
  metaLabel: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 11,
    letterSpacing: 0.4,
    textTransform: "uppercase",
  },
  metaValue: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 13,
    marginTop: 4,
  },
  modalCard: {
    borderRadius: 24,
    gap: 18,
    maxHeight: "84%",
    maxWidth: 980,
    padding: 24,
    width: "88%",
  },
  modalHeader: {
    alignItems: "flex-start",
    flexDirection: "row",
    justifyContent: "space-between",
  },
  modalOverlay: {
    alignItems: "center",
    backgroundColor: "rgba(13, 27, 62, 0.42)",
    flex: 1,
    justifyContent: "center",
  },
  modalSubtitle: {
    fontFamily: "Inter_400Regular",
    fontSize: 13,
    marginTop: 3,
  },
  modalTitle: {
    fontFamily: "Inter_700Bold",
    fontSize: 24,
  },
  page: {
    flex: 1,
  },
  searchBox: {
    alignItems: "center",
    borderRadius: 14,
    borderWidth: 1,
    flexDirection: "row",
    gap: 10,
    minWidth: 280,
    paddingHorizontal: 14,
    paddingVertical: 12,
  },
  searchInput: {
    flex: 1,
    fontFamily: "Inter_400Regular",
    fontSize: 15,
    outlineStyle: "none",
  } as any,
  shell: {
    alignSelf: "center",
    gap: 18,
    maxWidth: 1180,
    padding: 28,
    width: "100%",
  },
  title: {
    fontFamily: "Inter_700Bold",
    fontSize: 24,
    letterSpacing: -0.3,
  },
  toolbar: {
    alignItems: "center",
    flexDirection: "row",
    gap: 18,
  },
  toolbarText: {
    flex: 1,
    gap: 4,
  },
});
