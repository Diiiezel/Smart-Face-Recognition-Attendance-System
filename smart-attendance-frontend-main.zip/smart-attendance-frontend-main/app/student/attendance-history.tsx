import { Badge, Card } from "@/components/UI";
import { ScreenHeader } from "@/components/ScreenHeader";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { Ionicons } from "@expo/vector-icons";
import React, { useMemo, useState } from "react";
import { FlatList, Platform, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

export default function AttendanceHistory() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { attendanceHistory } = useApp();
  const [filter, setFilter] = useState<"all" | "present" | "absent">("all");
  const [courseFilter, setCourseFilter] = useState("all");
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  const courseOptions = useMemo(() => {
    const courseMap = new Map<string, string>();
    attendanceHistory.forEach((record) => {
      if (record.courseCode) {
        courseMap.set(record.courseCode, record.courseName || record.courseCode);
      }
    });

    return Array.from(courseMap, ([code, name]) => ({ code, name }));
  }, [attendanceHistory]);

  const filtered = attendanceHistory.filter(
    (r) =>
      (filter === "all" || r.status === filter) &&
      (courseFilter === "all" || r.courseCode === courseFilter),
  );
  const presentCount = attendanceHistory.filter((r) => r.status === "present").length;
  const rate = attendanceHistory.length > 0 ? Math.round((presentCount / attendanceHistory.length) * 100) : 0;

  const FILTERS = [
    { key: "all", label: "All" },
    { key: "present", label: "Present" },
    { key: "absent", label: "Absent" },
  ] as const;

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <ScreenHeader title="Attendance History" showBack subtitle="Track your class participation" />

      <View style={styles.summaryRow}>
        <View style={[styles.summaryCard, { backgroundColor: "#D1FAE5" }]}>
          <Text style={[styles.summaryVal, { color: "#166534" }]}>{rate}%</Text>
          <Text style={[styles.summaryLabel, { color: "#166534" }]}>Overall Rate</Text>
        </View>
        <View style={[styles.summaryCard, { backgroundColor: "#DBEAFE" }]}>
          <Text style={[styles.summaryVal, { color: "#1E40AF" }]}>{presentCount}</Text>
          <Text style={[styles.summaryLabel, { color: "#1E40AF" }]}>Present</Text>
        </View>
        <View style={[styles.summaryCard, { backgroundColor: "#FEE2E2" }]}>
          <Text style={[styles.summaryVal, { color: "#991B1B" }]}>
            {attendanceHistory.filter((r) => r.status === "absent").length}
          </Text>
          <Text style={[styles.summaryLabel, { color: "#991B1B" }]}>Absent</Text>
        </View>
      </View>

      <View style={styles.filterRow}>
        {FILTERS.map((f) => (
          <Pressable
            key={f.key}
            onPress={() => setFilter(f.key)}
            style={[
              styles.filterBtn,
              filter === f.key
                ? { backgroundColor: colors.primary }
                : { backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border },
            ]}
          >
            <Text
              style={{ fontSize: 13, fontFamily: "Inter_600SemiBold", color: filter === f.key ? "#FFFFFF" : colors.foreground }}
            >
              {f.label}
            </Text>
          </Pressable>
        ))}
      </View>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.courseFilterScroll}
        contentContainerStyle={styles.courseFilterRow}
      >
        {[{ code: "all", name: "All Courses" }, ...courseOptions].map((course) => {
          const isActive = courseFilter === course.code;

          return (
            <Pressable
              key={course.code}
              onPress={() => setCourseFilter(course.code)}
              style={[
                styles.courseFilterBtn,
                isActive
                  ? { backgroundColor: colors.primary, borderColor: colors.primary }
                  : { backgroundColor: colors.card, borderColor: colors.border },
              ]}
            >
              <Text
                style={{
                  fontSize: 12,
                  fontFamily: "Inter_600SemiBold",
                  color: isActive ? "#FFFFFF" : colors.foreground,
                }}
                numberOfLines={1}
              >
                {course.name}
              </Text>
            </Pressable>
          );
        })}
      </ScrollView>

      <FlatList
        data={filtered}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ padding: 16, paddingBottom: bottomPad + 20, gap: 10 }}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => (
          <Card style={{ padding: 14 }}>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
              <View
                style={{
                  width: 44,
                  height: 44,
                  borderRadius: 12,
                  backgroundColor: item.status === "present" ? "#D1FAE5" : "#FEE2E2",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Ionicons
                  name={item.status === "present" ? "checkmark-circle" : "close-circle"}
                  size={24}
                  color={item.status === "present" ? "#10B981" : "#EF4444"}
                />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 15, fontWeight: "600", color: colors.foreground, fontFamily: "Inter_600SemiBold" }}>
                  {item.courseName}
                </Text>
                <Text style={{ fontSize: 12, color: colors.mutedForeground, fontFamily: "Inter_400Regular" }}>
                  {item.courseCode} · {item.date}
                  {item.time ? ` · ${item.time}` : ""}
                </Text>
              </View>
              <Badge
                label={item.status.charAt(0).toUpperCase() + item.status.slice(1)}
                variant={item.status === "present" ? "success" : "danger"}
              />
            </View>
            <View style={{ marginTop: 12, height: 6, backgroundColor: colors.muted, borderRadius: 3, overflow: "hidden" }}>
              <View style={{ width: `${item.attendanceRate}%`, height: 6, backgroundColor: item.attendanceRate >= 75 ? "#10B981" : "#EF4444", borderRadius: 3 }} />
            </View>
            <Text style={{ fontSize: 11, color: colors.mutedForeground, marginTop: 4, fontFamily: "Inter_400Regular" }}>
              Course attendance rate: {item.attendanceRate}%
            </Text>
          </Card>
        )}
        ListEmptyComponent={
          <View style={{ alignItems: "center", paddingTop: 60, gap: 12 }}>
            <Ionicons name="calendar-outline" size={48} color={colors.mutedForeground} />
            <Text style={{ fontSize: 16, color: colors.mutedForeground, fontFamily: "Inter_500Medium" }}>No records found</Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  summaryRow: {
    flexDirection: "row",
    paddingHorizontal: 16,
    paddingTop: 16,
    gap: 8,
  },
  summaryCard: {
    flex: 1,
    borderRadius: 12,
    padding: 12,
    alignItems: "center",
  },
  summaryVal: {
    fontSize: 20,
    fontWeight: "700",
    fontFamily: "Inter_700Bold",
  },
  summaryLabel: {
    fontSize: 10,
    fontFamily: "Inter_500Medium",
    marginTop: 2,
  },
  filterRow: {
    flexDirection: "row",
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 8,
  },
  filterBtn: {
    flex: 1,
    paddingVertical: 8,
    borderRadius: 10,
    alignItems: "center",
  },
  courseFilterRow: {
    paddingHorizontal: 16,
    paddingBottom: 10,
    gap: 8,
    alignItems: "center",
  },
  courseFilterScroll: {
    maxHeight: 48,
  },
  courseFilterBtn: {
    minWidth: 96,
    maxWidth: 190,
    minHeight: 36,
    borderRadius: 10,
    borderWidth: 1,
    paddingHorizontal: 12,
    paddingVertical: 8,
    alignItems: "center",
    justifyContent: "center",
  },
});
