import { Badge, Card, SectionHeader } from "@/components/UI";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import React from "react";
import { Pressable, ScrollView, StyleSheet, Text, useWindowDimensions, View } from "react-native";

const QUICK_ACTIONS = [
  { label: "Register Face", icon: "scan", route: "/student/face-enrollment", color: "#2563EB", bg: "#DBEAFE" },
  { label: "My Courses", icon: "book", route: "/student/courses", color: "#6366F1", bg: "#EEF2FF" },
  { label: "Attendance", icon: "calendar", route: "/student/attendance-history", color: "#10B981", bg: "#D1FAE5" },
  { label: "My QR Code", icon: "qr-code", route: "/student/qr-code", color: "#F59E0B", bg: "#FEF3C7" },
];

export default function StudentDashboard() {
  const colors = useColors();
  const { width } = useWindowDimensions();
  const { studentProfile, attendanceHistory, courses } = useApp();
  const isCompact = width < 860;

  const presentCount = attendanceHistory.filter((r) => r.status === "present").length;
  const totalCount = attendanceHistory.length;
  const attendanceRate = totalCount > 0 ? Math.round((presentCount / totalCount) * 100) : 0;
  const recentRecords = attendanceHistory.slice(0, 3);

  return (
    <ScrollView
      style={[styles.page, { backgroundColor: colors.background }]}
      showsVerticalScrollIndicator={false}
      contentContainerStyle={styles.scrollContent}
    >
      <View style={[styles.shell, isCompact && styles.shellCompact]}>
        <LinearGradient
          colors={["#0B1530", "#0F1B3C", "#1E3A7B"]}
          start={{ x: 0.08, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.hero}
        >
          <View style={styles.heroTop}>
            <View style={styles.heroCopy}>
              <Text style={styles.eyebrow}>Student workspace</Text>
              <Text style={styles.heroTitle} numberOfLines={2}>
                Good morning, {studentProfile?.name ?? "Student"}
              </Text>
              <View style={styles.identityRow}>
                <Text style={styles.identityText}>{studentProfile?.universityId}</Text>
                {studentProfile?.department ? (
                  <>
                    <View style={styles.identityDot} />
                    <Text style={styles.identityText}>{studentProfile.department}</Text>
                  </>
                ) : null}
              </View>
            </View>
            <Pressable
              onPress={() => router.push("/student/profile")}
              style={({ pressed, hovered }) => [
                styles.profileButton,
                hovered && styles.profileButtonHover,
                pressed && { opacity: 0.82 },
              ]}
            >
              <Ionicons name="person" size={22} color="#2563EB" />
              <Text style={styles.profileButtonText}>Profile</Text>
            </Pressable>
          </View>

          <View style={[styles.heroStats, isCompact && styles.heroStatsCompact]}>
            <View style={styles.heroStat}>
              <Text style={styles.heroStatValue}>{attendanceRate}%</Text>
              <Text style={styles.heroStatLabel}>Attendance rate</Text>
            </View>
            <View style={styles.heroDivider} />
            <View style={styles.heroStat}>
              <Text style={styles.heroStatValue}>{courses.length}</Text>
              <Text style={styles.heroStatLabel}>Enrolled courses</Text>
            </View>
            <View style={styles.heroDivider} />
            <View style={styles.heroStat}>
              <Text style={styles.heroStatValue}>{presentCount}/{totalCount || 0}</Text>
              <Text style={styles.heroStatLabel}>Present records</Text>
            </View>
          </View>
        </LinearGradient>

        {!studentProfile?.faceEnrolled && (
          <Pressable onPress={() => router.push("/student/face-enrollment")}>
            <View style={styles.warningBanner}>
              <View style={styles.warningIconBox}>
                <Ionicons name="scan" size={20} color="#92400E" />
              </View>
              <View style={styles.warningTextBlock}>
                <Text style={styles.warningTitle}>Register your face</Text>
                <Text style={styles.warningDesc}>Required for face recognition attendance.</Text>
              </View>
              <Ionicons name="chevron-forward" size={17} color="#92400E" />
            </View>
          </Pressable>
        )}

        <View style={[styles.grid, isCompact && styles.gridCompact]}>
          <View style={styles.primaryColumn}>
            <View>
              <SectionHeader title="Quick actions" />
              <View style={[styles.actionsGrid, isCompact && styles.actionsGridCompact]}>
                {QUICK_ACTIONS.map((action) => (
                  <Pressable
                    key={action.label}
                    onPress={() => {
                      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                      router.push(action.route as any);
                    }}
                    style={({ pressed, hovered }) => [
                      styles.actionCard,
                      {
                        backgroundColor: colors.card,
                        borderColor: colors.border,
                      },
                      hovered && styles.actionCardHover,
                      pressed && { opacity: 0.84, transform: [{ scale: 0.985 }] },
                    ]}
                  >
                    <View style={[styles.actionIcon, { backgroundColor: action.bg }]}>
                      <Ionicons name={action.icon as any} size={22} color={action.color} />
                    </View>
                    <View style={styles.actionTextBlock}>
                      <Text style={[styles.actionLabel, { color: colors.foreground }]}>
                        {action.label}
                      </Text>
                      <Text style={[styles.actionMeta, { color: colors.mutedForeground }]}>
                        Open
                      </Text>
                    </View>
                    <Ionicons name="chevron-forward" size={15} color={colors.mutedForeground} />
                  </Pressable>
                ))}
              </View>
            </View>

            <View>
              <SectionHeader
                title="Recent attendance"
                action="View all"
                onAction={() => router.push("/student/attendance-history")}
              />
              <View style={styles.recordStack}>
                {recentRecords.length > 0 ? (
                  recentRecords.map((record) => (
                    <Card key={record.id} style={styles.recordCard}>
                      <View style={styles.recordRow}>
                        <View
                          style={[
                            styles.statusDot,
                            { backgroundColor: record.status === "present" ? "#D1FAE5" : "#FEE2E2" },
                          ]}
                        >
                          <Ionicons
                            name={record.status === "present" ? "checkmark" : "close"}
                            size={13}
                            color={record.status === "present" ? "#10B981" : "#EF4444"}
                          />
                        </View>
                        <View style={styles.recordMain}>
                          <Text style={[styles.recordTitle, { color: colors.foreground }]}>
                            {record.courseName}
                          </Text>
                          <Text style={[styles.recordMeta, { color: colors.mutedForeground }]}>
                            {record.courseCode} · {record.date}
                          </Text>
                        </View>
                        <Badge
                          label={record.status.charAt(0).toUpperCase() + record.status.slice(1)}
                          variant={record.status === "present" ? "success" : "danger"}
                        />
                      </View>
                    </Card>
                  ))
                ) : (
                  <Card style={styles.emptyCard} elevated={false}>
                    <Text style={[styles.emptyTitle, { color: colors.foreground }]}>No attendance yet</Text>
                    <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
                      Your recent class records will appear here.
                    </Text>
                  </Card>
                )}
              </View>
            </View>
          </View>

          <View style={styles.sideColumn}>
            <Card style={styles.progressCard}>
              <Text style={[styles.panelKicker, { color: colors.mutedForeground }]}>Term snapshot</Text>
              <Text style={[styles.panelTitle, { color: colors.foreground }]}>Attendance standing</Text>
              <View style={styles.progressTrack}>
                <View
                  style={[
                    styles.progressFill,
                    { width: `${Math.min(attendanceRate, 100)}%`, backgroundColor: colors.primary },
                  ]}
                />
              </View>
              <Text style={[styles.progressNote, { color: colors.mutedForeground }]}>
                {totalCount > 0
                  ? `${presentCount} present records from ${totalCount} total sessions.`
                  : "No sessions have been recorded yet."}
              </Text>
            </Card>

            <Card style={styles.courseCard}>
              <View style={styles.courseHeader}>
                <Text style={[styles.panelTitle, { color: colors.foreground }]}>Courses</Text>
                <Badge label={`${courses.length} active`} variant="primary" />
              </View>
              <View style={styles.courseList}>
                {courses.slice(0, 4).map((course) => (
                  <View key={course.id} style={[styles.courseRow, { borderBottomColor: colors.border }]}>
                    <View>
                      <Text style={[styles.courseName, { color: colors.foreground }]}>{course.name}</Text>
                      <Text style={[styles.courseCode, { color: colors.mutedForeground }]}>{course.code}</Text>
                    </View>
                  </View>
                ))}
              </View>
            </Card>
          </View>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  actionCard: {
    alignItems: "center",
    borderRadius: 18,
    borderWidth: 1,
    flexDirection: "row",
    gap: 14,
    minWidth: 230,
    padding: 18,
  },
  actionCardHover: {
    boxShadow: "0 10px 22px rgba(13, 27, 62, 0.07)",
    transform: [{ translateY: -2 }],
  } as any,
  actionIcon: {
    alignItems: "center",
    borderRadius: 14,
    height: 48,
    justifyContent: "center",
    width: 48,
  },
  actionLabel: {
    fontFamily: "Inter_700Bold",
    fontSize: 15,
    fontWeight: "700",
  },
  actionMeta: {
    fontFamily: "Inter_400Regular",
    fontSize: 12,
    marginTop: 2,
  },
  actionTextBlock: {
    flex: 1,
  },
  actionsGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 14,
  },
  actionsGridCompact: {
    flexDirection: "column",
  },
  courseCard: {
    gap: 16,
  },
  courseCode: {
    fontFamily: "Inter_400Regular",
    fontSize: 12,
    marginTop: 2,
  },
  courseHeader: {
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "space-between",
  },
  courseList: {
    gap: 0,
  },
  courseName: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 14,
    fontWeight: "600",
  },
  courseRow: {
    borderBottomWidth: 1,
    paddingVertical: 13,
  },
  emptyCard: {
    padding: 22,
  },
  emptyText: {
    fontFamily: "Inter_400Regular",
    fontSize: 13,
    marginTop: 4,
  },
  emptyTitle: {
    fontFamily: "Inter_700Bold",
    fontSize: 15,
    fontWeight: "700",
  },
  eyebrow: {
    color: "rgba(255,255,255,0.58)",
    fontFamily: "Inter_600SemiBold",
    fontSize: 12,
    fontWeight: "600",
    letterSpacing: 1.2,
    textTransform: "uppercase",
  },
  grid: {
    alignItems: "flex-start",
    flexDirection: "row",
    gap: 24,
  },
  gridCompact: {
    flexDirection: "column",
  },
  hero: {
    borderRadius: 28,
    gap: 30,
    padding: 32,
  },
  heroCopy: {
    flex: 1,
    gap: 8,
  },
  heroDivider: {
    backgroundColor: "rgba(255,255,255,0.14)",
    height: 44,
    width: 1,
  },
  heroStat: {
    flex: 1,
    gap: 4,
  },
  heroStatLabel: {
    color: "rgba(255,255,255,0.56)",
    fontFamily: "Inter_400Regular",
    fontSize: 12,
  },
  heroStatValue: {
    color: "#FFFFFF",
    fontFamily: "Inter_700Bold",
    fontSize: 30,
    fontWeight: "700",
    letterSpacing: -0.7,
  },
  heroStats: {
    alignItems: "center",
    backgroundColor: "rgba(255,255,255,0.08)",
    borderColor: "rgba(255,255,255,0.1)",
    borderRadius: 20,
    borderWidth: 1,
    flexDirection: "row",
    padding: 20,
  },
  heroStatsCompact: {
    alignItems: "flex-start",
    gap: 16,
  },
  heroTitle: {
    color: "#FFFFFF",
    fontFamily: "Inter_700Bold",
    fontSize: 40,
    fontWeight: "700",
    letterSpacing: -1,
    lineHeight: 48,
  },
  heroTop: {
    alignItems: "flex-start",
    flexDirection: "row",
    gap: 20,
  },
  identityDot: {
    backgroundColor: "rgba(255,255,255,0.35)",
    borderRadius: 2,
    height: 4,
    width: 4,
  },
  identityRow: {
    alignItems: "center",
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
  },
  identityText: {
    color: "rgba(255,255,255,0.64)",
    fontFamily: "Inter_400Regular",
    fontSize: 14,
  },
  page: {
    flex: 1,
  },
  panelKicker: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 12,
    fontWeight: "600",
    letterSpacing: 0.8,
    textTransform: "uppercase",
  },
  panelTitle: {
    fontFamily: "Inter_700Bold",
    fontSize: 18,
    fontWeight: "700",
    letterSpacing: -0.2,
  },
  primaryColumn: {
    flex: 1,
    gap: 28,
    minWidth: 0,
  },
  profileButton: {
    alignItems: "center",
    backgroundColor: "#FFFFFF",
    borderRadius: 999,
    flexDirection: "row",
    gap: 8,
    paddingHorizontal: 16,
    paddingVertical: 11,
  },
  profileButtonHover: {
    transform: [{ translateY: -1 }],
  },
  profileButtonText: {
    color: "#1E3A7B",
    fontFamily: "Inter_700Bold",
    fontSize: 13,
    fontWeight: "700",
  },
  progressCard: {
    gap: 14,
  },
  progressFill: {
    borderRadius: 999,
    height: "100%",
  },
  progressNote: {
    fontFamily: "Inter_400Regular",
    fontSize: 13,
    lineHeight: 20,
  },
  progressTrack: {
    backgroundColor: "#E8ECF4",
    borderRadius: 999,
    height: 10,
    overflow: "hidden",
  },
  recordCard: {
    padding: 16,
  },
  recordMain: {
    flex: 1,
    minWidth: 0,
  },
  recordMeta: {
    fontFamily: "Inter_400Regular",
    fontSize: 12,
    marginTop: 2,
  },
  recordRow: {
    alignItems: "center",
    flexDirection: "row",
    gap: 13,
  },
  recordStack: {
    gap: 10,
  },
  recordTitle: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 14,
    fontWeight: "600",
  },
  scrollContent: {
    paddingBottom: 44,
  },
  shell: {
    alignSelf: "center",
    gap: 24,
    maxWidth: 1180,
    paddingHorizontal: 28,
    paddingTop: 28,
    width: "100%",
  },
  shellCompact: {
    paddingHorizontal: 16,
    paddingTop: 16,
  },
  sideColumn: {
    gap: 18,
    width: 320,
  },
  statusDot: {
    alignItems: "center",
    borderRadius: 10,
    height: 34,
    justifyContent: "center",
    width: 34,
  },
  warningBanner: {
    alignItems: "center",
    backgroundColor: "#FFFBEB",
    borderColor: "#FCD34D",
    borderRadius: 18,
    borderWidth: 1,
    flexDirection: "row",
    gap: 13,
    padding: 16,
  },
  warningDesc: {
    color: "#B45309",
    fontFamily: "Inter_400Regular",
    fontSize: 13,
    marginTop: 2,
  },
  warningIconBox: {
    alignItems: "center",
    backgroundColor: "#FEF3C7",
    borderRadius: 13,
    height: 44,
    justifyContent: "center",
    width: 44,
  },
  warningTextBlock: {
    flex: 1,
  },
  warningTitle: {
    color: "#92400E",
    fontFamily: "Inter_700Bold",
    fontSize: 14,
    fontWeight: "700",
  },
});
