import { Button, Card } from "@/components/UI";
import { AccountSettingsCard } from "@/components/AccountSettingsCard";
import { ScreenHeader } from "@/components/ScreenHeader";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useState } from "react";
import { ActivityIndicator, Alert, Image, Platform, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

interface InfoRowProps {
  label: string;
  value: string;
  icon: string;
}

function InfoRow({ label, value, icon }: InfoRowProps) {
  const colors = useColors();
  return (
    <View style={{ flexDirection: "row", alignItems: "center", gap: 14, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: colors.border }}>
      <View style={{ width: 36, height: 36, borderRadius: 10, backgroundColor: colors.muted, alignItems: "center", justifyContent: "center" }}>
        <Ionicons name={icon as any} size={18} color={colors.primary} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={{ fontSize: 11, color: colors.mutedForeground, fontFamily: "Inter_500Medium", textTransform: "uppercase", letterSpacing: 0.5 }}>
          {label}
        </Text>
        <Text style={{ fontSize: 15, color: colors.foreground, fontFamily: "Inter_500Medium", marginTop: 2 }}>
          {value}
        </Text>
      </View>
    </View>
  );
}

export default function StudentProfile() {
  const colors = useColors();
  const { studentProfile, logout } = useApp();
  const insets = useSafeAreaInsets();
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;
  const [isSigningOut, setIsSigningOut] = useState(false);

  const performSignOut = async () => {
    setIsSigningOut(true);

    try {
      await logout();
      router.replace("/role-select");
    } catch {
      setIsSigningOut(false);
      Alert.alert("Sign Out", "Unable to sign out. Please try again.");
    }
  };

  const handleSignOut = () => {
    if (isSigningOut) {
      return;
    }

    if (Platform.OS === "web") {
      const confirmed =
        typeof globalThis.confirm === "function"
          ? globalThis.confirm("Are you sure you want to sign out?")
          : true;

      if (confirmed) {
        void performSignOut();
      }
      return;
    }

    Alert.alert("Sign Out", "Are you sure you want to sign out?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Sign Out",
        style: "destructive",
        onPress: () => void performSignOut(),
      },
    ]);
  };

  if (!studentProfile) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.background }}>
        <ScreenHeader title="My Profile" showBack subtitle="Student" />
        <View style={styles.emptyState}>
          {isSigningOut ? (
            <>
              <ActivityIndicator size="small" color={colors.primary} />
              <Text style={{ color: colors.mutedForeground, fontFamily: "Inter_500Medium" }}>
                Signing out...
              </Text>
            </>
          ) : (
            <Text style={{ color: colors.mutedForeground, fontFamily: "Inter_500Medium" }}>
              Profile unavailable.
            </Text>
          )}
        </View>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <ScreenHeader title="My Profile" showBack subtitle={studentProfile.department} />
      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: bottomPad + 20, gap: 20 }} showsVerticalScrollIndicator={false}>
        <Card style={styles.identityCard}>
          {studentProfile.faceImageUri ? (
            <Image source={{ uri: studentProfile.faceImageUri }} style={styles.avatarImage} />
          ) : (
            <View style={styles.avatarLarge}>
              <Ionicons name="person" size={40} color="#2563EB" />
            </View>
          )}
          <View style={{ alignItems: "center" }}>
            <Text style={{ fontSize: 20, fontWeight: "700", color: colors.foreground, fontFamily: "Inter_700Bold" }}>
              {studentProfile.name}
            </Text>
            <Text style={{ fontSize: 14, color: colors.mutedForeground, fontFamily: "Inter_400Regular" }}>
              {studentProfile.universityId}
            </Text>
          </View>
          <View style={{ flexDirection: "row", gap: 8 }}>
            <View style={{ backgroundColor: "#DBEAFE", borderRadius: 20, paddingHorizontal: 12, paddingVertical: 4 }}>
              <Text style={{ fontSize: 12, color: "#1E40AF", fontFamily: "Inter_600SemiBold" }}>Student</Text>
            </View>
            <View style={{ backgroundColor: studentProfile.faceEnrolled ? "#D1FAE5" : "#FEE2E2", borderRadius: 20, paddingHorizontal: 12, paddingVertical: 4 }}>
              <Text style={{ fontSize: 12, color: studentProfile.faceEnrolled ? "#166534" : "#991B1B", fontFamily: "Inter_600SemiBold" }}>
                {studentProfile.faceEnrolled ? "Face Enrolled" : "Face Not Enrolled"}
              </Text>
            </View>
          </View>
        </Card>

        <Card>
          <InfoRow label="Full Name" value={studentProfile.name} icon="person-outline" />
          <InfoRow label="University ID" value={studentProfile.universityId} icon="id-card-outline" />
          <InfoRow label="Email" value={studentProfile.email} icon="mail-outline" />
          <InfoRow label="Major" value={studentProfile.department} icon="business-outline" />
          <View style={{ paddingTop: 14 }}>
            <InfoRow label="Level" value={studentProfile.level} icon="school-outline" />
          </View>
        </Card>

        <AccountSettingsCard mode="student" />

        <Button
          title="Register Face Data"
          onPress={() => router.push("/student/face-enrollment")}
          variant={studentProfile.faceEnrolled ? "secondary" : "primary"}
        />

        <Pressable onPress={handleSignOut} disabled={isSigningOut}>
          <View style={[styles.signOutRow, isSigningOut && styles.signOutRowDisabled]}>
            <Ionicons name="log-out-outline" size={17} color={colors.mutedForeground} />
            {isSigningOut ? (
              <ActivityIndicator size="small" color={colors.mutedForeground} />
            ) : (
              <Text style={{ color: colors.mutedForeground, fontSize: 14, fontFamily: "Inter_500Medium" }}>
                Sign Out
              </Text>
            )}
          </View>
        </Pressable>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  avatarLarge: {
    width: 82,
    height: 82,
    borderRadius: 41,
    backgroundColor: "#DBEAFE",
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 3,
    borderColor: "#BFDBFE",
  },
  avatarImage: {
    width: 82,
    height: 82,
    borderRadius: 41,
    borderWidth: 3,
    borderColor: "#BFDBFE",
  },
  identityCard: {
    alignItems: "center",
    gap: 10,
    paddingVertical: 22,
  },
  signOutRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    paddingVertical: 14,
    backgroundColor: "#FFFFFF",
    borderRadius: 14,
    borderWidth: 1,
    borderColor: "#E8ECF4",
  },
  signOutRowDisabled: {
    opacity: 0.7,
  },
  emptyState: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 12,
    paddingHorizontal: 24,
  },
});
