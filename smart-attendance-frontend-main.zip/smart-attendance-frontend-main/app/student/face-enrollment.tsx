import { Button, Card } from "@/components/UI";
import { ScreenHeader } from "@/components/ScreenHeader";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { Ionicons } from "@expo/vector-icons";
import { CameraView, useCameraPermissions } from "expo-camera";
import * as Haptics from "expo-haptics";
import * as ImagePicker from "expo-image-picker";
import { router } from "expo-router";
import React, { useEffect, useRef, useState } from "react";
import { Image, Platform, ScrollView, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

type Step = "idle" | "camera" | "preview" | "verifying" | "verified";
type DetectionState = "idle" | "detected" | "not-detected";
type ImageAssetLike = {
  uri?: string | null;
  base64?: string | null;
  mimeType?: string | null;
};

function getPersistableImageUri(asset: ImageAssetLike) {
  if (Platform.OS === "web" && asset.base64) {
    return `data:${asset.mimeType || "image/jpeg"};base64,${asset.base64}`;
  }

  return asset.uri || null;
}

export default function FaceEnrollment() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { studentProfile, enrollFace, isLoading } = useApp();
  const [cameraPermission, requestCameraPermission] = useCameraPermissions();

  const [step, setStep] = useState<Step>("idle");
  const [detectionState, setDetectionState] = useState<DetectionState>("idle");
  const [previewUri, setPreviewUri] = useState<string | null>(studentProfile?.faceImageUri || null);
  const [error, setError] = useState("");
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraReady, setCameraReady] = useState(false);
  const [isUpdatingFace, setIsUpdatingFace] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const nativeCameraRef = useRef<CameraView | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;
  const isVerified = Boolean(studentProfile?.faceEnrolled);
  const canEditFaceData = !isVerified || isUpdatingFace;
  const savedFaceImage = studentProfile?.faceImageUri || studentProfile?.avatar || null;

  const stopCamera = () => {
    streamRef.current?.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
    setCameraActive(false);
    setCameraReady(false);
  };

  useEffect(() => {
    if (isVerified && !isUpdatingFace) {
      stopCamera();
      setPreviewUri(savedFaceImage);
      setDetectionState(savedFaceImage ? "detected" : "idle");
      setStep("verified");
      setError("");
      return;
    }

    setStep((currentStep) => (currentStep === "verified" ? "idle" : currentStep));
  }, [isUpdatingFace, isVerified, savedFaceImage]);

  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  useEffect(() => {
    if (Platform.OS !== "web" || !cameraActive || !videoRef.current || !streamRef.current) {
      return;
    }

    const video = videoRef.current;
    video.srcObject = streamRef.current;

    const handleLoadedMetadata = () => {
      setCameraReady(true);
    };

    video.addEventListener("loadedmetadata", handleLoadedMetadata);

    void video.play().catch(() => {
      setCameraReady(false);
      setError("Camera preview could not start.");
    });

    return () => {
      video.removeEventListener("loadedmetadata", handleLoadedMetadata);
    };
  }, [cameraActive]);

  const beginCameraCapture = async () => {
    if (!canEditFaceData) {
      return;
    }

    setError("");
    setDetectionState("idle");

    if (Platform.OS !== "web") {
      const permission = cameraPermission?.granted
        ? cameraPermission
        : await requestCameraPermission();

      if (!permission.granted) {
        setError("Camera access is required to capture face data.");
        return;
      }

      setStep("camera");
      setCameraActive(true);
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: "user",
          width: { ideal: 960 },
          height: { ideal: 960 },
        },
        audio: false,
      });
      streamRef.current?.getTracks().forEach((track) => track.stop());
      streamRef.current = stream;
      setCameraActive(true);
      setStep("camera");
    } catch {
      setError("Unable to access camera. Please allow camera permission and try again.");
    }
  };

  const handleUploadPhoto = async () => {
    if (!canEditFaceData) {
      return;
    }

    stopCamera();
    setError("");
    setStep("preview");

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ["images"],
      allowsEditing: true,
      quality: 0.85,
      base64: Platform.OS === "web",
    });

    if (result.canceled || !result.assets[0]) {
      setStep(previewUri ? "preview" : "idle");
      return;
    }

    const nextUri = getPersistableImageUri(result.assets[0]);
    if (!nextUri) {
      setDetectionState("not-detected");
      setError("Unable to read the selected image.");
      setStep(previewUri ? "preview" : "idle");
      return;
    }

    setPreviewUri(nextUri);
    setDetectionState("detected");
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };

  const handleCapturePhoto = async () => {
    if (!canEditFaceData || !cameraActive) {
      return;
    }

    setError("");

    if (Platform.OS !== "web") {
      const photo = await nativeCameraRef.current?.takePictureAsync({
        quality: 0.72,
        shutterSound: false,
        skipProcessing: true,
      });

      const nextUri = photo ? getPersistableImageUri(photo) : null;
      if (!nextUri) {
        setDetectionState("not-detected");
        setError("Unable to capture your face photo.");
        return;
      }

      stopCamera();
      setPreviewUri(nextUri);
      setDetectionState("detected");
      setStep("preview");
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      return;
    }

    if (!videoRef.current) {
      setError("Camera preview is not ready yet.");
      return;
    }

    const video = videoRef.current;
    const canvas = document.createElement("canvas");
    canvas.width = video.videoWidth || 720;
    canvas.height = video.videoHeight || 720;
    const context = canvas.getContext("2d");

    if (!context) {
      setDetectionState("not-detected");
      setError("Unable to capture your face photo.");
      return;
    }

    context.drawImage(video, 0, 0, canvas.width, canvas.height);
    stopCamera();
    setPreviewUri(canvas.toDataURL("image/jpeg", 0.92));
    setDetectionState("detected");
    setStep("preview");
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };

  const handleVerify = async () => {
    if (!previewUri || !canEditFaceData) {
      setDetectionState("not-detected");
      setError("Please capture or upload your face before continuing.");
      return;
    }

    setError("");
    setStep("verifying");
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    try {
      await enrollFace({
        uri: previewUri,
        name: "face.jpg",
        mimeType: "image/jpeg",
      });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setIsUpdatingFace(false);
      setStep("verified");
    } catch (err) {
      setStep("preview");
      setError(err instanceof Error ? err.message : "Unable to register face data.");
    }
  };

  const handleClearSelection = () => {
    if (!canEditFaceData) {
      return;
    }

    stopCamera();
    setPreviewUri(null);
    setDetectionState("idle");
    setError("");
    setStep("idle");
  };

  const handleUpdateFaceData = () => {
    stopCamera();
    setIsUpdatingFace(true);
    setPreviewUri(null);
    setDetectionState("idle");
    setError("");
    setStep("idle");
  };

  const statusColor =
    detectionState === "detected"
      ? "#10B981"
      : detectionState === "not-detected"
        ? "#EF4444"
        : "rgba(255,255,255,0.7)";
  const statusText =
    step === "verified"
      ? "Identity already verified"
      : detectionState === "detected"
        ? "Face detected"
        : detectionState === "not-detected"
          ? "No face detected"
          : "Align your face within the frame";

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <ScreenHeader title="Face Enrollment" showBack subtitle="Register your biometric data" />
      <ScrollView
        contentContainerStyle={{ padding: 20, paddingBottom: bottomPad + 20, gap: 20 }}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.cameraPlaceholder}>
          <View style={styles.cameraInner}>
            {Platform.OS === "web" && cameraActive ? (
              <View style={styles.videoFrame}>
                <video ref={videoRef} muted playsInline autoPlay style={styles.webVideo as never} />
                <View style={styles.videoOverlay}>
                  <View style={[styles.corner, styles.cornerTopLeft, cameraReady ? styles.cornerDetected : null]} />
                  <View style={[styles.corner, styles.cornerTopRight, cameraReady ? styles.cornerDetected : null]} />
                  <View style={[styles.corner, styles.cornerBottomLeft, cameraReady ? styles.cornerDetected : null]} />
                  <View style={[styles.corner, styles.cornerBottomRight, cameraReady ? styles.cornerDetected : null]} />
                </View>
              </View>
            ) : Platform.OS !== "web" && cameraActive ? (
              <View style={styles.videoFrame}>
                <CameraView
                  ref={nativeCameraRef}
                  style={StyleSheet.absoluteFill}
                  facing="front"
                  mirror
                  active={cameraActive}
                  mode="picture"
                  onCameraReady={() => setCameraReady(true)}
                  onMountError={(event) => {
                    setCameraReady(false);
                    setError(event.message || "Camera preview could not start.");
                  }}
                />
                <View style={styles.videoOverlay} pointerEvents="none">
                  <View style={[styles.corner, styles.cornerTopLeft, cameraReady ? styles.cornerDetected : null]} />
                  <View style={[styles.corner, styles.cornerTopRight, cameraReady ? styles.cornerDetected : null]} />
                  <View style={[styles.corner, styles.cornerBottomLeft, cameraReady ? styles.cornerDetected : null]} />
                  <View style={[styles.corner, styles.cornerBottomRight, cameraReady ? styles.cornerDetected : null]} />
                </View>
              </View>
            ) : previewUri ? (
              <Image source={{ uri: previewUri }} style={styles.previewImage} />
            ) : (
              <View style={styles.faceGuide}>
                <View style={[styles.corner, styles.cornerTopLeft]} />
                <View style={[styles.corner, styles.cornerTopRight]} />
                <View style={[styles.corner, styles.cornerBottomLeft]} />
                <View style={[styles.corner, styles.cornerBottomRight]} />
                <Ionicons
                  name={step === "verified" ? "checkmark-circle-outline" : "person-circle-outline"}
                  size={100}
                  color={step === "verified" ? "rgba(34,197,94,0.5)" : "rgba(37,99,235,0.5)"}
                />
              </View>
            )}
          </View>
          <Text style={[styles.cameraLabel, { color: statusColor }]}>
            {step === "verifying" ? "Verifying identity..." : statusText}
          </Text>
        </View>

        {step === "verified" ? (
          <Card>
            <Text
              style={{
                fontSize: 16,
                fontWeight: "700",
                color: colors.foreground,
                fontFamily: "Inter_700Bold",
                marginBottom: 8,
              }}
            >
              Identity already verified
            </Text>
            <Text
              style={{
                fontSize: 13,
                color: colors.mutedForeground,
                fontFamily: "Inter_400Regular",
                lineHeight: 20,
              }}
            >
              Your verified face image is saved locally for this student account. You can return to
              your profile or dashboard without capturing again, or update it if your appearance has
              changed.
            </Text>
          </Card>
        ) : previewUri ? (
          <Card>
            <Text
              style={{
                fontSize: 15,
                fontWeight: "600",
                color: colors.foreground,
                fontFamily: "Inter_600SemiBold",
                marginBottom: 12,
              }}
            >
              Ready for verification
            </Text>
            <View
              style={{
                height: 8,
                backgroundColor: colors.muted,
                borderRadius: 4,
                overflow: "hidden",
              }}
            >
              <View
                style={{
                  width: step === "verifying" ? "100%" : "72%",
                  height: 8,
                  backgroundColor: step === "verifying" ? colors.primary : "#10B981",
                  borderRadius: 4,
                }}
              />
            </View>
            <Text
              style={{
                fontSize: 12,
                color: colors.mutedForeground,
                marginTop: 12,
                fontFamily: "Inter_400Regular",
              }}
            >
              {step === "verifying"
                ? "Processing your selected face image with the local verification flow."
                : "Review the selected face image, then continue when you are ready."}
            </Text>
          </Card>
        ) : null}

        {error ? (
          <Card style={{ backgroundColor: "#FEF2F2", borderColor: "#FECACA", borderWidth: 1 }}>
            <Text style={{ color: "#B91C1C", fontFamily: "Inter_500Medium" }}>{error}</Text>
          </Card>
        ) : null}

        <Card>
          <Text
            style={{
              fontSize: 15,
              fontWeight: "600",
              color: colors.foreground,
              fontFamily: "Inter_600SemiBold",
              marginBottom: 12,
            }}
          >
            Camera Guidelines
          </Text>
          {[
            "Keep your face centered inside the frame",
            "Ensure good lighting (avoid dark environments)",
            "Look directly at the camera",
            "Avoid wearing sunglasses or masks",
            "Keep only one face in the frame",
            "Hold your phone steady while capturing",
          ].map((tip, index) => (
            <View
              key={tip}
              style={{
                flexDirection: "row",
                gap: 10,
                marginBottom: 10,
                alignItems: "flex-start",
              }}
            >
              <View
                style={{
                  width: 20,
                  height: 20,
                  borderRadius: 10,
                  backgroundColor: colors.secondary,
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Text style={{ fontSize: 10, color: colors.primary, fontFamily: "Inter_700Bold" }}>
                  {index + 1}
                </Text>
              </View>
              <Text
                style={{
                  flex: 1,
                  fontSize: 13,
                  color: colors.mutedForeground,
                  fontFamily: "Inter_400Regular",
                  lineHeight: 19,
                }}
              >
                {tip}
              </Text>
            </View>
          ))}
        </Card>

        {step === "camera" ? (
          <View style={{ gap: 12 }}>
            <Button
              title={cameraReady ? "Capture Photo" : "Preparing Camera..."}
              onPress={handleCapturePhoto}
              disabled={!cameraReady || isLoading}
              loading={false}
              size="lg"
            />
            <Button title="Close Camera" onPress={handleClearSelection} variant="outline" size="lg" />
          </View>
        ) : step === "verified" ? (
          <View style={{ gap: 12 }}>
            <Button title="Update Face Data" onPress={handleUpdateFaceData} size="lg" />
            <Button title="Back to Profile" onPress={() => router.back()} size="lg" />
          </View>
        ) : previewUri ? (
          <View style={{ gap: 12 }}>
            <Button
              title={step === "verifying" || isLoading ? "Verifying..." : "Verify Identity"}
              onPress={handleVerify}
              disabled={step === "verifying" || isLoading}
              loading={step === "verifying" || isLoading}
              size="lg"
            />
            <Button title="Take Photo" onPress={beginCameraCapture} variant="outline" size="lg" />
            <Button title="Upload Photo" onPress={handleUploadPhoto} variant="secondary" size="lg" />
          </View>
        ) : (
          <View style={{ gap: 12 }}>
            <Button title="Take Photo" onPress={beginCameraCapture} size="lg" />
            <Button title="Upload Photo" onPress={handleUploadPhoto} variant="outline" size="lg" />
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  cameraPlaceholder: {
    height: 280,
    backgroundColor: "#1A2540",
    borderRadius: 20,
    overflow: "hidden",
    alignItems: "center",
    justifyContent: "center",
  },
  cameraInner: {
    width: 220,
    height: 220,
    alignItems: "center",
    justifyContent: "center",
  },
  videoFrame: {
    width: 220,
    height: 220,
    borderRadius: 20,
    overflow: "hidden",
    position: "relative",
    backgroundColor: "#0B1530",
  },
  previewImage: {
    width: 220,
    height: 220,
    borderRadius: 20,
  },
  webVideo: {
    width: "100%",
    height: "100%",
    objectFit: "cover",
    transform: "scaleX(-1)",
  },
  videoOverlay: {
    ...StyleSheet.absoluteFillObject,
  },
  faceGuide: {
    width: 180,
    height: 180,
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
  },
  corner: {
    position: "absolute",
    width: 28,
    height: 28,
    borderColor: "#3B82F6",
  },
  cornerDetected: {
    borderColor: "#10B981",
  },
  cornerTopLeft: {
    top: 0,
    left: 0,
    borderTopWidth: 3,
    borderLeftWidth: 3,
  },
  cornerTopRight: {
    top: 0,
    right: 0,
    borderTopWidth: 3,
    borderRightWidth: 3,
  },
  cornerBottomLeft: {
    bottom: 0,
    left: 0,
    borderBottomWidth: 3,
    borderLeftWidth: 3,
  },
  cornerBottomRight: {
    bottom: 0,
    right: 0,
    borderBottomWidth: 3,
    borderRightWidth: 3,
  },
  cameraLabel: {
    position: "absolute",
    bottom: 18,
    fontSize: 13,
    fontFamily: "Inter_500Medium",
  },
});
