import { Badge, Button, Card } from "@/components/UI";
import { AccountSettingsCard } from "@/components/AccountSettingsCard";
import { ScreenHeader } from "@/components/ScreenHeader";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Image,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  useWindowDimensions,
  View,
} from "react-native";

interface InfoRowProps {
  label: string;
  value: string;
  icon: string;
}

function InfoRow({ label, value, icon }: InfoRowProps) {
  const colors = useColors();

  return (
    <View style={[styles.infoRow, { borderBottomColor: colors.border }]}>
      <View style={[styles.infoIcon, { backgroundColor: colors.muted }]}>
        <Ionicons name={icon as any} size={18} color={colors.primary} />
      </View>
      <View style={styles.infoText}>
        <Text style={[styles.infoLabel, { color: colors.mutedForeground }]}>{label}</Text>
        <Text style={[styles.infoValue, { color: colors.foreground }]}>{value}</Text>
      </View>
    </View>
  );
}

export default function StudentProfile() {
  const colors = useColors();
  const { studentProfile, logout } = useApp();
  const { width } = useWindowDimensions();
  const isWide = width >= 960;
  const [isSigningOut, setIsSigningOut] = useState(false);

  const performSignOut = async () => {
    setIsSigningOut(true);

    try {
      await logout();
      router.replace("/role-select");
    } catch {
      setIsSigningOut(false);
      Alert.alert("Sign Out", "Unable to sign out. Please try again.");
    }
  };

  const handleSignOut = () => {
    if (isSigningOut) {
      return;
    }

    if (Platform.OS === "web") {
      const confirmed =
        typeof globalThis.confirm === "function"
          ? globalThis.confirm("Are you sure you want to sign out?")
          : true;

      if (confirmed) {
        void performSignOut();
      }
      return;
    }

    Alert.alert("Sign Out", "Are you sure you want to sign out?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Sign Out",
        style: "destructive",
        onPress: () => void performSignOut(),
      },
    ]);
  };

  if (!studentProfile) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.background }}>
        <ScreenHeader title="My Profile" showBack subtitle="Student" />
        <View style={styles.emptyState}>
          {isSigningOut ? (
            <>
              <ActivityIndicator size="small" color={colors.primary} />
              <Text style={[styles.emptyStateText, { color: colors.mutedForeground }]}>
                Signing out...
              </Text>
            </>
          ) : (
            <Text style={[styles.emptyStateText, { color: colors.mutedForeground }]}>
              Profile unavailable.
            </Text>
          )}
        </View>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <ScreenHeader title="My Profile" showBack subtitle={studentProfile.department} />
      <ScrollView
        contentContainerStyle={[
          styles.page,
          { paddingHorizontal: isWide ? 32 : 18, paddingBottom: 44 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <View style={[styles.profileGrid, { flexDirection: isWide ? "row" : "column" }]}>
          <Card style={styles.identityPanel}>
            <View style={styles.identityTopline}>
              <Text style={[styles.kicker, { color: colors.mutedForeground }]}>
                Student record
              </Text>
              <Badge label={studentProfile.faceEnrolled ? "Face Enrolled" : "Not Enrolled"} variant={studentProfile.faceEnrolled ? "success" : "danger"} />
            </View>

            <View style={styles.identityMain}>
              {studentProfile.faceImageUri ? (
                <Image source={{ uri: studentProfile.faceImageUri }} style={styles.avatarImage} />
              ) : (
                <View style={styles.avatarLarge}>
                  <Ionicons name="person" size={40} color="#2563EB" />
                </View>
              )}
              <View style={styles.nameBlock}>
                <Text style={[styles.profileName, { color: colors.foreground }]}>
                  {studentProfile.name}
                </Text>
                <Text style={[styles.profileSubline, { color: colors.mutedForeground }]}>
                  {studentProfile.universityId}
                </Text>
                <View style={styles.badgeRow}>
                  <Badge label="Student" variant="primary" />
                  <Badge label={studentProfile.level} variant="muted" />
                </View>
              </View>
            </View>

          </Card>

          <View style={styles.detailColumn}>
            <Card style={styles.detailCard}>
              <View style={styles.cardHeader}>
                <View>
                  <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
                    Academic details
                  </Text>
                  <Text style={[styles.sectionSubtitle, { color: colors.mutedForeground }]}>
                    Profile data from the current student account
                  </Text>
                </View>
              </View>
              <InfoRow label="Full Name" value={studentProfile.name} icon="person-outline" />
              <InfoRow label="University ID" value={studentProfile.universityId} icon="id-card-outline" />
              <InfoRow label="Email" value={studentProfile.email} icon="mail-outline" />
              <InfoRow label="Major" value={studentProfile.department} icon="business-outline" />
              <InfoRow label="Level" value={studentProfile.level} icon="school-outline" />
            </Card>

            <AccountSettingsCard mode="student" />

            <View style={styles.actionStack}>
              <Button
                title="Register Face Data"
                onPress={() => router.push("/student/face-enrollment")}
                variant={studentProfile.faceEnrolled ? "secondary" : "primary"}
              />
              <Pressable onPress={handleSignOut} disabled={isSigningOut}>
                <View style={[styles.signOutRow, { borderColor: colors.border, backgroundColor: colors.card }, isSigningOut && styles.signOutRowDisabled]}>
                  <Ionicons name="log-out-outline" size={17} color={colors.mutedForeground} />
                  {isSigningOut ? (
                    <ActivityIndicator size="small" color={colors.mutedForeground} />
                  ) : (
                    <Text style={[styles.signOutText, { color: colors.mutedForeground }]}>
                      Sign Out
                    </Text>
                  )}
                </View>
              </Pressable>
            </View>

            <Card style={styles.statusPanel}>
              <View style={styles.statusIcon}>
                <Ionicons name={studentProfile.faceEnrolled ? "shield-checkmark" : "shield-outline"} size={22} color={studentProfile.faceEnrolled ? "#10B981" : "#F59E0B"} />
              </View>
              <View style={styles.statusCopy}>
                <Text style={[styles.statusTitle, { color: colors.foreground }]}>
                  {studentProfile.faceEnrolled ? "Face data is registered" : "Face data is not registered"}
                </Text>
                <Text style={[styles.statusDescription, { color: colors.mutedForeground }]}>
                  {studentProfile.faceEnrolled
                    ? "Your profile is ready for face recognition attendance sessions."
                    : "Register face data to use face recognition attendance when required."}
                </Text>
              </View>
            </Card>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  actionStack: {
    gap: 12,
    marginTop: 8,
  },
  avatarImage: {
    borderColor: "#BFDBFE",
    borderRadius: 38,
    borderWidth: 3,
    height: 76,
    width: 76,
  },
  avatarLarge: {
    alignItems: "center",
    backgroundColor: "#DBEAFE",
    borderColor: "#BFDBFE",
    borderRadius: 38,
    borderWidth: 3,
    height: 76,
    justifyContent: "center",
    width: 76,
  },
  badgeRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
    marginTop: 10,
  },
  cardHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 4,
  },
  detailCard: {
    gap: 2,
  },
  detailColumn: {
    flex: 1,
    gap: 18,
    minWidth: 0,
  },
  emptyState: {
    alignItems: "center",
    flex: 1,
    gap: 12,
    justifyContent: "center",
    paddingHorizontal: 24,
  },
  emptyStateText: {
    fontFamily: "Inter_500Medium",
    fontSize: 14,
  },
  identityMain: {
    alignItems: "center",
    gap: 12,
    paddingVertical: 10,
  },
  identityPanel: {
    alignSelf: "flex-start",
    flex: 0.85,
    gap: 14,
    minWidth: 300,
  },
  identityTopline: {
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 12,
  },
  infoIcon: {
    alignItems: "center",
    borderRadius: 12,
    height: 40,
    justifyContent: "center",
    width: 40,
  },
  infoLabel: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 11,
    letterSpacing: 0.6,
    textTransform: "uppercase",
  },
  infoRow: {
    alignItems: "center",
    borderBottomWidth: 1,
    flexDirection: "row",
    gap: 14,
    paddingVertical: 15,
  },
  infoText: {
    flex: 1,
    minWidth: 0,
  },
  infoValue: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 15,
    marginTop: 2,
  },
  kicker: {
    fontFamily: "Inter_700Bold",
    fontSize: 11,
    letterSpacing: 0.8,
    textTransform: "uppercase",
  },
  nameBlock: {
    alignItems: "center",
  },
  page: {
    alignSelf: "center",
    maxWidth: 1180,
    paddingTop: 28,
    width: "100%",
  },
  profileGrid: {
    gap: 22,
  },
  profileName: {
    fontFamily: "Inter_700Bold",
    fontSize: 24,
    fontWeight: "700",
    textAlign: "center",
  },
  profileSubline: {
    fontFamily: "Inter_500Medium",
    fontSize: 13,
    marginTop: 2,
    textAlign: "center",
  },
  sectionSubtitle: {
    fontFamily: "Inter_400Regular",
    fontSize: 13,
    marginTop: 3,
  },
  sectionTitle: {
    fontFamily: "Inter_700Bold",
    fontSize: 18,
    fontWeight: "700",
  },
  signOutRow: {
    alignItems: "center",
    borderRadius: 14,
    borderWidth: 1,
    flexDirection: "row",
    gap: 8,
    justifyContent: "center",
    paddingVertical: 14,
  },
  signOutRowDisabled: {
    opacity: 0.7,
  },
  signOutText: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 14,
  },
  statusCopy: {
    flex: 1,
    gap: 4,
  },
  statusDescription: {
    fontFamily: "Inter_400Regular",
    fontSize: 13,
    lineHeight: 20,
  },
  statusIcon: {
    alignItems: "center",
    backgroundColor: "#F8FAFC",
    borderRadius: 14,
    height: 46,
    justifyContent: "center",
    width: 46,
  },
  statusPanel: {
    alignItems: "center",
    flexDirection: "row",
    gap: 14,
  },
  statusTitle: {
    fontFamily: "Inter_700Bold",
    fontSize: 15,
  },
});
