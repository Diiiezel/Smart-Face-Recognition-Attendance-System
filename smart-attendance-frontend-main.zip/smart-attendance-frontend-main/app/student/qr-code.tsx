import { Card } from "@/components/UI";
import { ScreenHeader } from "@/components/ScreenHeader";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { Ionicons } from "@expo/vector-icons";
import QRCode from "react-native-qrcode-svg";
import React from "react";
import { Platform, ScrollView, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

export default function MyQRCode() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { studentProfile, qrPayload } = useApp();
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <ScreenHeader title="My QR Code" showBack subtitle="Show this to mark attendance" />
      <ScrollView
        contentContainerStyle={{ padding: 20, paddingBottom: bottomPad + 20, gap: 20 }}
        showsVerticalScrollIndicator={false}
      >
        <Card style={{ alignItems: "center", paddingVertical: 32, gap: 20 }}>
          <View style={styles.qrContainer}>
            <View style={styles.qrInner}>
              {qrPayload ? (
                <QRCode
                  value={qrPayload}
                  size={200}
                  backgroundColor="#FFFFFF"
                  color="#0F172A"
                />
              ) : (
                <View style={styles.emptyQr}>
                  <Ionicons name="qr-code-outline" size={72} color={colors.mutedForeground} />
                </View>
              )}
            </View>
            <View style={[styles.qrCorner, { top: 0, left: 0, borderTopWidth: 3, borderLeftWidth: 3 }]} />
            <View style={[styles.qrCorner, { top: 0, right: 0, borderTopWidth: 3, borderRightWidth: 3 }]} />
            <View style={[styles.qrCorner, { bottom: 0, left: 0, borderBottomWidth: 3, borderLeftWidth: 3 }]} />
            <View style={[styles.qrCorner, { bottom: 0, right: 0, borderBottomWidth: 3, borderRightWidth: 3 }]} />
          </View>

          <View style={{ alignItems: "center", gap: 4 }}>
            <Text style={{ fontSize: 20, fontWeight: "700", color: colors.foreground, fontFamily: "Inter_700Bold" }}>
              {studentProfile?.name}
            </Text>
            <Text style={{ fontSize: 15, color: colors.primary, fontFamily: "Inter_600SemiBold" }}>
              {studentProfile?.universityId}
            </Text>
            <Text style={{ fontSize: 13, color: colors.mutedForeground, fontFamily: "Inter_400Regular" }}>
              {studentProfile?.department} · {studentProfile?.level}
            </Text>
          </View>

          <View style={{ backgroundColor: colors.muted, borderRadius: 20, paddingHorizontal: 14, paddingVertical: 6 }}>
            <Text style={{ fontSize: 12, color: colors.mutedForeground, fontFamily: "Inter_500Medium" }}>
              Live student QR for attendance check-in
            </Text>
          </View>
        </Card>

        <Card style={{ gap: 14 }}>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 2 }}>
            <Ionicons name="information-circle" size={20} color={colors.primary} />
            <Text style={{ fontSize: 15, fontWeight: "600", color: colors.foreground, fontFamily: "Inter_600SemiBold" }}>
              How to use
            </Text>
          </View>
          {[
          { icon: "scan-outline", text: "Show this QR code to your instructor during class." },
          { icon: "phone-portrait-outline", text: "Keep your phone brightness high for easier scanning." },
          { icon: "time-outline", text: "Staff can scan this code directly from the camera page." },
        ].map((item, i) => (
            <View key={i} style={{ flexDirection: "row", gap: 12, alignItems: "flex-start" }}>
              <View style={{ width: 32, height: 32, borderRadius: 10, backgroundColor: "#EEF2FF", alignItems: "center", justifyContent: "center" }}>
                <Ionicons name={item.icon as any} size={16} color={colors.primary} />
              </View>
              <Text style={{ flex: 1, fontSize: 13, color: colors.mutedForeground, fontFamily: "Inter_400Regular", lineHeight: 19 }}>
                {item.text}
              </Text>
            </View>
          ))}
        </Card>

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  qrContainer: {
    width: 240,
    height: 240,
    padding: 20,
    backgroundColor: "#FFFFFF",
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "#0F1B3C",
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.12,
    shadowRadius: 20,
    elevation: 8,
    position: "relative",
  },
  qrInner: {
    width: 200,
    height: 200,
  },
  emptyQr: {
    width: 200,
    height: 200,
    alignItems: "center",
    justifyContent: "center",
  },
  qrCorner: {
    position: "absolute",
    width: 24,
    height: 24,
    borderColor: "#2563EB",
  },
});
