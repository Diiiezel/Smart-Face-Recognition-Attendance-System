import { Card } from "@/components/UI";
import { ScreenHeader } from "@/components/ScreenHeader";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { Ionicons } from "@expo/vector-icons";
import QRCode from "react-native-qrcode-svg";
import React from "react";
import { ScrollView, StyleSheet, Text, View } from "react-native";

export default function MyQRCode() {
  const colors = useColors();
  const { studentProfile, qrPayload } = useApp();

  return (
    <View style={[styles.page, { backgroundColor: colors.background }]}>
      <ScreenHeader title="My QR Code" showBack subtitle="Show this to mark attendance" />
      <ScrollView contentContainerStyle={styles.shell} showsVerticalScrollIndicator={false}>
        <View style={styles.layout}>
          <Card style={styles.qrCard}>
            <View style={styles.qrHeader}>
              <View style={[styles.iconBox, { backgroundColor: colors.secondary }]}>
                <Ionicons name="qr-code-outline" size={22} color={colors.primary} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.cardTitle, { color: colors.foreground }]}>Live student QR</Text>
                <Text style={[styles.cardSubtitle, { color: colors.mutedForeground }]}>
                  Staff can scan this code from the attendance camera flow.
                </Text>
              </View>
            </View>

            <View style={styles.qrStage}>
              <View style={styles.qrContainer}>
                <View style={styles.qrInner}>
                  {qrPayload ? (
                    <QRCode value={qrPayload} size={220} backgroundColor="#FFFFFF" color="#0F172A" />
                  ) : (
                    <View style={styles.emptyQr}>
                      <Ionicons name="qr-code-outline" size={76} color={colors.mutedForeground} />
                    </View>
                  )}
                </View>
                <View style={[styles.qrCorner, styles.cornerTopLeft]} />
                <View style={[styles.qrCorner, styles.cornerTopRight]} />
                <View style={[styles.qrCorner, styles.cornerBottomLeft]} />
                <View style={[styles.qrCorner, styles.cornerBottomRight]} />
              </View>
            </View>

            <View style={styles.identityBlock}>
              <Text style={[styles.name, { color: colors.foreground }]}>
                {studentProfile?.name}
              </Text>
              <Text style={[styles.universityId, { color: colors.primary }]}>
                {studentProfile?.universityId}
              </Text>
              <Text style={[styles.meta, { color: colors.mutedForeground }]}>
                {studentProfile?.department} · {studentProfile?.level}
              </Text>
            </View>
          </Card>

          <View style={styles.sideColumn}>
            <Card style={styles.infoCard}>
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>How to use</Text>
              {[
                { icon: "scan-outline", text: "Show this QR code to your instructor during class." },
                { icon: "phone-portrait-outline", text: "Keep your screen brightness high for reliable scanning." },
                { icon: "time-outline", text: "Use the current QR only during the active attendance window." },
              ].map((item) => (
                <View key={item.text} style={styles.instructionRow}>
                  <View style={[styles.instructionIcon, { backgroundColor: colors.secondary }]}>
                    <Ionicons name={item.icon as any} size={16} color={colors.primary} />
                  </View>
                  <Text style={[styles.instructionText, { color: colors.mutedForeground }]}>
                    {item.text}
                  </Text>
                </View>
              ))}
            </Card>

            <Card style={styles.statusCard}>
              <View style={styles.statusTop}>
                <View style={styles.statusDot} />
                <Text style={[styles.statusText, { color: colors.foreground }]}>
                  {qrPayload ? "QR payload ready" : "Waiting for QR payload"}
                </Text>
              </View>
              <Text style={[styles.statusHelp, { color: colors.mutedForeground }]}>
                This screen uses the existing QR payload from the app context. No extra data is generated here.
              </Text>
            </Card>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  cardSubtitle: {
    fontFamily: "Inter_400Regular",
    fontSize: 13,
    marginTop: 3,
  },
  cardTitle: {
    fontFamily: "Inter_700Bold",
    fontSize: 20,
    fontWeight: "700",
  },
  cornerBottomLeft: {
    borderBottomWidth: 3,
    borderLeftWidth: 3,
    bottom: 0,
    left: 0,
  },
  cornerBottomRight: {
    borderBottomWidth: 3,
    borderRightWidth: 3,
    bottom: 0,
    right: 0,
  },
  cornerTopLeft: {
    borderLeftWidth: 3,
    borderTopWidth: 3,
    left: 0,
    top: 0,
  },
  cornerTopRight: {
    borderRightWidth: 3,
    borderTopWidth: 3,
    right: 0,
    top: 0,
  },
  emptyQr: {
    alignItems: "center",
    height: 220,
    justifyContent: "center",
    width: 220,
  },
  iconBox: {
    alignItems: "center",
    borderRadius: 14,
    height: 44,
    justifyContent: "center",
    width: 44,
  },
  identityBlock: {
    alignItems: "center",
    gap: 5,
  },
  infoCard: {
    gap: 16,
  },
  instructionIcon: {
    alignItems: "center",
    borderRadius: 12,
    height: 34,
    justifyContent: "center",
    width: 34,
  },
  instructionRow: {
    alignItems: "flex-start",
    flexDirection: "row",
    gap: 12,
  },
  instructionText: {
    flex: 1,
    fontFamily: "Inter_400Regular",
    fontSize: 14,
    lineHeight: 20,
  },
  layout: {
    alignItems: "start",
    display: "grid",
    gap: 24,
    gridTemplateColumns: "minmax(320px, 1fr) minmax(280px, 360px)",
    maxWidth: 1080,
    width: "100%",
  } as any,
  meta: {
    fontFamily: "Inter_400Regular",
    fontSize: 13,
  },
  name: {
    fontFamily: "Inter_700Bold",
    fontSize: 22,
    fontWeight: "700",
  },
  page: {
    flex: 1,
  },
  qrCard: {
    alignItems: "center",
    gap: 24,
    width: "100%",
  },
  qrContainer: {
    alignItems: "center",
    backgroundColor: "#FFFFFF",
    borderRadius: 24,
    boxShadow: "0 18px 40px rgba(13, 27, 62, 0.12)",
    height: 284,
    justifyContent: "center",
    padding: 32,
    position: "relative",
    width: 284,
  } as any,
  qrCorner: {
    borderColor: "#2563EB",
    height: 28,
    position: "absolute",
    width: 28,
  },
  qrHeader: {
    alignItems: "center",
    alignSelf: "stretch",
    flexDirection: "row",
    gap: 14,
  },
  qrInner: {
    height: 220,
    width: 220,
  },
  qrStage: {
    alignItems: "center",
    alignSelf: "stretch",
    backgroundColor: "#F8FAFC",
    borderColor: "#E8ECF4",
    borderRadius: 24,
    borderWidth: 1,
    padding: 28,
  },
  sectionTitle: {
    fontFamily: "Inter_700Bold",
    fontSize: 18,
    fontWeight: "700",
  },
  shell: {
    alignItems: "center",
    padding: 28,
    paddingBottom: 44,
  },
  sideColumn: {
    gap: 16,
    width: "100%",
  },
  statusCard: {
    gap: 10,
  },
  statusDot: {
    backgroundColor: "#10B981",
    borderRadius: 5,
    height: 10,
    width: 10,
  },
  statusHelp: {
    fontFamily: "Inter_400Regular",
    fontSize: 13,
    lineHeight: 19,
  },
  statusText: {
    fontFamily: "Inter_700Bold",
    fontSize: 14,
    fontWeight: "700",
  },
  statusTop: {
    alignItems: "center",
    flexDirection: "row",
    gap: 8,
  },
  universityId: {
    fontFamily: "Inter_700Bold",
    fontSize: 16,
    fontWeight: "700",
  },
});
