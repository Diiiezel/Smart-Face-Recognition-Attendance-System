import { Badge, Button, Card } from "@/components/UI";
import { ScreenHeader } from "@/components/ScreenHeader";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { coursesService } from "@/services/coursesService";
import { Ionicons } from "@expo/vector-icons";
import React, { useEffect, useMemo, useState } from "react";
import {
  FlatList,
  Modal,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import type { Course } from "@/context/AppContext";

const COURSE_COLORS = ["#DBEAFE", "#EEF2FF", "#D1FAE5", "#FEF3C7"];
const COURSE_ICON_COLORS = ["#2563EB", "#6366F1", "#10B981", "#F59E0B"];

function normalizeCourse(course: any): Course {
  const departments = Array.isArray(course.departments)
    ? course.departments.filter(Boolean)
    : String(course.department || course.semester || course.doctor?.major || "")
        .split(",")
        .map((item) => item.trim())
        .filter((item) => item === "CS" || item === "IS");
  const levels = Array.isArray(course.levels)
    ? course.levels.filter(Boolean)
    : course.level
      ? [course.level]
      : [];

  return {
    id: String(course.id),
    code: course.code,
    name: course.name,
    instructor: course.doctor?.name || "Doctor",
    department: course.department || departments.join(", ") || "General",
    level: levels.join(", ") || course.level || "N/A",
    departments,
    levels,
    enrolledCount: Number(course.enrollments_count || 0),
    schedule: course.semester || "TBD",
  };
}

function CourseCard({
  course,
  index,
  enrolled,
  onPress,
}: {
  course: Course;
  index: number;
  enrolled: boolean;
  onPress?: () => void;
}) {
  const colors = useColors();

  return (
    <Card
      style={{
        padding: 0,
        overflow: "hidden",
        borderColor: enrolled ? "#93C5FD" : colors.border,
        borderWidth: enrolled ? 1.5 : 1,
      }}
      onPress={onPress}
    >
      <View style={[styles.courseHeader, { backgroundColor: COURSE_COLORS[index % 4] }]}>
        <View style={[styles.courseIconBg, { backgroundColor: COURSE_ICON_COLORS[index % 4] }]}>
          <Ionicons name="book" size={22} color="#FFFFFF" />
        </View>
        <View style={{ flex: 1 }}>
          <Text
            style={{
              fontSize: 13,
              fontWeight: "700",
              color: COURSE_ICON_COLORS[index % 4],
              fontFamily: "Inter_700Bold",
            }}
          >
            {course.code}
          </Text>
          <Text style={{ fontSize: 10, color: "#64748B", fontFamily: "Inter_400Regular" }}>
            {course.department}
          </Text>
        </View>
        <View style={styles.headerMeta}>
          <View
            style={{
              backgroundColor: enrolled ? "#DBEAFE" : "rgba(255,255,255,0.7)",
              borderRadius: 12,
              paddingHorizontal: 8,
              paddingVertical: 3,
            }}
          >
            <Text style={{ fontSize: 11, color: "#374151", fontFamily: "Inter_600SemiBold" }}>
              {course.level}
            </Text>
          </View>
          {enrolled ? <Badge label="Enrolled" variant="primary" /> : null}
        </View>
      </View>
      <View style={{ padding: 14, gap: 10 }}>
        <Text
          style={{
            fontSize: 16,
            fontWeight: "700",
            color: colors.foreground,
            fontFamily: "Inter_700Bold",
          }}
        >
          {course.name}
        </Text>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
          <View style={[styles.infoChip, { backgroundColor: colors.muted }]}>
            <Ionicons name="person-outline" size={12} color={colors.mutedForeground} />
            <Text style={{ fontSize: 12, color: colors.mutedForeground, fontFamily: "Inter_400Regular" }}>
              {course.instructor}
            </Text>
          </View>
          <View style={[styles.infoChip, { backgroundColor: colors.muted }]}>
            <Ionicons name="time-outline" size={12} color={colors.mutedForeground} />
            <Text style={{ fontSize: 12, color: colors.mutedForeground, fontFamily: "Inter_400Regular" }}>
              {course.schedule}
            </Text>
          </View>
        </View>
      </View>
    </Card>
  );
}

export default function MyCourses() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { courses, studentProfile, refreshData } = useApp();
  const [search, setSearch] = useState("");
  const [availableCourses, setAvailableCourses] = useState<Course[]>([]);
  const [showPicker, setShowPicker] = useState(false);
  const [isAdding, setIsAdding] = useState(false);
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  useEffect(() => {
    void (async () => {
      const nextCourses = await coursesService.getStudentAvailableCourses();
      setAvailableCourses((nextCourses || []).map(normalizeCourse));
    })();
  }, [courses.length, studentProfile?.department, studentProfile?.level]);

  const enrolledCodes = useMemo(() => new Set(courses.map((course) => course.code)), [courses]);

  const filteredEnrolled = useMemo(
    () =>
      courses.filter(
        (course) =>
          course.name.toLowerCase().includes(search.toLowerCase()) ||
          course.code.toLowerCase().includes(search.toLowerCase()) ||
          course.instructor.toLowerCase().includes(search.toLowerCase()),
      ),
    [courses, search],
  );

  const remainingCourses = useMemo(
    () => availableCourses.filter((course) => !enrolledCodes.has(course.code)),
    [availableCourses, enrolledCodes],
  );
  const hasEnrolledCourses = courses.length > 0;
  const emptyAvailableTitle = hasEnrolledCourses
    ? "All matching courses selected"
    : "No available courses for your current level";
  const emptyAvailableMessage = hasEnrolledCourses
    ? "You have already enrolled in all available courses for your current level."
    : "Ask your doctor to create a course for your current level, then refresh this screen.";

  const handleEnroll = async (course: Course) => {
    setIsAdding(true);
    try {
      await coursesService.enrollStudent(course.code);
      await refreshData();
      const nextCourses = await coursesService.getStudentAvailableCourses();
      setAvailableCourses((nextCourses || []).map(normalizeCourse));
      setShowPicker(false);
    } finally {
      setIsAdding(false);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <ScreenHeader
        title="My Courses"
        showBack
        subtitle={`${courses.length} enrolled courses`}
      />
      <View style={styles.searchContainer}>
        <View style={[styles.searchBox, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Ionicons name="search-outline" size={18} color={colors.mutedForeground} />
          <TextInput
            style={{ flex: 1, fontSize: 15, color: colors.foreground, fontFamily: "Inter_400Regular" }}
            placeholder="Search courses..."
            placeholderTextColor={colors.mutedForeground}
            value={search}
            onChangeText={setSearch}
          />
        </View>
      </View>

      <FlatList
        data={filteredEnrolled}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ padding: 16, paddingBottom: bottomPad + 110, gap: 12 }}
        renderItem={({ item, index }) => (
          <CourseCard course={item} index={index} enrolled />
        )}
        ListEmptyComponent={
          <View style={{ alignItems: "center", paddingTop: 60, gap: 12 }}>
            <Ionicons name="book-outline" size={48} color={colors.mutedForeground} />
            <Text style={{ fontSize: 16, color: colors.mutedForeground, fontFamily: "Inter_500Medium" }}>
              No enrolled courses yet
            </Text>
            <Text
              style={{
                fontSize: 13,
                color: colors.mutedForeground,
                fontFamily: "Inter_400Regular",
                textAlign: "center",
                maxWidth: 280,
              }}
            >
              Tap the + button to add courses available for your major and year.
            </Text>
          </View>
        }
        showsVerticalScrollIndicator={false}
      />

      <Pressable
        onPress={() => setShowPicker(true)}
        style={[styles.addButton, { bottom: bottomPad + 18, backgroundColor: colors.primary }]}
      >
        <Ionicons name="add" size={28} color="#FFFFFF" />
      </Pressable>

      <Modal visible={showPicker} transparent animationType="slide" onRequestClose={() => setShowPicker(false)}>
        <View style={styles.modalOverlay}>
          <View style={[styles.modalCard, { backgroundColor: colors.card }]}>
            <View style={styles.modalHeader}>
              <View>
                <Text style={[styles.modalTitle, { color: colors.foreground }]}>Available Courses</Text>
                <Text style={[styles.modalSubtitle, { color: colors.mutedForeground }]}>
                  Matching {studentProfile?.department || "your major"} · {studentProfile?.level || "your year"}
                </Text>
              </View>
              <Pressable onPress={() => setShowPicker(false)} style={[styles.closeButton, { backgroundColor: colors.muted }]}>
                <Ionicons name="close" size={18} color={colors.foreground} />
              </Pressable>
            </View>

            {remainingCourses.length === 0 ? (
              <View style={styles.emptyPicker}>
                <Ionicons name="checkmark-done-circle-outline" size={42} color={colors.mutedForeground} />
                <Text style={[styles.emptyPickerTitle, { color: colors.foreground }]}>{emptyAvailableTitle}</Text>
                <Text style={[styles.emptyPickerSubtitle, { color: colors.mutedForeground }]}>
                  {emptyAvailableMessage}
                </Text>
              </View>
            ) : (
              <FlatList
                data={remainingCourses}
                keyExtractor={(item) => `available-${item.id}`}
                contentContainerStyle={{ gap: 12, paddingBottom: 8 }}
                renderItem={({ item, index }) => (
                  <View style={{ gap: 10 }}>
                    <CourseCard course={item} index={index} enrolled={false} />
                    <Button
                      title="Enroll"
                      onPress={() => void handleEnroll(item)}
                      loading={isAdding}
                      disabled={isAdding}
                      fullWidth={false}
                    />
                  </View>
                )}
                showsVerticalScrollIndicator={false}
              />
            )}
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  searchContainer: {
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  searchBox: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    borderRadius: 14,
    borderWidth: 1.5,
  },
  courseHeader: {
    flexDirection: "row",
    alignItems: "center",
    padding: 14,
    gap: 12,
  },
  courseIconBg: {
    width: 44,
    height: 44,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  headerMeta: {
    alignItems: "flex-end",
    gap: 8,
  },
  infoChip: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 8,
  },
  addButton: {
    position: "absolute",
    left: 20,
    width: 58,
    height: 58,
    borderRadius: 29,
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "#0F1B3C",
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.16,
    shadowRadius: 18,
    elevation: 8,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(15, 23, 42, 0.45)",
    justifyContent: "flex-end",
  },
  modalCard: {
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: 20,
    maxHeight: "78%",
    gap: 16,
  },
  modalHeader: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
    gap: 12,
  },
  modalTitle: {
    fontSize: 20,
    fontFamily: "Inter_700Bold",
  },
  modalSubtitle: {
    fontSize: 12,
    fontFamily: "Inter_400Regular",
    marginTop: 2,
  },
  closeButton: {
    width: 34,
    height: 34,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  emptyPicker: {
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 40,
    gap: 10,
  },
  emptyPickerTitle: {
    fontSize: 16,
    fontFamily: "Inter_700Bold",
  },
  emptyPickerSubtitle: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    textAlign: "center",
    maxWidth: 280,
  },
});
