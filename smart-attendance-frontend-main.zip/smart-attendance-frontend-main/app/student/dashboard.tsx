import { Badge, Card, SectionHeader, StatCard } from "@/components/UI";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import React from "react";
import { Platform, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const QUICK_ACTIONS = [
  { label: "Register Face", icon: "scan", route: "/student/face-enrollment", color: "#2563EB", bg: "#DBEAFE" },
  { label: "My Courses", icon: "book", route: "/student/courses", color: "#6366F1", bg: "#EEF2FF" },
  { label: "Attendance", icon: "calendar", route: "/student/attendance-history", color: "#10B981", bg: "#D1FAE5" },
  { label: "My QR Code", icon: "qr-code", route: "/student/qr-code", color: "#F59E0B", bg: "#FEF3C7" },
];

export default function StudentDashboard() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { studentProfile, attendanceHistory, courses } = useApp();

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  const presentCount = attendanceHistory.filter((r) => r.status === "present").length;
  const totalCount = attendanceHistory.length;
  const attendanceRate = totalCount > 0 ? Math.round((presentCount / totalCount) * 100) : 0;

  const recentRecords = attendanceHistory.slice(0, 3);

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.background }}
      showsVerticalScrollIndicator={false}
      contentContainerStyle={{ paddingBottom: bottomPad + 20 }}
    >
      <LinearGradient
        colors={["#0B1530", "#0F1B3C", "#1E3A7B"]}
        start={{ x: 0.1, y: 0 }}
        end={{ x: 0.9, y: 1 }}
        style={[styles.header, { paddingTop: topPad + 18 }]}
      >
        <View style={styles.headerTop}>
          <View style={{ flex: 1 }}>
            <Text style={styles.greeting}>Good morning,</Text>
            <Text style={styles.name} numberOfLines={1}>
              {studentProfile?.name ?? "Student"}
            </Text>
            <View style={styles.subInfoRow}>
              <Text style={styles.subInfo}>
                {studentProfile?.universityId}
              </Text>
              {studentProfile?.department ? (
                <>
                  <View style={styles.subInfoDot} />
                  <Text style={styles.subInfo}>{studentProfile.department}</Text>
                </>
              ) : null}
            </View>
          </View>
          <Pressable
            onPress={() => router.push("/student/profile")}
            style={styles.avatarCircle}
          >
            <Ionicons name="person" size={24} color="#2563EB" />
          </Pressable>
        </View>

        <View style={styles.statsRow}>
          <View style={styles.statPill}>
            <Text style={styles.statPillValue}>{attendanceRate}%</Text>
            <Text style={styles.statPillLabel}>Attendance Rate</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statPill}>
            <Text style={styles.statPillValue}>{courses.length}</Text>
            <Text style={styles.statPillLabel}>Enrolled Courses</Text>
          </View>
        </View>
      </LinearGradient>

      <View style={styles.content}>
        {!studentProfile?.faceEnrolled && (
          <Pressable onPress={() => router.push("/student/face-enrollment")}>
            <View style={styles.warningBanner}>
              <View style={styles.warningIconBox}>
                <Ionicons name="scan" size={20} color="#92400E" />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.warningTitle}>Register your face</Text>
                <Text style={styles.warningDesc}>Required for face recognition attendance</Text>
              </View>
              <Ionicons name="chevron-forward" size={16} color="#92400E" />
            </View>
          </Pressable>
        )}

        <View>
          <SectionHeader title="Quick Actions" />
          <View style={styles.actionsGrid}>
            {QUICK_ACTIONS.map((action) => (
              <Pressable
                key={action.label}
                onPress={() => {
                  Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                  router.push(action.route as any);
                }}
                style={({ pressed }) => [
                  styles.actionCard,
                  {
                    backgroundColor: colors.card,
                    borderColor: colors.border,
                    opacity: pressed ? 0.85 : 1,
                    transform: [{ scale: pressed ? 0.95 : 1 }],
                  },
                ]}
              >
                <View style={[styles.actionIcon, { backgroundColor: action.bg }]}>
                  <Ionicons name={action.icon as any} size={22} color={action.color} />
                </View>
                <Text
                  style={{
                    fontSize: 12,
                    fontWeight: "600",
                    color: colors.foreground,
                    fontFamily: "Inter_600SemiBold",
                    textAlign: "center",
                    lineHeight: 16,
                  }}
                >
                  {action.label}
                </Text>
              </Pressable>
            ))}
          </View>
        </View>

        <View>
          <SectionHeader
            title="Recent Attendance"
            action="View All"
            onAction={() => router.push("/student/attendance-history")}
          />
          <View style={{ gap: 8 }}>
            {recentRecords.map((record) => (
              <Card key={record.id} style={{ padding: 14 }}>
                <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
                  <View
                    style={[
                      styles.statusDot,
                      {
                        backgroundColor: record.status === "present" ? "#D1FAE5" : "#FEE2E2",
                      },
                    ]}
                  >
                    <Ionicons
                      name={record.status === "present" ? "checkmark" : "close"}
                      size={13}
                      color={record.status === "present" ? "#10B981" : "#EF4444"}
                    />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text
                      style={{
                        fontSize: 14,
                        fontWeight: "600",
                        color: colors.foreground,
                        fontFamily: "Inter_600SemiBold",
                      }}
                    >
                      {record.courseName}
                    </Text>
                    <Text
                      style={{
                        fontSize: 12,
                        color: colors.mutedForeground,
                        fontFamily: "Inter_400Regular",
                        marginTop: 1,
                      }}
                    >
                      {record.courseCode} · {record.date}
                    </Text>
                  </View>
                  <Badge
                    label={record.status.charAt(0).toUpperCase() + record.status.slice(1)}
                    variant={record.status === "present" ? "success" : "danger"}
                  />
                </View>
              </Card>
            ))}
          </View>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: 20,
    paddingBottom: 28,
    borderBottomLeftRadius: 28,
    borderBottomRightRadius: 28,
    gap: 20,
  },
  headerTop: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 12,
  },
  greeting: {
    fontSize: 13,
    color: "rgba(255,255,255,0.55)",
    fontFamily: "Inter_400Regular",
  },
  name: {
    fontSize: 22,
    fontWeight: "700",
    color: "#FFFFFF",
    fontFamily: "Inter_700Bold",
    letterSpacing: -0.4,
    marginTop: 1,
  },
  subInfoRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    marginTop: 3,
  },
  subInfo: {
    fontSize: 12,
    color: "rgba(255,255,255,0.5)",
    fontFamily: "Inter_400Regular",
  },
  subInfoDot: {
    width: 3,
    height: 3,
    borderRadius: 2,
    backgroundColor: "rgba(255,255,255,0.3)",
  },
  avatarCircle: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: "#FFFFFF",
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.12,
    shadowRadius: 8,
    elevation: 6,
  },
  statsRow: {
    flexDirection: "row",
    backgroundColor: "rgba(255,255,255,0.09)",
    borderRadius: 16,
    padding: 16,
    alignItems: "center",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.08)",
  },
  statPill: {
    flex: 1,
    alignItems: "center",
    gap: 2,
  },
  statPillValue: {
    fontSize: 21,
    fontWeight: "700",
    color: "#FFFFFF",
    fontFamily: "Inter_700Bold",
    letterSpacing: -0.5,
  },
  statPillLabel: {
    fontSize: 10,
    color: "rgba(255,255,255,0.5)",
    fontFamily: "Inter_400Regular",
    textAlign: "center",
  },
  statDivider: {
    width: 1,
    height: 32,
    backgroundColor: "rgba(255,255,255,0.15)",
  },
  content: {
    padding: 20,
    gap: 24,
  },
  warningBanner: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    backgroundColor: "#FFFBEB",
    borderRadius: 14,
    padding: 14,
    borderWidth: 1,
    borderColor: "#FCD34D",
  },
  warningIconBox: {
    width: 40,
    height: 40,
    borderRadius: 11,
    backgroundColor: "#FEF3C7",
    alignItems: "center",
    justifyContent: "center",
  },
  warningTitle: {
    fontSize: 14,
    fontWeight: "700",
    color: "#92400E",
    fontFamily: "Inter_700Bold",
  },
  warningDesc: {
    fontSize: 12,
    color: "#B45309",
    fontFamily: "Inter_400Regular",
    marginTop: 1,
  },
  actionsGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 12,
  },
  actionCard: {
    width: "47%",
    borderRadius: 16,
    padding: 16,
    alignItems: "center",
    gap: 10,
    borderWidth: 1,
    shadowColor: "#0D1B3E",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  actionIcon: {
    width: 48,
    height: 48,
    borderRadius: 13,
    alignItems: "center",
    justifyContent: "center",
  },
  statusDot: {
    width: 30,
    height: 30,
    borderRadius: 9,
    alignItems: "center",
    justifyContent: "center",
  },
});
