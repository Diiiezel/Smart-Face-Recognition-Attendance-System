import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import React, { useEffect, useRef } from "react";
import { Animated, Platform, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

export default function SplashScreen() {
  const { isAuthenticated, role, isReady } = useApp();
  const colors = useColors();
  const insets = useSafeAreaInsets();

  const logoScale = useRef(new Animated.Value(0.6)).current;
  const logoOpacity = useRef(new Animated.Value(0)).current;
  const subtitleOpacity = useRef(new Animated.Value(0)).current;
  const ringScale = useRef(new Animated.Value(0.5)).current;
  const ringOpacity = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (!isReady) {
      return;
    }

    Animated.sequence([
      Animated.parallel([
        Animated.timing(logoOpacity, { toValue: 1, duration: 600, useNativeDriver: true }),
        Animated.spring(logoScale, { toValue: 1, friction: 6, tension: 80, useNativeDriver: true }),
        Animated.timing(ringOpacity, { toValue: 0.3, duration: 800, useNativeDriver: true }),
        Animated.spring(ringScale, { toValue: 1, friction: 5, tension: 60, useNativeDriver: true }),
      ]),
      Animated.timing(subtitleOpacity, { toValue: 1, duration: 400, useNativeDriver: true }),
      Animated.delay(1200),
    ]).start(() => {
      if (isAuthenticated && role) {
        router.replace(role === "student" ? "/student/dashboard" : "/staff/dashboard");
      } else {
        router.replace("/role-select");
      }
    });
  }, [isAuthenticated, isReady, role]);

  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  return (
    <LinearGradient
      colors={["#0B1530", "#0F1B3C", "#1E3A7B"]}
      start={{ x: 0.1, y: 0 }}
      end={{ x: 0.9, y: 1 }}
      style={styles.container}
    >
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
        <Animated.View
          style={{ transform: [{ scale: ringScale }], opacity: ringOpacity, position: "absolute" }}
        >
          <View style={styles.ring1} />
        </Animated.View>
        <Animated.View
          style={{ transform: [{ scale: ringScale }], opacity: ringOpacity, position: "absolute" }}
        >
          <View style={styles.ring2} />
        </Animated.View>
        <Animated.View
          style={{ transform: [{ scale: ringScale }], opacity: ringOpacity, position: "absolute" }}
        >
          <View style={styles.ring3} />
        </Animated.View>

        <Animated.View
          style={[styles.logoContainer, { opacity: logoOpacity, transform: [{ scale: logoScale }] }]}
        >
          <View style={styles.iconBg}>
            <Ionicons name="scan" size={50} color="#2563EB" />
          </View>
        </Animated.View>

        <Animated.View style={[styles.textContainer, { opacity: subtitleOpacity }]}>
          <Text style={styles.appName}>Smart Attendance</Text>
          <Text style={styles.subtitle}>Face Recognition Attendance System</Text>
          <View style={styles.divider} />
          <Text style={styles.university}>University Management Platform</Text>
        </Animated.View>
      </View>

    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  ring1: {
    width: 240,
    height: 240,
    borderRadius: 120,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.15)",
  },
  ring2: {
    width: 320,
    height: 320,
    borderRadius: 160,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.08)",
    position: "absolute",
    top: -40,
    left: -40,
  },
  ring3: {
    width: 400,
    height: 400,
    borderRadius: 200,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.04)",
    position: "absolute",
    top: -80,
    left: -80,
  },
  logoContainer: {
    marginBottom: 36,
  },
  iconBg: {
    width: 104,
    height: 104,
    borderRadius: 26,
    backgroundColor: "#FFFFFF",
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 16 },
    shadowOpacity: 0.28,
    shadowRadius: 28,
    elevation: 24,
  },
  textContainer: {
    alignItems: "center",
    gap: 6,
  },
  appName: {
    fontSize: 28,
    fontWeight: "700",
    color: "#FFFFFF",
    fontFamily: "Inter_700Bold",
    letterSpacing: -0.5,
  },
  subtitle: {
    fontSize: 14,
    color: "rgba(255,255,255,0.65)",
    fontFamily: "Inter_400Regular",
    textAlign: "center",
  },
  divider: {
    width: 32,
    height: 1.5,
    backgroundColor: "rgba(255,255,255,0.25)",
    borderRadius: 1,
    marginVertical: 6,
  },
  university: {
    fontSize: 11,
    color: "rgba(255,255,255,0.4)",
    fontFamily: "Inter_400Regular",
    letterSpacing: 1.5,
    textTransform: "uppercase",
  },
});
