import { useApp } from "@/context/AppContext";
import { Button, InputField } from "@/components/UI";
import { useColors } from "@/hooks/useColors";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import { router, useLocalSearchParams } from "expo-router";
import React, { useState } from "react";
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

export default function LoginScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { role, login, isLoading } = useApp();
  const params = useLocalSearchParams<{ role?: string }>();
  const activeRole = (params.role || role) as "student" | "staff";

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");

  const isStaff = activeRole === "staff";
  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  const handleLogin = async () => {
    if (!email || !password) {
      setError("Please fill in all fields.");
      return;
    }
    setError("");
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

    try {
      await login(email, password, activeRole);
      router.replace(isStaff ? "/staff/dashboard" : "/student/dashboard");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to sign in.");
    }
  };

  const handleEmailChange = (value: string) => {
    setEmail(value);
    if (error) setError("");
  };

  const handlePasswordChange = (value: string) => {
    setPassword(value);
    if (error) setError("");
  };

  const handleForgotPassword = () => {
    router.push({
      pathname: "/auth/forgot-password",
      params: { role: activeRole },
    } as any);
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <LinearGradient
        colors={
          isStaff ? ["#3730A3", "#4F46E5"] : ["#0F1B3C", "#1E3A7B"]
        }
        start={{ x: 0.1, y: 0 }}
        end={{ x: 0.9, y: 1 }}
        style={[styles.headerGrad, { paddingTop: topPad + 14 }]}
      >
        <Pressable onPress={() => router.back()} style={styles.backBtn}>
          <Ionicons name="chevron-back" size={20} color="#FFF" />
        </Pressable>
        <View style={styles.headerBody}>
          <View style={styles.headerIcon}>
            <Ionicons
              name={isStaff ? "briefcase" : "person"}
              size={28}
              color={isStaff ? "#6366F1" : "#2563EB"}
            />
          </View>
          <View style={{ gap: 4 }}>
            <Text style={styles.headerTitle}>
              {isStaff ? "Staff Login" : "Student Login"}
            </Text>
            <Text style={styles.headerSubtitle}>
              Sign in to your {isStaff ? "staff" : "student"} account
            </Text>
          </View>
        </View>
      </LinearGradient>

      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        style={{ flex: 1 }}
      >
        <ScrollView
          contentContainerStyle={[styles.form, { paddingBottom: bottomPad + 20 }]}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.formCard}>
            <InputField
              label="Email Address"
              placeholder="your@university.edu"
              value={email}
              onChangeText={handleEmailChange}
              keyboardType="email-address"
              autoCapitalize="none"
              icon={
                <Ionicons
                  name="mail-outline"
                  size={17}
                  color={colors.mutedForeground}
                />
              }
            />
            <InputField
              label="Password"
              placeholder="Enter your password"
              value={password}
              onChangeText={handlePasswordChange}
              secureTextEntry={!showPassword}
              icon={
                <Ionicons
                  name="lock-closed-outline"
                  size={17}
                  color={colors.mutedForeground}
                />
              }
              rightElement={
                <Pressable onPress={() => setShowPassword(!showPassword)}>
                  <Ionicons
                    name={showPassword ? "eye-off-outline" : "eye-outline"}
                    size={17}
                    color={colors.mutedForeground}
                  />
                </Pressable>
              }
            />

            <Pressable onPress={handleForgotPassword} style={styles.forgotPasswordBtn}>
              <Text style={[styles.forgotPasswordText, { color: colors.primary }]}>
                Forgot Password?
              </Text>
            </Pressable>

            {error ? (
              <View style={styles.errorBox}>
                <Ionicons
                  name="alert-circle"
                  size={15}
                  color={colors.destructive}
                />
                <Text style={[styles.errorText, { color: colors.destructive }]}>
                  {error}
                </Text>
              </View>
            ) : null}

            <Button
              title="Sign In"
              onPress={handleLogin}
              loading={isLoading}
              size="lg"
            />
          </View>

          <View style={styles.signupRow}>
            <Text
              style={{
                color: colors.mutedForeground,
                fontSize: 14,
                fontFamily: "Inter_400Regular",
              }}
            >
              Don't have an account?
            </Text>
            <Pressable
              onPress={() => router.push(`/auth/signup?role=${activeRole}`)}
            >
              <Text
                style={{
                  color: colors.primary,
                  fontSize: 14,
                  fontWeight: "600",
                  fontFamily: "Inter_600SemiBold",
                }}
              >
                Sign Up
              </Text>
            </Pressable>
          </View>

          <Pressable
            onPress={() => router.replace("/role-select")}
            style={{ alignItems: "center", marginTop: 8 }}
          >
            <Text
              style={{
                color: colors.mutedForeground,
                fontSize: 13,
                fontFamily: "Inter_400Regular",
              }}
            >
              Switch role
            </Text>
          </Pressable>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  headerGrad: {
    paddingHorizontal: 20,
    paddingBottom: 36,
    borderBottomLeftRadius: 28,
    borderBottomRightRadius: 28,
    gap: 18,
  },
  backBtn: {
    width: 34,
    height: 34,
    borderRadius: 10,
    backgroundColor: "rgba(255,255,255,0.12)",
    alignItems: "center",
    justifyContent: "center",
    alignSelf: "flex-start",
  },
  headerBody: {
    flexDirection: "row",
    alignItems: "center",
    gap: 14,
  },
  headerIcon: {
    width: 56,
    height: 56,
    borderRadius: 16,
    backgroundColor: "#FFFFFF",
    alignItems: "center",
    justifyContent: "center",
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: "700",
    color: "#FFFFFF",
    fontFamily: "Inter_700Bold",
    letterSpacing: -0.4,
  },
  headerSubtitle: {
    fontSize: 13,
    color: "rgba(255,255,255,0.65)",
    fontFamily: "Inter_400Regular",
  },
  form: {
    padding: 20,
    gap: 16,
  },
  formCard: {
    backgroundColor: "#FFFFFF",
    borderRadius: 20,
    padding: 22,
    gap: 18,
    borderWidth: 1,
    borderColor: "#E8ECF4",
    shadowColor: "#0D1B3E",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.06,
    shadowRadius: 16,
    elevation: 4,
  },
  errorBox: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    backgroundColor: "#FEF2F2",
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: "#FECACA",
  },
  errorText: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    flex: 1,
  },
  signupRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
  },
  forgotPasswordBtn: {
    alignSelf: "flex-end",
    marginTop: -8,
  },
  forgotPasswordText: {
    fontSize: 13,
    fontFamily: "Inter_600SemiBold",
  },
});
