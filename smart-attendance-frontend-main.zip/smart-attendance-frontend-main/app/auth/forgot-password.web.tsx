import { Button, Card, InputField } from "@/components/UI";
import { useColors } from "@/hooks/useColors";
import { authService, getErrorMessage } from "@/services/authService";
import { Ionicons } from "@expo/vector-icons";
import { router, useLocalSearchParams } from "expo-router";
import React, { useState } from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

export default function ForgotPasswordScreen() {
  const colors = useColors();
  const params = useLocalSearchParams<{ role?: string }>();
  const isStaff = params.role === "staff";
  const roleParam = isStaff ? "staff" : "student";
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [step, setStep] = useState<"email" | "reset" | "done">("email");
  const [message, setMessage] = useState("");
  const [messageType, setMessageType] = useState<"error" | "success" | null>(null);
  const [isSending, setIsSending] = useState(false);

  const handleSendInstructions = async () => {
    if (!email.trim()) {
      setMessageType("error");
      setMessage("Please enter your email address.");
      return;
    }

    setIsSending(true);

    try {
      const response = await authService.forgotPassword(email.trim());
      setMessageType("success");
      setMessage(response.message || "If this email exists, a reset code has been sent.");
      setStep("reset");
    } catch (error) {
      setMessageType("error");
      setMessage(getErrorMessage(error));
    } finally {
      setIsSending(false);
    }
  };

  const handleResetPassword = async () => {
    if (!otp.trim() || !password || !confirmPassword) {
      setMessageType("error");
      setMessage("Please enter the reset code and new password.");
      return;
    }

    if (password !== confirmPassword) {
      setMessageType("error");
      setMessage("Passwords do not match.");
      return;
    }

    setIsSending(true);

    try {
      const response = await authService.resetPassword({
        email: email.trim(),
        otp: otp.trim(),
        password,
        password_confirmation: confirmPassword,
      });
      setMessageType("success");
      setMessage(response.message || "Password reset successfully. You can now sign in.");
      setStep("done");
      setOtp("");
      setPassword("");
      setConfirmPassword("");
    } catch (error) {
      setMessageType("error");
      setMessage(getErrorMessage(error) || "Invalid or expired reset code.");
    } finally {
      setIsSending(false);
    }
  };

  const goToLogin = () => {
    router.replace(`/auth/login?role=${roleParam}`);
  };

  return (
    <View style={[styles.page, { backgroundColor: colors.background }]}>
      <ScrollView contentContainerStyle={styles.shell} keyboardShouldPersistTaps="handled">
        <View style={styles.leftRail}>
          <Pressable onPress={() => router.back()} style={styles.backButton}>
            <Ionicons name="chevron-back" size={18} color={colors.foreground} />
            <Text style={[styles.backText, { color: colors.foreground }]}>Back</Text>
          </Pressable>
          <View style={styles.copyBlock}>
            <Text style={[styles.kicker, { color: colors.primary }]}>
              {isStaff ? "Staff account recovery" : "Student account recovery"}
            </Text>
            <Text style={[styles.title, { color: colors.foreground }]}>Reset access securely</Text>
            <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
              Enter the email connected to your Smart Attendance account, then use the reset code
              sent to your inbox to choose a new password.
            </Text>
          </View>
        </View>

        <Card style={styles.card}>
          <View style={styles.cardHeader}>
            <View style={[styles.iconBox, { backgroundColor: colors.secondary }]}>
              <Ionicons name="key-outline" size={20} color={colors.primary} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[styles.cardTitle, { color: colors.foreground }]}>Forgot Password</Text>
              <Text style={[styles.cardSubtitle, { color: colors.mutedForeground }]}>
              Send reset instructions to your university email.
              </Text>
            </View>
          </View>

          <InputField
            label="Email Address"
            placeholder="your@university.edu"
            value={email}
            editable={step === "email"}
            onChangeText={(value) => {
              setEmail(value);
              if (messageType) {
                setMessage("");
                setMessageType(null);
              }
            }}
            keyboardType="email-address"
            autoCapitalize="none"
            icon={<Ionicons name="mail-outline" size={17} color={colors.mutedForeground} />}
          />

          {step === "reset" ? (
            <>
              <InputField
                label="Reset Code"
                placeholder="123456"
                value={otp}
                onChangeText={(value) => {
                  setOtp(value);
                  if (messageType === "error") {
                    setMessage("");
                    setMessageType(null);
                  }
                }}
                keyboardType="numeric"
                autoCapitalize="none"
                icon={<Ionicons name="keypad-outline" size={17} color={colors.mutedForeground} />}
              />
              <InputField
                label="New Password"
                placeholder="Enter new password"
                value={password}
                onChangeText={(value) => {
                  setPassword(value);
                  if (messageType === "error") {
                    setMessage("");
                    setMessageType(null);
                  }
                }}
                secureTextEntry
                autoCapitalize="none"
                icon={<Ionicons name="lock-closed-outline" size={17} color={colors.mutedForeground} />}
              />
              <InputField
                label="Confirm Password"
                placeholder="Confirm new password"
                value={confirmPassword}
                onChangeText={(value) => {
                  setConfirmPassword(value);
                  if (messageType === "error") {
                    setMessage("");
                    setMessageType(null);
                  }
                }}
                secureTextEntry
                autoCapitalize="none"
                icon={<Ionicons name="lock-closed-outline" size={17} color={colors.mutedForeground} />}
              />
            </>
          ) : null}

          {message ? (
            <View
              style={[
                styles.messageBox,
                messageType === "success" ? styles.successBox : styles.errorBox,
              ]}
            >
              <Ionicons
                name={messageType === "success" ? "checkmark-circle" : "alert-circle"}
                size={16}
                color={messageType === "success" ? "#166534" : colors.destructive}
              />
              <Text
                style={[
                  styles.messageText,
                  { color: messageType === "success" ? "#166534" : colors.destructive },
                ]}
              >
                {message}
              </Text>
            </View>
          ) : null}

          <Button
            title={
              step === "email"
                ? "Send Reset Code"
                : step === "reset"
                  ? "Reset Password"
                  : "Back to Login"
            }
            onPress={
              step === "email"
                ? handleSendInstructions
                : step === "reset"
                  ? handleResetPassword
                  : goToLogin
            }
            loading={isSending}
            size="lg"
          />
        </Card>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  backButton: {
    alignItems: "center",
    alignSelf: "flex-start",
    backgroundColor: "#FFFFFF",
    borderColor: "#E8ECF4",
    borderRadius: 999,
    borderWidth: 1,
    flexDirection: "row",
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  backText: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 13,
  },
  card: {
    gap: 20,
    maxWidth: 460,
    width: "100%",
  },
  cardHeader: {
    alignItems: "center",
    flexDirection: "row",
    gap: 14,
  },
  cardSubtitle: {
    fontFamily: "Inter_400Regular",
    fontSize: 13,
    marginTop: 3,
  },
  cardTitle: {
    fontFamily: "Inter_700Bold",
    fontSize: 20,
    fontWeight: "700",
  },
  copyBlock: {
    gap: 10,
    maxWidth: 520,
  },
  errorBox: {
    backgroundColor: "#FEF2F2",
    borderColor: "#FECACA",
  },
  iconBox: {
    alignItems: "center",
    borderRadius: 14,
    height: 44,
    justifyContent: "center",
    width: 44,
  },
  kicker: {
    fontFamily: "Inter_700Bold",
    fontSize: 12,
    fontWeight: "700",
    letterSpacing: 1.1,
    textTransform: "uppercase",
  },
  leftRail: {
    gap: 28,
    maxWidth: 560,
  },
  messageBox: {
    alignItems: "center",
    borderRadius: 12,
    borderWidth: 1,
    flexDirection: "row",
    gap: 8,
    padding: 12,
  },
  messageText: {
    flex: 1,
    fontFamily: "Inter_500Medium",
    fontSize: 13,
    lineHeight: 18,
  },
  page: {
    flex: 1,
  },
  shell: {
    alignItems: "center",
    display: "grid",
    gap: 44,
    gridTemplateColumns: "minmax(280px, 1fr) minmax(340px, 460px)",
    minHeight: "100%",
    padding: 40,
  } as any,
  subtitle: {
    fontFamily: "Inter_400Regular",
    fontSize: 16,
    lineHeight: 24,
  },
  successBox: {
    backgroundColor: "#F0FDF4",
    borderColor: "#BBF7D0",
  },
  title: {
    fontFamily: "Inter_700Bold",
    fontSize: 36,
    fontWeight: "700",
    letterSpacing: -0.6,
    lineHeight: 42,
  },
});
