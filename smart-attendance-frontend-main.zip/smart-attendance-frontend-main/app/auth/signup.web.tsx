import { Button, Card, InputField, SelectionField } from "@/components/UI";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { LEVEL_OPTIONS, MAJOR_OPTIONS } from "@/mocks/academicOptions";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router, useLocalSearchParams } from "expo-router";
import React, { useState } from "react";
import { Pressable, ScrollView, StyleSheet, Text, useWindowDimensions, View } from "react-native";

export default function SignupScreen() {
  const colors = useColors();
  const { role, signup, isLoading } = useApp();
  const params = useLocalSearchParams<{ role?: string }>();
  const activeRole = (params.role || role) as "student" | "staff";
  const isStaff = activeRole === "staff";
  const { width } = useWindowDimensions();
  const isDesktop = width >= 960;
  const isCompact = width < 640;

  const [name, setName] = useState("");
  const [universityId, setUniversityId] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [major, setMajor] = useState("");
  const [level, setLevel] = useState("");
  const [error, setError] = useState("");

  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  const handleSignup = async () => {
    if (
      !name ||
      (!isStaff && !universityId) ||
      !email ||
      !password ||
      !confirmPassword ||
      (!isStaff && (!major || !level))
    ) {
      setError("Please fill in all fields.");
      return;
    }
    if (!emailPattern.test(email.trim())) {
      setError("Please enter a valid email address.");
      return;
    }
    if (password !== confirmPassword) {
      setError("Passwords do not match.");
      return;
    }
    setError("");
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

    try {
      await signup({
        name,
        email,
        password,
        role: activeRole,
        universityId: isStaff ? `STF-${Date.now()}` : universityId,
        ...(isStaff ? {} : { major, level }),
      });
      router.replace(isStaff ? "/staff/dashboard" : "/student/dashboard");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to create account.");
    }
  };

  return (
    <View style={[styles.page, { backgroundColor: colors.background }]}>
      <ScrollView
        contentContainerStyle={[
          styles.shell,
          isDesktop ? styles.shellDesktop : styles.shellStacked,
          isCompact ? styles.shellCompact : null,
        ]}
        keyboardShouldPersistTaps="handled"
      >
        <View style={[styles.authFrame, isDesktop ? styles.authFrameDesktop : styles.authFrameStacked]}>
          <View style={[styles.contextPanel, isDesktop ? styles.contextPanelDesktop : null]}>
            <Pressable onPress={() => router.back()} style={styles.backButton}>
              <Ionicons name="chevron-back" size={18} color={colors.foreground} />
              <Text style={[styles.backText, { color: colors.foreground }]}>Back</Text>
            </Pressable>

            <View style={styles.roleMark}>
              <View style={[styles.iconBox, { backgroundColor: colors.secondary }]}>
                <Ionicons name={isStaff ? "briefcase-outline" : "school-outline"} size={20} color={colors.primary} />
              </View>
              <Text style={[styles.kicker, { color: colors.primary }]}>
                {isStaff ? "Staff registration" : "Student registration"}
              </Text>
            </View>

            <View style={styles.heroCopy}>
              <Text style={[styles.title, { color: colors.foreground }]}>Create your Smart Attendance account</Text>
              <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
                {isStaff
                  ? "Set up a staff workspace for managing courses, sessions, attendance reviews, and reporting."
                  : "Set up your student profile so your course enrollments and attendance records stay connected."}
              </Text>
            </View>

            <View style={styles.infoStack}>
              {[
                ["Role", isStaff ? "Academic staff" : "Student"],
                ["Required", isStaff ? "Name, email, and password" : "Name, ID, email, password, major, and level"],
                ["Destination", isStaff ? "Staff dashboard" : "Student dashboard"],
              ].map(([label, value]) => (
                <View key={label} style={styles.auditRow}>
                  <Text style={styles.auditLabel}>{label}</Text>
                  <Text style={[styles.auditValue, { color: colors.foreground }]}>{value}</Text>
                </View>
              ))}
            </View>

            <View style={styles.notePanel}>
              <Ionicons name="shield-checkmark-outline" size={18} color={colors.primary} />
              <Text style={[styles.noteText, { color: colors.mutedForeground }]}>
                The form uses the same role-based validation and mock-backed frontend flow as the app.
              </Text>
            </View>
          </View>

          <Card style={isDesktop ? styles.formCardDesktop : styles.formCard}>
            <View style={styles.formHeader}>
              <View style={{ flex: 1 }}>
                <Text style={[styles.formTitle, { color: colors.foreground }]}>Account details</Text>
                <Text style={[styles.formSubtitle, { color: colors.mutedForeground }]}>
                  Complete every required field to continue.
                </Text>
              </View>
              <View style={styles.rolePill}>
                <View style={[styles.roleDot, { backgroundColor: colors.primary }]} />
                <Text style={[styles.rolePillText, { color: colors.foreground }]}>
                  {isStaff ? "Staff" : "Student"}
                </Text>
              </View>
            </View>

            <View style={styles.fieldStack}>
              {isStaff ? (
                <>
                  <InputField
                    label="Full Name"
                    placeholder="Your full name"
                    value={name}
                    onChangeText={setName}
                    icon={<Ionicons name="person-outline" size={18} color={colors.mutedForeground} />}
                  />

                  <InputField
                    label="Email Address"
                    placeholder="your@university.edu"
                    value={email}
                    onChangeText={setEmail}
                    keyboardType="email-address"
                    autoCapitalize="none"
                    icon={<Ionicons name="mail-outline" size={18} color={colors.mutedForeground} />}
                  />

                  <View style={[styles.fieldRow, isCompact ? styles.fieldRowCompact : null]}>
                    <View style={styles.fieldCell}>
                      <InputField
                        label="Password"
                        placeholder="Create a password"
                        value={password}
                        onChangeText={setPassword}
                        secureTextEntry
                        icon={<Ionicons name="lock-closed-outline" size={18} color={colors.mutedForeground} />}
                      />
                    </View>
                    <View style={styles.fieldCell}>
                      <InputField
                        label="Confirm Password"
                        placeholder="Repeat your password"
                        value={confirmPassword}
                        onChangeText={setConfirmPassword}
                        secureTextEntry
                        icon={<Ionicons name="shield-checkmark-outline" size={18} color={colors.mutedForeground} />}
                      />
                    </View>
                  </View>
                </>
              ) : (
                <>
                  <View style={[styles.fieldRow, isCompact ? styles.fieldRowCompact : null]}>
                    <View style={styles.fieldCell}>
                      <InputField
                        label="Full Name"
                        placeholder="Your full name"
                        value={name}
                        onChangeText={setName}
                        icon={<Ionicons name="person-outline" size={18} color={colors.mutedForeground} />}
                      />
                    </View>
                    <View style={styles.fieldCell}>
                      <InputField
                        label="University ID"
                        placeholder="e.g. 202101234"
                        value={universityId}
                        onChangeText={setUniversityId}
                        icon={<Ionicons name="id-card-outline" size={18} color={colors.mutedForeground} />}
                      />
                    </View>
                  </View>

                  <InputField
                    label="Email Address"
                    placeholder="your@university.edu"
                    value={email}
                    onChangeText={setEmail}
                    keyboardType="email-address"
                    autoCapitalize="none"
                    icon={<Ionicons name="mail-outline" size={18} color={colors.mutedForeground} />}
                  />

                  <View style={[styles.fieldRow, isCompact ? styles.fieldRowCompact : null]}>
                    <View style={styles.fieldCell}>
                      <InputField
                        label="Password"
                        placeholder="Create a password"
                        value={password}
                        onChangeText={setPassword}
                        secureTextEntry
                        icon={<Ionicons name="lock-closed-outline" size={18} color={colors.mutedForeground} />}
                      />
                    </View>
                    <View style={styles.fieldCell}>
                      <InputField
                        label="Confirm Password"
                        placeholder="Repeat your password"
                        value={confirmPassword}
                        onChangeText={setConfirmPassword}
                        secureTextEntry
                        icon={<Ionicons name="shield-checkmark-outline" size={18} color={colors.mutedForeground} />}
                      />
                    </View>
                  </View>

                  <View style={[styles.fieldRow, isCompact ? styles.fieldRowCompact : null]}>
                    <View style={styles.fieldCell}>
                      <SelectionField
                        label="Major"
                        placeholder="Select your major"
                        value={major}
                        onSelect={setMajor}
                        options={MAJOR_OPTIONS.map((option) => ({ ...option }))}
                        icon={<Ionicons name="book-outline" size={18} color={colors.mutedForeground} />}
                      />
                    </View>
                    <View style={styles.fieldCell}>
                      <SelectionField
                        label="Level"
                        placeholder="Select your level"
                        value={level}
                        onSelect={setLevel}
                        options={LEVEL_OPTIONS.map((option) => ({ ...option }))}
                        icon={<Ionicons name="layers-outline" size={18} color={colors.mutedForeground} />}
                      />
                    </View>
                  </View>
                </>
              )}
            </View>

            {error ? (
              <View style={styles.errorBox}>
                <Ionicons name="alert-circle" size={16} color={colors.destructive} />
                <Text style={[styles.errorText, { color: colors.destructive }]}>{error}</Text>
              </View>
            ) : null}

            <View style={styles.actions}>
              <Button title="Create Account" onPress={handleSignup} loading={isLoading} size="lg" />
              <View style={styles.loginRow}>
                <Text style={[styles.loginText, { color: colors.mutedForeground }]}>
                  Already have an account?
                </Text>
                <Pressable onPress={() => router.back()}>
                  <Text style={[styles.loginLink, { color: colors.primary }]}>Sign In</Text>
                </Pressable>
              </View>
            </View>
          </Card>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  actions: {
    gap: 14,
  },
  auditLabel: {
    color: "#6B7A99",
    fontFamily: "Inter_500Medium",
    fontSize: 12,
  },
  auditRow: {
    borderBottomColor: "#E8ECF4",
    borderBottomWidth: 1,
    gap: 4,
    paddingBottom: 10,
  },
  auditValue: {
    fontFamily: "Inter_700Bold",
    fontSize: 14,
    fontWeight: "700",
  },
  backButton: {
    alignItems: "center",
    alignSelf: "flex-start",
    backgroundColor: "#FFFFFF",
    borderColor: "#E8ECF4",
    borderRadius: 999,
    borderWidth: 1,
    flexDirection: "row",
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  backText: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 13,
  },
  errorBox: {
    alignItems: "center",
    backgroundColor: "#FEF2F2",
    borderColor: "#FECACA",
    borderRadius: 12,
    borderWidth: 1,
    flexDirection: "row",
    gap: 8,
    padding: 12,
  },
  errorText: {
    flex: 1,
    fontFamily: "Inter_500Medium",
    fontSize: 13,
  },
  authFrame: {
    width: "100%",
  },
  authFrameDesktop: {
    alignItems: "stretch",
    flexDirection: "row",
    gap: 24,
    maxWidth: 1180,
  },
  authFrameStacked: {
    gap: 18,
    maxWidth: 760,
  },
  contextPanel: {
    backgroundColor: "#FFFFFF",
    borderColor: "#E8ECF4",
    borderRadius: 24,
    borderWidth: 1,
    gap: 22,
    padding: 24,
  },
  contextPanelDesktop: {
    flex: 0.75,
    justifyContent: "space-between",
    minHeight: 620,
  },
  fieldCell: {
    flex: 1,
    minWidth: 0,
  },
  fieldCellSpacer: {
    flex: 1,
  },
  fieldRow: {
    flexDirection: "row",
    gap: 14,
  },
  fieldRowCompact: {
    flexDirection: "column",
  },
  fieldStack: {
    gap: 14,
  },
  formCard: {
    gap: 20,
    width: "100%",
  },
  formCardDesktop: {
    gap: 20,
    flex: 1.15,
    width: "100%",
  },
  formHeader: {
    alignItems: "flex-start",
    flexDirection: "row",
    gap: 14,
    justifyContent: "space-between",
  },
  roleMark: {
    alignItems: "center",
    flexDirection: "row",
    gap: 12,
  },
  formSubtitle: {
    fontFamily: "Inter_400Regular",
    fontSize: 13,
    marginTop: 3,
  },
  formTitle: {
    fontFamily: "Inter_700Bold",
    fontSize: 20,
    fontWeight: "700",
  },
  heroCopy: {
    gap: 12,
  },
  iconBox: {
    alignItems: "center",
    borderRadius: 14,
    height: 44,
    justifyContent: "center",
    width: 44,
  },
  kicker: {
    fontFamily: "Inter_700Bold",
    fontSize: 12,
    fontWeight: "700",
    letterSpacing: 1.1,
    textTransform: "uppercase",
  },
  loginLink: {
    fontFamily: "Inter_700Bold",
    fontSize: 14,
    fontWeight: "700",
  },
  loginRow: {
    alignItems: "center",
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 6,
    justifyContent: "center",
  },
  loginText: {
    fontFamily: "Inter_400Regular",
    fontSize: 14,
  },
  page: {
    flex: 1,
  },
  infoStack: {
    backgroundColor: "#F8FAFC",
    borderColor: "#E8ECF4",
    borderRadius: 18,
    borderWidth: 1,
    gap: 12,
    padding: 16,
  },
  notePanel: {
    alignItems: "flex-start",
    backgroundColor: "#F6F9FF",
    borderColor: "#DCE8FF",
    borderRadius: 16,
    borderWidth: 1,
    flexDirection: "row",
    gap: 10,
    padding: 14,
  },
  noteText: {
    flex: 1,
    fontFamily: "Inter_400Regular",
    fontSize: 13,
    lineHeight: 19,
  },
  roleDot: {
    borderRadius: 999,
    height: 8,
    width: 8,
  },
  rolePill: {
    alignItems: "center",
    backgroundColor: "#F8FAFC",
    borderColor: "#E8ECF4",
    borderRadius: 999,
    borderWidth: 1,
    flexDirection: "row",
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  rolePillText: {
    fontFamily: "Inter_700Bold",
    fontSize: 12,
    fontWeight: "700",
  },
  shell: {
    alignItems: "center",
    minHeight: "100%",
    paddingHorizontal: 28,
    paddingVertical: 28,
  },
  shellDesktop: {
    justifyContent: "center",
  },
  shellStacked: {
    justifyContent: "flex-start",
  },
  shellCompact: {
    paddingHorizontal: 14,
    paddingVertical: 14,
  },
  subtitle: {
    fontFamily: "Inter_400Regular",
    fontSize: 16,
    lineHeight: 24,
    maxWidth: 560,
  },
  title: {
    fontFamily: "Inter_700Bold",
    fontSize: 34,
    fontWeight: "700",
    letterSpacing: -0.6,
    lineHeight: 40,
  },
});
