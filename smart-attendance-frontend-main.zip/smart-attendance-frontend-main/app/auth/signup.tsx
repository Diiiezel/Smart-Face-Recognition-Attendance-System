import { Button, InputField, SelectionField } from "@/components/UI";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { LEVEL_OPTIONS, MAJOR_OPTIONS } from "@/mocks/academicOptions";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import * as Haptics from "expo-haptics";
import { router, useLocalSearchParams } from "expo-router";
import React, { useState } from "react";
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

export default function SignupScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { role, signup, isLoading } = useApp();
  const params = useLocalSearchParams<{ role?: string }>();
  const activeRole = (params.role || role) as "student" | "staff";
  const isStaff = activeRole === "staff";

  const [name, setName] = useState("");
  const [universityId, setUniversityId] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [major, setMajor] = useState("");
  const [level, setLevel] = useState("");
  const [error, setError] = useState("");

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  const handleSignup = async () => {
    if (
      !name ||
      (!isStaff && !universityId) ||
      !email ||
      !password ||
      !confirmPassword ||
      (!isStaff && (!major || !level))
    ) {
      setError("Please fill in all fields.");
      return;
    }
    if (!emailPattern.test(email.trim())) {
      setError("Please enter a valid email address.");
      return;
    }
    if (password !== confirmPassword) {
      setError("Passwords do not match.");
      return;
    }
    setError("");
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

    try {
      await signup({
        name,
        email,
        password,
        role: activeRole,
        universityId: isStaff ? `STF-${Date.now()}` : universityId,
        ...(isStaff ? {} : { major, level }),
      });
      router.replace(isStaff ? "/staff/dashboard" : "/student/dashboard");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to create account.");
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <LinearGradient
        colors={isStaff ? ["#4F46E5", "#6366F1"] : ["#1E3A7B", "#2563EB"]}
        style={[styles.headerGrad, { paddingTop: topPad + 16 }]}
      >
        <Pressable onPress={() => router.back()} style={styles.backBtn}>
          <Ionicons name="chevron-back" size={22} color="#FFF" />
        </Pressable>
        <Text style={styles.roleBadge}>{isStaff ? "Staff Registration" : "Student Registration"}</Text>
        <Text style={styles.headerTitle}>Create Account</Text>
        <Text style={styles.headerSubtitle}>Join Smart Attendance today</Text>
      </LinearGradient>

      <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"} style={{ flex: 1 }}>
        <ScrollView
          contentContainerStyle={[styles.form, { paddingBottom: bottomPad + 20 }]}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.formCard}>
            <InputField
              label="Full Name"
              placeholder="Your full name"
              value={name}
              onChangeText={setName}
              icon={<Ionicons name="person-outline" size={18} color={colors.mutedForeground} />}
            />
            {!isStaff ? (
              <InputField
                label="University ID"
                placeholder="e.g. 202101234"
                value={universityId}
                onChangeText={setUniversityId}
                icon={<Ionicons name="id-card-outline" size={18} color={colors.mutedForeground} />}
              />
            ) : null}
            <InputField
              label="Email Address"
              placeholder="your@university.edu"
              value={email}
              onChangeText={setEmail}
              keyboardType="email-address"
              autoCapitalize="none"
              icon={<Ionicons name="mail-outline" size={18} color={colors.mutedForeground} />}
            />
            <InputField
              label="Password"
              placeholder="Create a password"
              value={password}
              onChangeText={setPassword}
              secureTextEntry
              icon={<Ionicons name="lock-closed-outline" size={18} color={colors.mutedForeground} />}
            />
            <InputField
              label="Confirm Password"
              placeholder="Repeat your password"
              value={confirmPassword}
              onChangeText={setConfirmPassword}
              secureTextEntry
              icon={<Ionicons name="shield-checkmark-outline" size={18} color={colors.mutedForeground} />}
            />
            {!isStaff ? (
              <>
                <SelectionField
                  label="Major"
                  placeholder="Select your major"
                  value={major}
                  onSelect={setMajor}
                  options={MAJOR_OPTIONS.map((option) => ({ ...option }))}
                  icon={<Ionicons name="book-outline" size={18} color={colors.mutedForeground} />}
                />
              <SelectionField
                label="Level"
                placeholder="Select your level"
                value={level}
                onSelect={setLevel}
                options={LEVEL_OPTIONS.map((option) => ({ ...option }))}
                icon={<Ionicons name="layers-outline" size={18} color={colors.mutedForeground} />}
              />
              </>
            ) : null}

            {error ? (
              <View style={styles.errorBox}>
                <Ionicons name="alert-circle" size={15} color={colors.destructive} />
                <Text style={[styles.errorText, { color: colors.destructive }]}>{error}</Text>
              </View>
            ) : null}

            <Button title="Create Account" onPress={handleSignup} loading={isLoading} size="lg" />
          </View>

          <View style={styles.loginRow}>
            <Text style={{ color: colors.mutedForeground, fontSize: 14, fontFamily: "Inter_400Regular" }}>
              Already have an account?
            </Text>
            <Pressable onPress={() => router.back()}>
              <Text style={{ color: colors.primary, fontSize: 14, fontWeight: "600", fontFamily: "Inter_600SemiBold" }}>
                Sign In
              </Text>
            </Pressable>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  headerGrad: {
    paddingHorizontal: 20,
    paddingBottom: 28,
    borderBottomLeftRadius: 28,
    borderBottomRightRadius: 28,
    gap: 6,
  },
  backBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: "rgba(255,255,255,0.15)",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 12,
  },
  roleBadge: {
    fontSize: 12,
    color: "rgba(255,255,255,0.8)",
    fontFamily: "Inter_600SemiBold",
    textTransform: "uppercase",
    letterSpacing: 1,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: "700",
    color: "#FFFFFF",
    fontFamily: "Inter_700Bold",
  },
  headerSubtitle: {
    fontSize: 14,
    color: "rgba(255,255,255,0.72)",
    fontFamily: "Inter_400Regular",
  },
  form: {
    padding: 20,
    gap: 16,
  },
  formCard: {
    backgroundColor: "#FFFFFF",
    borderRadius: 20,
    padding: 20,
    gap: 16,
    shadowColor: "#0F1B3C",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 16,
    elevation: 4,
  },
  errorBox: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    backgroundColor: "#FEE2E2",
    padding: 12,
    borderRadius: 10,
  },
  errorText: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    flex: 1,
  },
  loginRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
  },
});
