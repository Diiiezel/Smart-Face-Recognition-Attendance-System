import { useApp } from "@/context/AppContext";
import { Button, InputField } from "@/components/UI";
import { useColors } from "@/hooks/useColors";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import { router, useLocalSearchParams } from "expo-router";
import React, { useState } from "react";
import {
  KeyboardAvoidingView,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  useWindowDimensions,
  View,
} from "react-native";

export default function LoginScreen() {
  const colors = useColors();
  const { width } = useWindowDimensions();
  const { role, login, isLoading } = useApp();
  const params = useLocalSearchParams<{ role?: string }>();
  const activeRole = (params.role || role) as "student" | "staff";

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");

  const isStaff = activeRole === "staff";
  const isCompact = width < 860;

  const handleLogin = async () => {
    if (!email || !password) {
      setError("Please fill in all fields.");
      return;
    }
    setError("");
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

    try {
      await login(email, password, activeRole);
      router.replace(isStaff ? "/staff/dashboard" : "/student/dashboard");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to sign in.");
    }
  };

  const handleEmailChange = (value: string) => {
    setEmail(value);
    if (error) setError("");
  };

  const handlePasswordChange = (value: string) => {
    setPassword(value);
    if (error) setError("");
  };

  const handleForgotPassword = () => {
    router.push({
      pathname: "/auth/forgot-password",
      params: { role: activeRole },
    } as any);
  };

  return (
    <View style={[styles.page, { backgroundColor: colors.background }]}>
      <ScrollView
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        <View style={[styles.shell, isCompact && styles.shellCompact]}>
          <LinearGradient
            colors={isStaff ? ["#3730A3", "#4F46E5"] : ["#0B1530", "#1E3A7B"]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={[styles.contextPanel, isCompact && styles.contextPanelCompact]}
          >
            <Pressable onPress={() => router.back()} style={styles.backBtn}>
              <Ionicons name="chevron-back" size={18} color="#FFFFFF" />
            </Pressable>
            <View style={styles.contextBody}>
              <View style={styles.contextIcon}>
                <Ionicons
                  name={isStaff ? "briefcase" : "person"}
                  size={30}
                  color={isStaff ? "#6366F1" : "#2563EB"}
                />
              </View>
              <Text style={styles.eyebrow}>Smart Attendance</Text>
              <Text style={styles.contextTitle}>
                {isStaff ? "Staff access for attendance operations" : "Student access for class attendance"}
              </Text>
              <Text style={styles.contextText}>
                Sign in to continue with the existing university attendance workflow.
              </Text>
            </View>
            <View style={styles.contextStats}>
              <View>
                <Text style={styles.contextMetric}>Web</Text>
                <Text style={styles.contextLabel}>Responsive workspace</Text>
              </View>
              <View style={styles.contextDivider} />
              <View>
                <Text style={styles.contextMetric}>{isStaff ? "Staff" : "Student"}</Text>
                <Text style={styles.contextLabel}>Selected role</Text>
              </View>
            </View>
          </LinearGradient>

          <KeyboardAvoidingView behavior="height" style={styles.formWrap}>
            <View style={[styles.formCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <View style={styles.formHeader}>
                <Text style={[styles.formTitle, { color: colors.foreground }]}>
                  {isStaff ? "Staff Login" : "Student Login"}
                </Text>
                <Text style={[styles.formSubtitle, { color: colors.mutedForeground }]}>
                  Sign in to your {isStaff ? "staff" : "student"} account
                </Text>
              </View>

              <InputField
                label="Email Address"
                placeholder="your@university.edu"
                value={email}
                onChangeText={handleEmailChange}
                keyboardType="email-address"
                autoCapitalize="none"
                icon={
                  <Ionicons
                    name="mail-outline"
                    size={17}
                    color={colors.mutedForeground}
                  />
                }
              />
              <InputField
                label="Password"
                placeholder="Enter your password"
                value={password}
                onChangeText={handlePasswordChange}
                secureTextEntry={!showPassword}
                icon={
                  <Ionicons
                    name="lock-closed-outline"
                    size={17}
                    color={colors.mutedForeground}
                  />
                }
                rightElement={
                  <Pressable onPress={() => setShowPassword(!showPassword)}>
                    <Ionicons
                      name={showPassword ? "eye-off-outline" : "eye-outline"}
                      size={17}
                      color={colors.mutedForeground}
                    />
                  </Pressable>
                }
              />

              <Pressable onPress={handleForgotPassword} style={styles.forgotPasswordBtn}>
                <Text style={[styles.forgotPasswordText, { color: colors.primary }]}>
                  Forgot Password?
                </Text>
              </Pressable>

              {error ? (
                <View style={styles.errorBox}>
                  <Ionicons name="alert-circle" size={15} color={colors.destructive} />
                  <Text style={[styles.errorText, { color: colors.destructive }]}>{error}</Text>
                </View>
              ) : null}

              <Button title="Sign In" onPress={handleLogin} loading={isLoading} size="lg" />

              <View style={styles.formFooter}>
                <Text style={[styles.footerText, { color: colors.mutedForeground }]}>
                  Don't have an account?
                </Text>
                <Pressable onPress={() => router.push(`/auth/signup?role=${activeRole}`)}>
                  <Text style={[styles.footerLink, { color: colors.primary }]}>Sign Up</Text>
                </Pressable>
              </View>

              <Pressable
                onPress={() => router.replace("/role-select")}
                style={({ pressed, hovered }) => [
                  styles.switchRole,
                  { borderColor: colors.border },
                  hovered && { backgroundColor: colors.muted },
                  pressed && { opacity: 0.72 },
                ]}
              >
                <Text style={[styles.switchRoleText, { color: colors.mutedForeground }]}>
                  Switch role
                </Text>
              </Pressable>
            </View>
          </KeyboardAvoidingView>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  backBtn: {
    alignItems: "center",
    backgroundColor: "rgba(255,255,255,0.12)",
    borderRadius: 12,
    height: 40,
    justifyContent: "center",
    width: 40,
  },
  contextBody: {
    gap: 12,
  },
  contextDivider: {
    backgroundColor: "rgba(255,255,255,0.14)",
    height: 42,
    width: 1,
  },
  contextIcon: {
    alignItems: "center",
    backgroundColor: "#FFFFFF",
    borderRadius: 18,
    height: 64,
    justifyContent: "center",
    width: 64,
  },
  contextLabel: {
    color: "rgba(255,255,255,0.54)",
    fontFamily: "Inter_400Regular",
    fontSize: 12,
    marginTop: 2,
  },
  contextMetric: {
    color: "#FFFFFF",
    fontFamily: "Inter_700Bold",
    fontSize: 18,
    fontWeight: "700",
  },
  contextPanel: {
    borderRadius: 30,
    flex: 1,
    gap: 58,
    justifyContent: "space-between",
    minHeight: 620,
    padding: 32,
  },
  contextPanelCompact: {
    minHeight: 360,
  },
  contextStats: {
    alignItems: "center",
    backgroundColor: "rgba(255,255,255,0.08)",
    borderColor: "rgba(255,255,255,0.1)",
    borderRadius: 20,
    borderWidth: 1,
    flexDirection: "row",
    gap: 20,
    padding: 18,
  },
  contextText: {
    color: "rgba(255,255,255,0.68)",
    fontFamily: "Inter_400Regular",
    fontSize: 15,
    lineHeight: 23,
    maxWidth: 500,
  },
  contextTitle: {
    color: "#FFFFFF",
    fontFamily: "Inter_700Bold",
    fontSize: 40,
    fontWeight: "700",
    letterSpacing: -1,
    lineHeight: 48,
    maxWidth: 560,
  },
  errorBox: {
    alignItems: "center",
    backgroundColor: "#FEF2F2",
    borderColor: "#FECACA",
    borderRadius: 14,
    borderWidth: 1,
    flexDirection: "row",
    gap: 8,
    padding: 12,
  },
  errorText: {
    flex: 1,
    fontFamily: "Inter_400Regular",
    fontSize: 13,
  },
  eyebrow: {
    color: "rgba(255,255,255,0.58)",
    fontFamily: "Inter_600SemiBold",
    fontSize: 12,
    fontWeight: "600",
    letterSpacing: 1.2,
    textTransform: "uppercase",
  },
  footerLink: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 14,
    fontWeight: "600",
  },
  footerText: {
    fontFamily: "Inter_400Regular",
    fontSize: 14,
  },
  forgotPasswordBtn: {
    alignSelf: "flex-end",
    marginTop: -6,
  },
  forgotPasswordText: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 13,
  },
  formCard: {
    borderRadius: 24,
    borderWidth: 1,
    gap: 18,
    padding: 30,
    boxShadow: "0 18px 36px rgba(13, 27, 62, 0.08)",
  } as any,
  formFooter: {
    alignItems: "center",
    flexDirection: "row",
    gap: 6,
    justifyContent: "center",
  },
  formHeader: {
    gap: 6,
    marginBottom: 4,
  },
  formSubtitle: {
    fontFamily: "Inter_400Regular",
    fontSize: 14,
  },
  formTitle: {
    fontFamily: "Inter_700Bold",
    fontSize: 28,
    fontWeight: "700",
    letterSpacing: -0.5,
  },
  formWrap: {
    flex: 1,
    justifyContent: "center",
    maxWidth: 480,
    minWidth: 0,
  },
  page: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
  },
  shell: {
    alignSelf: "center",
    flexDirection: "row",
    gap: 28,
    maxWidth: 1120,
    padding: 28,
    width: "100%",
  },
  shellCompact: {
    flexDirection: "column",
    padding: 16,
  },
  switchRole: {
    alignItems: "center",
    borderRadius: 999,
    borderWidth: 1,
    paddingVertical: 10,
  },
  switchRoleText: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 13,
    fontWeight: "600",
  },
});
