import { Button, InputField } from "@/components/UI";
import { useColors } from "@/hooks/useColors";
import { authService, getErrorMessage } from "@/services/authService";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { router, useLocalSearchParams } from "expo-router";
import React, { useState } from "react";
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

export default function ForgotPasswordScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{ role?: string }>();
  const isStaff = params.role === "staff";
  const roleParam = isStaff ? "staff" : "student";
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [step, setStep] = useState<"email" | "reset" | "done">("email");
  const [message, setMessage] = useState("");
  const [messageType, setMessageType] = useState<"error" | "success" | null>(null);
  const [isSending, setIsSending] = useState(false);

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  const handleSendInstructions = async () => {
    if (!email.trim()) {
      setMessageType("error");
      setMessage("Please enter your email address.");
      return;
    }

    setIsSending(true);

    try {
      const response = await authService.forgotPassword(email.trim());
      setMessageType("success");
      setMessage(response.message || "If this email exists, a reset code has been sent.");
      setStep("reset");
    } catch (error) {
      setMessageType("error");
      setMessage(getErrorMessage(error));
    } finally {
      setIsSending(false);
    }
  };

  const handleResetPassword = async () => {
    if (!otp.trim() || !password || !confirmPassword) {
      setMessageType("error");
      setMessage("Please enter the reset code and new password.");
      return;
    }

    if (password !== confirmPassword) {
      setMessageType("error");
      setMessage("Passwords do not match.");
      return;
    }

    setIsSending(true);

    try {
      const response = await authService.resetPassword({
        email: email.trim(),
        otp: otp.trim(),
        password,
        password_confirmation: confirmPassword,
      });
      setMessageType("success");
      setMessage(response.message || "Password reset successfully. You can now sign in.");
      setStep("done");
      setOtp("");
      setPassword("");
      setConfirmPassword("");
    } catch (error) {
      setMessageType("error");
      setMessage(getErrorMessage(error) || "Invalid or expired reset code.");
    } finally {
      setIsSending(false);
    }
  };

  const goToLogin = () => {
    router.replace(`/auth/login?role=${roleParam}`);
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <LinearGradient
        colors={isStaff ? ["#3730A3", "#4F46E5"] : ["#0F1B3C", "#1E3A7B"]}
        start={{ x: 0.1, y: 0 }}
        end={{ x: 0.9, y: 1 }}
        style={[styles.headerGrad, { paddingTop: topPad + 14 }]}
      >
        <Pressable onPress={() => router.back()} style={styles.backBtn}>
          <Ionicons name="chevron-back" size={20} color="#FFF" />
        </Pressable>
        <View style={styles.headerBody}>
          <View style={styles.headerIcon}>
            <Ionicons name="key-outline" size={28} color={isStaff ? "#6366F1" : "#2563EB"} />
          </View>
          <View style={{ flex: 1, gap: 4 }}>
            <Text style={styles.headerTitle}>Forgot Password</Text>
            <Text style={styles.headerSubtitle}>
              Enter your email address to reset your password.
            </Text>
          </View>
        </View>
      </LinearGradient>

      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        style={{ flex: 1 }}
      >
        <ScrollView
          contentContainerStyle={[styles.form, { paddingBottom: bottomPad + 20 }]}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.formCard}>
            <InputField
              label="Email Address"
              placeholder="your@university.edu"
              value={email}
              editable={step === "email"}
              onChangeText={(value) => {
                setEmail(value);
                if (messageType) {
                  setMessage("");
                  setMessageType(null);
                }
              }}
              keyboardType="email-address"
              autoCapitalize="none"
              icon={<Ionicons name="mail-outline" size={17} color={colors.mutedForeground} />}
            />

            {step === "reset" ? (
              <>
                <InputField
                  label="Reset Code"
                  placeholder="123456"
                  value={otp}
                  onChangeText={(value) => {
                    setOtp(value);
                    if (messageType === "error") {
                      setMessage("");
                      setMessageType(null);
                    }
                  }}
                  keyboardType="numeric"
                  autoCapitalize="none"
                  icon={<Ionicons name="keypad-outline" size={17} color={colors.mutedForeground} />}
                />
                <InputField
                  label="New Password"
                  placeholder="Enter new password"
                  value={password}
                  onChangeText={(value) => {
                    setPassword(value);
                    if (messageType === "error") {
                      setMessage("");
                      setMessageType(null);
                    }
                  }}
                  secureTextEntry
                  autoCapitalize="none"
                  icon={<Ionicons name="lock-closed-outline" size={17} color={colors.mutedForeground} />}
                />
                <InputField
                  label="Confirm Password"
                  placeholder="Confirm new password"
                  value={confirmPassword}
                  onChangeText={(value) => {
                    setConfirmPassword(value);
                    if (messageType === "error") {
                      setMessage("");
                      setMessageType(null);
                    }
                  }}
                  secureTextEntry
                  autoCapitalize="none"
                  icon={<Ionicons name="lock-closed-outline" size={17} color={colors.mutedForeground} />}
                />
              </>
            ) : null}

            {message ? (
              <View
                style={[
                  styles.messageBox,
                  messageType === "success" ? styles.successBox : styles.errorBox,
                ]}
              >
                <Ionicons
                  name={messageType === "success" ? "checkmark-circle" : "alert-circle"}
                  size={16}
                  color={messageType === "success" ? "#166534" : colors.destructive}
                />
                <Text
                  style={[
                    styles.messageText,
                    { color: messageType === "success" ? "#166534" : colors.destructive },
                  ]}
                >
                  {message}
                </Text>
              </View>
            ) : null}

            <Button
              title={
                step === "email"
                  ? "Send Reset Code"
                  : step === "reset"
                    ? "Reset Password"
                    : "Back to Login"
              }
              onPress={
                step === "email"
                  ? handleSendInstructions
                  : step === "reset"
                    ? handleResetPassword
                    : goToLogin
              }
              loading={isSending}
              size="lg"
            />
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  headerGrad: {
    paddingHorizontal: 20,
    paddingBottom: 36,
    borderBottomLeftRadius: 28,
    borderBottomRightRadius: 28,
    gap: 18,
  },
  backBtn: {
    width: 34,
    height: 34,
    borderRadius: 10,
    backgroundColor: "rgba(255,255,255,0.12)",
    alignItems: "center",
    justifyContent: "center",
    alignSelf: "flex-start",
  },
  headerBody: {
    flexDirection: "row",
    alignItems: "center",
    gap: 14,
  },
  headerIcon: {
    width: 56,
    height: 56,
    borderRadius: 16,
    backgroundColor: "#FFFFFF",
    alignItems: "center",
    justifyContent: "center",
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: "700",
    color: "#FFFFFF",
    fontFamily: "Inter_700Bold",
  },
  headerSubtitle: {
    fontSize: 13,
    color: "rgba(255,255,255,0.72)",
    fontFamily: "Inter_400Regular",
    lineHeight: 18,
  },
  form: {
    padding: 20,
  },
  formCard: {
    backgroundColor: "#FFFFFF",
    borderRadius: 20,
    padding: 22,
    gap: 18,
    borderWidth: 1,
    borderColor: "#E8ECF4",
    shadowColor: "#0D1B3E",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.06,
    shadowRadius: 16,
    elevation: 4,
  },
  messageBox: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
  },
  successBox: {
    backgroundColor: "#F0FDF4",
    borderColor: "#BBF7D0",
  },
  errorBox: {
    backgroundColor: "#FEF2F2",
    borderColor: "#FECACA",
  },
  messageText: {
    flex: 1,
    fontSize: 13,
    fontFamily: "Inter_500Medium",
    lineHeight: 18,
  },
});
