import { useApp } from "@/context/AppContext";
import { Redirect } from "expo-router";
import React from "react";

export default function TabIndex() {
  const { isAuthenticated, role } = useApp();
  if (isAuthenticated && role === "student") return <Redirect href="/student/dashboard" />;
  if (isAuthenticated && role === "staff") return <Redirect href="/staff/dashboard" />;
  return <Redirect href="/role-select" />;
}
