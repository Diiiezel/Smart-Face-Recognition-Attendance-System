const colors = {
  light: {
    text: "#0D1B3E",
    tint: "#2563EB",

    background: "#F5F7FB",
    foreground: "#0D1B3E",

    card: "#FFFFFF",
    cardForeground: "#0D1B3E",

    primary: "#2563EB",
    primaryForeground: "#FFFFFF",

    secondary: "#EEF2FF",
    secondaryForeground: "#1E3A7B",

    muted: "#EFF2F8",
    mutedForeground: "#6B7A99",

    accent: "#6366F1",
    accentForeground: "#FFFFFF",

    destructive: "#EF4444",
    destructiveForeground: "#FFFFFF",

    success: "#10B981",
    successForeground: "#FFFFFF",

    warning: "#F59E0B",
    warningForeground: "#FFFFFF",

    border: "#E8ECF4",
    input: "#E8ECF4",

    navy: "#0D1B3E",
    navyLight: "#1E3A7B",
    blueGlow: "#3B82F6",
  },

  radius: 16,
};

export default colors;
