export interface StudentQrPayload {
  studentId: string;
  name: string;
  universityCode: string;
  major: string;
  year: string;
  role: "student";
}

const YEAR_LABEL_TO_NUMBER: Record<string, string> = {
  "First Year": "1",
  "Second Year": "2",
  "Third Year": "3",
  "Fourth Year": "4",
};

export function normalizeYearValue(level?: string | null) {
  if (!level) {
    return "1";
  }

  const trimmed = level.trim();

  if (YEAR_LABEL_TO_NUMBER[trimmed]) {
    return YEAR_LABEL_TO_NUMBER[trimmed];
  }

  const directMatch = trimmed.match(/\b([1-4])\b/);
  if (directMatch?.[1]) {
    return directMatch[1];
  }

  const ordinalMatch = trimmed.match(/(first|second|third|fourth)/i);
  if (ordinalMatch?.[1]) {
    return YEAR_LABEL_TO_NUMBER[
      `${ordinalMatch[1].charAt(0).toUpperCase()}${ordinalMatch[1].slice(1).toLowerCase()} Year`
    ];
  }

  return "1";
}

export function buildStudentQrPayload(input: {
  studentId?: string | number | null;
  name?: string | null;
  universityCode?: string | null;
  major?: string | null;
  level?: string | null;
}): StudentQrPayload {
  return {
    studentId: String(input.studentId ?? "").trim(),
    name: String(input.name ?? "").trim(),
    universityCode: String(input.universityCode ?? "").trim(),
    major: String(input.major ?? "").trim() || "CS",
    year: normalizeYearValue(input.level),
    role: "student",
  };
}

export function stringifyStudentQrPayload(payload: StudentQrPayload) {
  return JSON.stringify(payload);
}

export function parseStudentQrPayload(rawPayload: string): StudentQrPayload {
  let parsed: unknown;

  try {
    parsed = JSON.parse(rawPayload);
  } catch {
    throw new Error("Please scan a student QR code from this app.");
  }

  if (!parsed || typeof parsed !== "object") {
    throw new Error("Please scan a student QR code from this app.");
  }

  const payload = parsed as Partial<StudentQrPayload> & {
    id?: string | number | null;
    university_code?: string | null;
    full_name?: string | null;
    level?: string | number | null;
  };

  const studentId = payload.studentId ?? payload.id;
  const name = payload.name || payload.full_name;
  const universityCode = payload.universityCode || payload.university_code;
  const major = payload.major || "CS";
  const year = payload.year || normalizeYearValue(
    payload.level === null || payload.level === undefined ? null : String(payload.level),
  );

  if (payload.role && payload.role !== "student") {
    throw new Error("Please scan a student QR code from this app.");
  }

  if (
    !studentId ||
    !name ||
    !universityCode ||
    !major ||
    !year
  ) {
    throw new Error("Please scan a student QR code from this app.");
  }

  return {
    studentId: String(studentId).trim(),
    name: String(name).trim(),
    universityCode: String(universityCode).trim(),
    major: String(major).trim(),
    year: String(year).trim(),
    role: "student",
  };
}
