const LEVEL_LABELS: Record<string, string> = {
  "1": "First Year",
  "2": "Second Year",
  "3": "Third Year",
  "4": "Fourth Year",
};

export function formatAcademicLevel(value?: string | number | null) {
  const normalized = String(value || "").trim();
  return LEVEL_LABELS[normalized] || normalized;
}

export function academicLevelToNumber(value?: string | number | null) {
  const normalized = String(value || "").trim();

  if (!normalized) {
    return "";
  }

  if (LEVEL_LABELS[normalized]) {
    return normalized;
  }

  const match = Object.entries(LEVEL_LABELS).find(
    ([, label]) => label.toLowerCase() === normalized.toLowerCase(),
  );

  return match?.[0] || normalized;
}
