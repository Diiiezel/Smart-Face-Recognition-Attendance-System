import type { AttendanceSession, SessionReport } from "@/context/AppContext";
import { buildCsv, type CsvCell } from "@/utils/csvExport";

type LoadSessionReport = (sessionId: string) => Promise<SessionReport>;

function titleCase(value: string) {
  return value ? value.charAt(0).toUpperCase() + value.slice(1) : "";
}

function sessionDateTime(session: AttendanceSession, time: string) {
  return [session.date, time].filter(Boolean).join(" ");
}

function sessionBlock(session: AttendanceSession, report: SessionReport, index: number): string {
  const rows: CsvCell[][] = [
    ["Course Name", session.courseName],
    ["Course Code", session.courseCode],
    ["Session ID", session.sessionIds?.length ? session.sessionIds.join(", ") : session.id],
    ["Status", titleCase(session.status)],
    ["Open Date", sessionDateTime(session, session.startTime)],
    ["Close Date", sessionDateTime(session, session.endTime)],
    [],
    ["University Code", "Full Name", "Status"],
    ...report.students.map((student) => [
      student.universityId,
      student.name,
      student.status === "present" ? "Present" : "Absent",
    ]),
  ];

  const prefix = index > 0 ? "\n" : "";
  return `${prefix}${rows.map((row) => row.map((cell) => buildCsv([String(cell ?? "")], []).split("\n")[0]).join(",")).join("\n")}`;
}

export async function buildSessionReportsCsv(
  sessions: AttendanceSession[],
  loadSessionReport: LoadSessionReport,
) {
  const reports = await Promise.all(
    sessions.map(async (session) => ({
      session,
      report: await loadSessionReport(session.id),
    })),
  );

  return reports.map(({ session, report }, index) => sessionBlock(session, report, index)).join("\n");
}
