function pad(value: number) {
  return String(value).padStart(2, "0");
}

const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;
const TIME_PATTERN = /^\d{2}:\d{2}$/;

function parseLocalDateTime(date: string, time: string) {
  const normalizedDate = date.trim();
  const normalizedTime = time.trim();

  if (!DATE_PATTERN.test(normalizedDate) || !TIME_PATTERN.test(normalizedTime)) {
    return null;
  }

  const [year, month, day] = normalizedDate.split("-").map(Number);
  const [hour, minute] = normalizedTime.split(":").map(Number);

  if (hour > 23 || minute > 59) {
    return null;
  }

  const value = new Date(year, month - 1, day, hour, minute, 0);

  if (
    value.getFullYear() !== year ||
    value.getMonth() !== month - 1 ||
    value.getDate() !== day ||
    value.getHours() !== hour ||
    value.getMinutes() !== minute
  ) {
    return null;
  }

  return { value, normalizedDate, hour, minute };
}

export function buildStrictLocalDateTime(date: string, time: string) {
  const parsed = parseLocalDateTime(date, time);

  if (!parsed) {
    return null;
  }

  const offsetMinutes = -parsed.value.getTimezoneOffset();
  const sign = offsetMinutes >= 0 ? "+" : "-";
  const absoluteOffset = Math.abs(offsetMinutes);
  const offset = `${sign}${pad(Math.floor(absoluteOffset / 60))}:${pad(absoluteOffset % 60)}`;

  return `${parsed.normalizedDate}T${pad(parsed.hour)}:${pad(parsed.minute)}:00${offset}`;
}

export function buildSessionDateTimes(date: string, startTime: string, endTime: string) {
  const start = parseLocalDateTime(date, startTime);
  const end = parseLocalDateTime(date, endTime);
  const startsAt = buildStrictLocalDateTime(date, startTime);
  const endsAt = buildStrictLocalDateTime(date, endTime);

  if (!start || !end || !startsAt || !endsAt || end.value.getTime() <= start.value.getTime()) {
    return null;
  }

  return { startsAt, endsAt };
}

export function buildFutureSessionDateTimes(date: string, startTime: string, endTime: string) {
  const parsed = parseLocalDateTime(date, startTime);
  const dateTimes = buildSessionDateTimes(date, startTime, endTime);

  if (!parsed || !dateTimes || parsed.value.getTime() < Date.now()) {
    return null;
  }

  return dateTimes;
}

export function buildLocalDateTime(date: string, time: string) {
  const normalizedDate = date && date !== "Not scheduled"
    ? date.trim()
    : `${new Date().getFullYear()}-${pad(new Date().getMonth() + 1)}-${pad(new Date().getDate())}`;
  const normalizedTime = time && time !== "--" ? time.trim() : "00:00";
  const [year, month, day] = normalizedDate.split("-").map(Number);
  const [hour, minute] = normalizedTime.split(":").map(Number);
  const value = new Date(year, (month || 1) - 1, day || 1, hour || 0, minute || 0, 0);
  const offsetMinutes = -value.getTimezoneOffset();
  const sign = offsetMinutes >= 0 ? "+" : "-";
  const absoluteOffset = Math.abs(offsetMinutes);
  const offset = `${sign}${pad(Math.floor(absoluteOffset / 60))}:${pad(absoluteOffset % 60)}`;

  return `${normalizedDate}T${pad(hour || 0)}:${pad(minute || 0)}:00${offset}`;
}

export function formatLocalDate(dateValue?: string | null) {
  if (!dateValue) return "Not scheduled";

  const date = new Date(dateValue);
  if (Number.isNaN(date.getTime())) {
    return dateValue.includes("T") ? dateValue.slice(0, 10) : dateValue;
  }

  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

export function formatLocalTime(dateValue?: string | null) {
  if (!dateValue) return "--";

  const date = new Date(dateValue);
  if (Number.isNaN(date.getTime())) {
    const match = dateValue.match(/T?(\d{2}:\d{2})/);
    return match?.[1] || dateValue;
  }

  return `${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

export function formatScheduleDate(dateValue?: string | null) {
  if (!dateValue) return "Not scheduled";

  const match = dateValue.match(/^(\d{4}-\d{2}-\d{2})/);
  if (match) return match[1];

  return formatLocalDate(dateValue);
}

export function formatScheduleTime(dateValue?: string | null) {
  if (!dateValue) return "--";

  const match = dateValue.match(/T?(\d{2}:\d{2})/);
  if (match) return match[1];

  return formatLocalTime(dateValue);
}
